#include <tls/jhd_tls_config.h>

#if defined(JHD_TLS_CTR_DRBG_C)

#include <tls/jhd_tls_ctr_drbg.h>

#include <string.h>
#include <stdio.h>

 jhd_tls_ctr_drbg_context s_g_jhd_tls_ctr_drbg;



/*
 * Non-public function wrapped by jhd_tls_ctr_drbg_seed(). Necessary to allow
 * NIST tests to succeed (which require known length fixed entropy)
 */
int jhd_tls_ctr_drbg_seed_entropy_len(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom, size_t len, size_t entropy_len) {
	int ret;
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];

	jhd_tls_platform_zeroize(key, JHD_TLS_CTR_DRBG_KEYSIZE);

	jhd_tls_platform_zeroize(&ctx->aes_ctx, sizeof(jhd_tls_aes_context));

//	ctx->f_entropy = jhd_tls_entropy_func;

	ctx->entropy_len = entropy_len;
	ctx->reseed_interval = JHD_TLS_CTR_DRBG_RESEED_INTERVAL;

	/*
	 * Initialize with an empty key
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&ctx->aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		return (ret);
	}

	if ((ret = jhd_tls_ctr_drbg_reseed(ctx, custom, len)) != 0) {
		return (ret);
	}
	return (0);
}
#if !defined(JHD_TLS_INLINE)
void jhd_tls_ctr_drbg_init(jhd_tls_ctr_drbg_context *ctx) {
	memset(ctx, 0, sizeof(jhd_tls_ctr_drbg_context));
}
int jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom, size_t len) {
	return (jhd_tls_ctr_drbg_seed_entropy_len(ctx, custom, len, JHD_TLS_CTR_DRBG_ENTROPY_LEN));
}
#endif


void jhd_tls_ctr_drbg_set_prediction_resistance(jhd_tls_ctr_drbg_context *ctx, int resistance) {
	ctx->prediction_resistance = resistance;
}

void jhd_tls_ctr_drbg_set_entropy_len(jhd_tls_ctr_drbg_context *ctx, size_t len) {
	ctx->entropy_len = len;
}

void jhd_tls_ctr_drbg_set_reseed_interval(jhd_tls_ctr_drbg_context *ctx, int interval) {
	ctx->reseed_interval = interval;
}

static int block_cipher_df(unsigned char *output, const unsigned char *data, size_t data_len) {
	unsigned char buf[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16];
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];
	unsigned char chain[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	unsigned char *p, *iv;
	jhd_tls_aes_context aes_ctx;
	int ret = 0;

	int i, j;
	size_t buf_len, use_len;

	if (data_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	jhd_tls_platform_zeroize(buf, JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16);
	jhd_tls_platform_zeroize(&aes_ctx, sizeof(jhd_tls_aes_context));

	/*
	 * Construct IV (16 bytes) and S in buffer
	 * IV = Counter (in 32-bits) padded to 16 with zeroes
	 * S = Length input string (in 32-bits) || Length of output (in 32-bits) ||
	 *     data || 0x80
	 *     (Total is padded to a multiple of 16-bytes with zeroes)
	 */
	p = buf + JHD_TLS_CTR_DRBG_BLOCKSIZE;
	*p++ = (data_len >> 24) & 0xff;
	*p++ = (data_len >> 16) & 0xff;
	*p++ = (data_len >> 8) & 0xff;
	*p++ = (data_len) & 0xff;
	p += 3;
	*p++ = JHD_TLS_CTR_DRBG_SEEDLEN;
	memcpy(p, data, data_len);
	p[data_len] = 0x80;

	buf_len = JHD_TLS_CTR_DRBG_BLOCKSIZE + 8 + data_len + 1;

	for (i = 0; i < JHD_TLS_CTR_DRBG_KEYSIZE; i++)
		key[i] = i;

	if ((ret = jhd_tls_aes_setkey_enc(&aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		goto exit;
	}

	/*
	 * Reduce data to JHD_TLS_CTR_DRBG_SEEDLEN bytes of data
	 */
	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		p = buf;
		memset(chain, 0, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		use_len = buf_len;

		while (use_len > 0) {
			for (i = 0; i < JHD_TLS_CTR_DRBG_BLOCKSIZE; i++)
				chain[i] ^= p[i];
			p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
			use_len -= (use_len >= JHD_TLS_CTR_DRBG_BLOCKSIZE) ?
			JHD_TLS_CTR_DRBG_BLOCKSIZE :
			                                                     use_len;

			if ((ret = jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, chain, chain)) != 0) {
				goto exit;
			}
		}

		memcpy(tmp + j, chain, JHD_TLS_CTR_DRBG_BLOCKSIZE);

		/*
		 * Update IV
		 */
		buf[3]++;
	}

	/*
	 * Do final encryption with reduced data
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		goto exit;
	}
	iv = tmp + JHD_TLS_CTR_DRBG_KEYSIZE;
	p = output;

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		if ((ret = jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, iv, iv)) != 0) {
			goto exit;
		}
		memcpy(p, iv, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}
	exit: jhd_tls_aes_free(&aes_ctx);
	/*
	 * tidy up the stack
	 */
	jhd_tls_platform_zeroize(buf, sizeof(buf));
	jhd_tls_platform_zeroize(tmp, sizeof(tmp));
	jhd_tls_platform_zeroize(key, sizeof(key));
	jhd_tls_platform_zeroize(chain, sizeof(chain));
	if (0 != ret) {
		/*
		 * wipe partial seed from memory
		 */
		jhd_tls_platform_zeroize(output, JHD_TLS_CTR_DRBG_SEEDLEN);
	}

	return (ret);
}

static int ctr_drbg_update_internal(jhd_tls_ctr_drbg_context *ctx, const unsigned char data[JHD_TLS_CTR_DRBG_SEEDLEN]) {
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = tmp;
	int i, j;
	int ret = 0;

	memset(tmp, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		if ((ret = jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, p)) != 0) {
			return (ret);
		}

		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}

	for (i = 0; i < JHD_TLS_CTR_DRBG_SEEDLEN; i++)
		tmp[i] ^= data[i];

	/*
	 * Update key and counter
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&ctx->aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		return (ret);
	}
	memcpy(ctx->counter, tmp + JHD_TLS_CTR_DRBG_KEYSIZE, JHD_TLS_CTR_DRBG_BLOCKSIZE);

	return (0);
}

void jhd_tls_ctr_drbg_update(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t add_len) {
	unsigned char add_input[JHD_TLS_CTR_DRBG_SEEDLEN];

	if (add_len > 0) {
		/* MAX_INPUT would be more logical here, but we have to match
		 * block_cipher_df()'s limits since we can't propagate errors */
		if (add_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
			add_len = JHD_TLS_CTR_DRBG_MAX_SEED_INPUT;

		block_cipher_df(add_input, additional, add_len);
		ctr_drbg_update_internal(ctx, add_input);
	}
}

int jhd_tls_ctr_drbg_reseed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t len) {
	unsigned char seed[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT];
	size_t seedlen = 0;
	int ret;

	if (ctx->entropy_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT || len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT - ctx->entropy_len)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	memset(seed, 0, JHD_TLS_CTR_DRBG_MAX_SEED_INPUT);

	/*
	 * Gather entropy_len bytes of entropy to seed state
	 */
	if (0 != jhd_tls_entropy_func(&ctx->entropy, seed, ctx->entropy_len)) {
		return ( JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED);
	}

	seedlen += ctx->entropy_len;

	/*
	 * Add additional data
	 */
	if (additional && len) {
		memcpy(seed + seedlen, additional, len);
		seedlen += len;
	}

	/*
	 * Reduce to 384 bits
	 */
	if ((ret = block_cipher_df(seed, seed, seedlen)) != 0) {
		return (ret);
	}

	/*
	 * Update state
	 */
	if ((ret = ctr_drbg_update_internal(ctx, seed)) != 0) {
		return (ret);
	}
	ctx->reseed_counter = 1;

	return (0);
}

int jhd_tls_ctr_drbg_random_with_add(void *p_rng, unsigned char *output, size_t output_len, const unsigned char *additional, size_t add_len) {
	int ret = 0;
	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;
	unsigned char add_input[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = output;
	unsigned char tmp[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	int i;
	size_t use_len;

	if (output_len > JHD_TLS_CTR_DRBG_MAX_REQUEST)
		return ( JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG);

	if (add_len > JHD_TLS_CTR_DRBG_MAX_INPUT)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	memset(add_input, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	if (ctx->reseed_counter > ctx->reseed_interval || ctx->prediction_resistance) {
		if ((ret = jhd_tls_ctr_drbg_reseed(ctx, additional, add_len)) != 0) {
			return (ret);
		}
		add_len = 0;
	}

	if (add_len > 0) {
		if ((ret = block_cipher_df(add_input, additional, add_len)) != 0) {
			return (ret);
		}
		if ((ret = ctr_drbg_update_internal(ctx, add_input)) != 0) {
			return (ret);
		}
	}

	while (output_len > 0) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		if ((ret = jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, tmp)) != 0) {
			return (ret);
		}

		use_len = (output_len > JHD_TLS_CTR_DRBG_BLOCKSIZE) ? JHD_TLS_CTR_DRBG_BLOCKSIZE : output_len;
		/*
		 * Copy random block to destination
		 */
		memcpy(p, tmp, use_len);
		p += use_len;
		output_len -= use_len;
	}

	if ((ret = ctr_drbg_update_internal(ctx, add_input)) != 0) {
		return (ret);
	}

	ctx->reseed_counter++;

	return (0);
}

int jhd_tls_ctr_drbg_random(void *p_rng, unsigned char *output, size_t output_len) {
	int ret;
	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;

	ret = jhd_tls_ctr_drbg_random_with_add(ctx, output, output_len, NULL, 0);

	return (ret);
}

int jhd_tls_random_init() {
	int ret;
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];
	jhd_tls_aes_context *aes_ctx;
	unsigned char seed[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT];
	size_t seedlen = 0;

	jhd_tls_platform_zeroize(&s_g_jhd_tls_ctr_drbg, sizeof(jhd_tls_ctr_drbg_context));
	jhd_tls_platform_zeroize(key, JHD_TLS_CTR_DRBG_KEYSIZE);
	aes_ctx = &s_g_jhd_tls_ctr_drbg.aes_ctx;

//	ctx->f_entropy = jhd_tls_entropy_func;

	s_g_jhd_tls_ctr_drbg.entropy_len = JHD_TLS_CTR_DRBG_ENTROPY_LEN;
	s_g_jhd_tls_ctr_drbg.reseed_interval = JHD_TLS_CTR_DRBG_RESEED_INTERVAL;

	/*
	 * Initialize with an empty key
	 */
	if ((ret = jhd_tls_aes_setkey_enc(aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		return (ret);
	}

	snprintf((char*)key, JHD_TLS_CTR_DRBG_KEYSIZE, "JHD_%d_%s123456789123456789123456789", jhd_pid, jhd_cache_log_time);
	key[JHD_TLS_CTR_DRBG_KEYSIZE - 1] = '?';

	memset(seed, 0, JHD_TLS_CTR_DRBG_MAX_SEED_INPUT);

	/*
	 * Gather entropy_len bytes of entropy to seed state
	 */
	if (0 != jhd_tls_entropy_func(&s_g_jhd_tls_ctr_drbg.entropy, seed, JHD_TLS_CTR_DRBG_ENTROPY_LEN)) {
		return ( JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED);
	}

	seedlen += JHD_TLS_CTR_DRBG_ENTROPY_LEN;

	memcpy(seed + seedlen, key, JHD_TLS_CTR_DRBG_KEYSIZE);
	seedlen += JHD_TLS_CTR_DRBG_KEYSIZE;

	/*
	 * Reduce to 384 bits
	 */
	if ((ret = block_cipher_df(seed, seed, seedlen)) != 0) {
		return (ret);
	}

	/*
	 * Update state
	 */
	if ((ret = ctr_drbg_update_internal(&s_g_jhd_tls_ctr_drbg, seed)) != 0) {
		return (ret);
	}
	s_g_jhd_tls_ctr_drbg.reseed_counter = 1;

	return (0);

}
#endif /* JHD_TLS_CTR_DRBG_C */
