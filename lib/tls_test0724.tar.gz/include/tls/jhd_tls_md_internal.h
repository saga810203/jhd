#ifndef JHD_TLS_MD_WRAP_H
#define JHD_TLS_MD_WRAP_H

#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_md.h>



struct jhd_tls_md_info_t
{
    /** Digest identifier */
    jhd_tls_md_type_t type;

    /** Name of the message digest */
    const char * name;

    /** Output length of the digest function in bytes */
    int size;

    /** Block length of the digest function in bytes */
    int block_size;

    /** Digest initialisation function */
    int (*starts_func)( void *ctx );

    /** Digest update function */
    int (*update_func)( void *ctx, const unsigned char *input, size_t ilen );

    /** Digest finalisation function */
    int (*finish_func)( void *ctx, unsigned char *output );

    /** Generic digest function */
    int (*digest_func)( const unsigned char *input, size_t ilen,unsigned char *output );

    /** Allocate a new context */
    void * (*ctx_alloc_func)( void );

    /** Free the given context */
    void (*ctx_free_func)( void *ctx );

    /** Clone state from a context */
    void (*clone_func)( void *dst, const void *src );

    /** Internal use only */
    int (*process_func)( void *ctx, const unsigned char *input );
};


extern const jhd_tls_md_info_t jhd_tls_md5_info;

#if defined(JHD_TLS_RIPEMD160_C)
extern const jhd_tls_md_info_t jhd_tls_ripemd160_info;
#endif
#if defined(JHD_TLS_SHA1_C)
extern const jhd_tls_md_info_t jhd_tls_sha1_info;
#endif
#if defined(JHD_TLS_SHA256_C)
extern const jhd_tls_md_info_t jhd_tls_sha224_info;
extern const jhd_tls_md_info_t jhd_tls_sha256_info;
#endif
#if defined(JHD_TLS_SHA512_C)
extern const jhd_tls_md_info_t jhd_tls_sha384_info;
extern const jhd_tls_md_info_t jhd_tls_sha512_info;
#endif



#endif /* JHD_TLS_MD_WRAP_H */
