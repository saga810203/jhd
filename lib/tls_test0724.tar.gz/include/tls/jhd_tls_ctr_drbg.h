#ifndef JHD_TLS_CTR_DRBG_H
#define JHD_TLS_CTR_DRBG_H

#include <tls/jhd_tls_aes.h>
#include <tls/jhd_tls_entropy.h>

#define JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED        -0x0034  /**< The entropy source failed. */
#define JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG              -0x0036  /**< The requested random buffer length is too big. */
#define JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG                -0x0038  /**< The input (entropy + additional data) is too large. */
#define JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR                -0x003A  /**< Read or write error in file. */

#define JHD_TLS_CTR_DRBG_BLOCKSIZE          16 /**< The block size used by the cipher. */
#define JHD_TLS_CTR_DRBG_KEYSIZE            32 /**< The key size used by the cipher. */
#define JHD_TLS_CTR_DRBG_KEYBITS            ( JHD_TLS_CTR_DRBG_KEYSIZE * 8 ) /**< The key size for the DRBG operation, in bits. */
#define JHD_TLS_CTR_DRBG_SEEDLEN            ( JHD_TLS_CTR_DRBG_KEYSIZE + JHD_TLS_CTR_DRBG_BLOCKSIZE ) /**< The seed length, calculated as (counter + AES key). */

/**
 * \name SECTION: Module settings
 *
 * The configuration options you can set for this module are in this section.
 * Either change them in config.h or define them using the compiler command
 * line.
 * \{
 */

#define JHD_TLS_CTR_DRBG_ENTROPY_LEN        48

#if !defined(JHD_TLS_CTR_DRBG_RESEED_INTERVAL)
#define JHD_TLS_CTR_DRBG_RESEED_INTERVAL    10000
/**< The interval before reseed is performed by default. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_INPUT)
#define JHD_TLS_CTR_DRBG_MAX_INPUT          256
/**< The maximum number of additional input Bytes. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_REQUEST)
#define JHD_TLS_CTR_DRBG_MAX_REQUEST        1024
/**< The maximum number of requested Bytes per call. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
#define JHD_TLS_CTR_DRBG_MAX_SEED_INPUT     384
/**< The maximum size of seed or reseed buffer. */
#endif

/* \} name SECTION: Module settings */

#define JHD_TLS_CTR_DRBG_PR_OFF             0
/**< Prediction resistance is disabled. */
#define JHD_TLS_CTR_DRBG_PR_ON              1
/**< Prediction resistance is enabled. */

/**
 * \brief          The CTR_DRBG context structure.
 */
typedef struct {
	unsigned char counter[16]; /*!< The counter (V). */
	int reseed_counter; /*!< The reseed counter. */
	int prediction_resistance; /*!< This determines whether prediction
	 resistance is enabled, that is
	 whether to systematically reseed before
	 each random generation. */
	size_t entropy_len; /*!< The amount of entropy grabbed on each
	 seed or reseed operation. */
	int reseed_interval; /*!< The reseed interval. */

	jhd_tls_aes_context aes_ctx; /*!< The AES context. */

	/*
	 * Callbacks (Entropy)
	 */
//	int (*f_entropy)(void *, unsigned char *, size_t);
	/*!< The entropy callback function. */

//	void *p_entropy; /*!< The context for the entropy function. */
	jhd_tls_entropy_context entropy;

} jhd_tls_ctr_drbg_context;

#if defined(JHD_TLS_INLINE)
#define jhd_tls_ctr_drbg_init(ctx) memset(ctx, 0, sizeof(jhd_tls_ctr_drbg_context))

#define jhd_tls_ctr_drbg_seed(ctx,custom,len) jhd_tls_ctr_drbg_seed_entropy_len(ctx,  custom, len,JHD_TLS_CTR_DRBG_ENTROPY_LEN)
#else

/**
 * \brief               This function initializes the CTR_DRBG context,
 *                      and prepares it for jhd_tls_ctr_drbg_seed()
 *                      or jhd_tls_ctr_drbg_free().
 *
 * \param ctx           The CTR_DRBG context to initialize.
 */
void jhd_tls_ctr_drbg_init(jhd_tls_ctr_drbg_context *ctx);

/**
 * \brief               This function seeds and sets up the CTR_DRBG
 *                      entropy source for future reseeds.
 *
 * \note Personalization data can be provided in addition to the more generic
 *       entropy source, to make this instantiation as unique as possible.
 *
 * \param ctx           The CTR_DRBG context to seed.
 * \param custom        Personalization data, that is device-specific
 identifiers. Can be NULL.
 * \param len           The length of the personalization data.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED on failure.
 */
int jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom, size_t len);
#endif

/**
 * \brief               This function reseeds the CTR_DRBG context, that is
 *                      extracts data from the entropy source.
 *
 * \param ctx           The CTR_DRBG context.
 * \param additional    Additional data to add to the state. Can be NULL.
 * \param len           The length of the additional data.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED on failure.
 */
int jhd_tls_ctr_drbg_reseed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t len);

/**
 * \brief              This function updates the state of the CTR_DRBG context.
 *
 * \note               If \p add_len is greater than
 *                     #JHD_TLS_CTR_DRBG_MAX_SEED_INPUT, only the first
 *                     #JHD_TLS_CTR_DRBG_MAX_SEED_INPUT Bytes are used.
 *                     The remaining Bytes are silently discarded.
 *
 * \param ctx          The CTR_DRBG context.
 * \param additional   The data to update the state with.
 * \param add_len      Length of \p additional data.
 *
 */
void jhd_tls_ctr_drbg_update(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t add_len);

/**
 * \brief   This function uses CTR_DRBG to generate random data.
 *
 * \note    The function automatically reseeds if the reseed counter is exceeded.
 *
 * \param p_rng         The CTR_DRBG context. This must be a pointer to a
 *                      #jhd_tls_ctr_drbg_context structure.
 * \param output        The buffer to fill.
 * \param output_len    The length of the buffer.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED or
 *                      #JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG on failure.
 */
int jhd_tls_ctr_drbg_random(void *p_rng, unsigned char *output, size_t output_len);

int jhd_tls_random_init();
extern jhd_tls_ctr_drbg_context s_g_jhd_tls_ctr_drbg;

#endif /* ctr_drbg.h */
