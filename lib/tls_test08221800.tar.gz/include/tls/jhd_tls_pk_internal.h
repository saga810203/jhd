#ifndef JHD_TLS_PK_WRAP_H
#define JHD_TLS_PK_WRAP_H


#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_pk.h>

#define JHD_TLS_SSL_SIG_ANON                 0
#define JHD_TLS_SSL_SIG_RSA                  1
#define JHD_TLS_SSL_SIG_ECDSA                3

struct jhd_tls_pk_info_t {
	/** Public key type */
	unsigned char pk_flag;
	/** Type name */
	const char *name;

	/** Get key size in bits */
	size_t (*get_bitlen)(const void *);
	/** Verify signature */
	int (*verify_func)(void *ctx, const jhd_tls_md_info_t *md_info, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len);

	/** Make signature */
	int (*sign_func)(void *ctx, const jhd_tls_md_info_t *md_info, const unsigned char *hash, size_t hash_len, unsigned char *sig, size_t *sig_len);

	/** Decrypt message */
	int (*decrypt_func)(void *ctx, const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, size_t osize);

	/** Encrypt message */
	int (*encrypt_func)(void *ctx, const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, size_t osize);

	/** Check public-private key pair */
	int (*check_pair_func)(const void *pub, const void *prv);

	/** Allocate a new context */
	void * (*ctx_alloc_func)(void);

	/** Free the given context */
	void (*ctx_free_func)(void *ctx);

	/** Interface with the debug module */
	void (*debug_func)(const void *ctx, jhd_tls_pk_debug_item *items);

};


extern const jhd_tls_pk_info_t jhd_tls_rsa_info;


//extern const jhd_tls_pk_info_t jhd_tls_eckey_info;
//extern const jhd_tls_pk_info_t jhd_tls_eckeydh_info;

extern const jhd_tls_pk_info_t jhd_tls_ecdsa_info;



#endif /* JHD_TLS_PK_WRAP_H */
