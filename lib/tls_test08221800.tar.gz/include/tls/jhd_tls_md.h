#ifndef JHD_TLS_MD_H
#define JHD_TLS_MD_H

#include <stddef.h>

#include <tls/jhd_tls_config.h>

/*
 * Supported Signature and Hash algorithms (For TLS 1.2)
 * RFC 5246 section 7.4.1.4.1
 */

#define JHD_TLS_SSL_HASH_NONE                0
#define JHD_TLS_SSL_HASH_MD5                 1
#define JHD_TLS_SSL_HASH_SHA1                2
#define JHD_TLS_SSL_HASH_SHA224              3
#define JHD_TLS_SSL_HASH_SHA256              4
#define JHD_TLS_SSL_HASH_SHA384              5
#define JHD_TLS_SSL_HASH_SHA512              6


#define JHD_TLS_ERR_MD_FEATURE_UNAVAILABLE                -0x5080  /**< The selected feature is not available. */
#define JHD_TLS_ERR_MD_BAD_INPUT_DATA                     -0x5100  /**< Bad input parameters to function. */
#define JHD_TLS_ERR_MD_ALLOC_FAILED                       -0x5180  /**< Failed to allocate memory. */
#define JHD_TLS_ERR_MD_FILE_IO_ERROR                      -0x5200  /**< Opening or reading of file failed. */
#define JHD_TLS_ERR_MD_HW_ACCEL_FAILED                    -0x5280  /**< MD hardware accelerator failed. */

///**
// * \brief     Supported message digests.
// *
// * \warning   MD2, MD4, MD5 and SHA-1 are considered weak message digests and
// *            their use constitutes a security risk. We recommend considering
// *            stronger message digests instead.
// *
// */
//typedef enum {
//	JHD_TLS_MD_NONE = 0, /**< None. */
//	JHD_TLS_MD_MD2, /**< The MD2 message digest. */
//	JHD_TLS_MD_MD4, /**< The MD4 message digest. */
//	JHD_TLS_MD_MD5, /**< The MD5 message digest. */
//	JHD_TLS_MD_SHA1, /**< The SHA-1 message digest. */
//	JHD_TLS_MD_SHA224, /**< The SHA-224 message digest. */
//	JHD_TLS_MD_SHA256, /**< The SHA-256 message digest. */
//	JHD_TLS_MD_SHA384, /**< The SHA-384 message digest. */
//	JHD_TLS_MD_SHA512, /**< The SHA-512 message digest. */
//	JHD_TLS_MD_RIPEMD160, /**< The RIPEMD-160 message digest. */
//} jhd_tls_md_type_t;

#define JHD_TLS_MD_MAX_SIZE         64  /* longest known is SHA512 */

/**
 * Opaque struct defined in md_internal.h.
 */
typedef struct jhd_tls_md_info_t jhd_tls_md_info_t;

/**
 * The generic message-digest context.
 */
typedef struct {
	/** Information about the associated message digest. */
	const jhd_tls_md_info_t *md_info;

	/** The digest-specific context. */
	void *md_ctx;

	/** The HMAC part of the context. */
	void *hmac_ctx;
} jhd_tls_md_context_t;

#if !defined(JHD_TLS_INLINE)




/**
 * \brief           This function extracts the message-digest size from the
 *                  message-digest information structure.
 *
 * \param md_info   The information structure of the message-digest algorithm
 *                  to use.
 *
 * \return          The size of the message-digest output in Bytes.
 */
unsigned char jhd_tls_md_get_size(const jhd_tls_md_info_t *md_info);

/**
 * \brief           This function extracts the message-digest name from the
 *                  message-digest information structure.
 *
 * \param md_info   The information structure of the message-digest algorithm
 *                  to use.
 *
 * \return          The name of the message digest.
 */
const char *jhd_tls_md_get_name(const jhd_tls_md_info_t *md_info);





/**
 * \brief           This function initializes a message-digest context without
 *                  binding it to a particular message-digest algorithm.
 *
 *                  This function should always be called first. It prepares the
 *                  context for jhd_tls_md_setup() for binding it to a
 *                  message-digest algorithm.
 */
void jhd_tls_md_init(jhd_tls_md_context_t *ctx);

/**
 * \brief           This function clears the internal structure of \p ctx and
 *                  frees any embedded internal structure, but does not free
 *                  \p ctx itself.
 *
 *                  If you have called jhd_tls_md_setup() on \p ctx, you must
 *                  call jhd_tls_md_free() when you are no longer using the
 *                  context.
 *                  Calling this function if you have previously
 *                  called jhd_tls_md_init() and nothing else is optional.
 *                  You must not call this function if you have not called
 *                  jhd_tls_md_init().
 */
void jhd_tls_md_free(jhd_tls_md_context_t *ctx);

/**
 * \brief           This function starts a message-digest computation.
 *
 *                  You must call this function after setting up the context
 *                  with jhd_tls_md_setup(), and before passing data with
 *                  jhd_tls_md_update().
 *
 * \param ctx       The generic message-digest context.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_starts(jhd_tls_md_context_t *ctx);

/**
 * \brief           This function feeds an input buffer into an ongoing
 *                  message-digest computation.
 *
 *                  You must call jhd_tls_md_starts() before calling this
 *                  function. You may call this function multiple times.
 *                  Afterwards, call jhd_tls_md_finish().
 *
 * \param ctx       The generic message-digest context.
 * \param input     The buffer holding the input data.
 * \param ilen      The length of the input data.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_update(jhd_tls_md_context_t *ctx, const unsigned char *input, size_t ilen);

/**
 * \brief           This function finishes the digest operation,
 *                  and writes the result to the output buffer.
 *
 *                  Call this function after a call to jhd_tls_md_starts(),
 *                  followed by any number of calls to jhd_tls_md_update().
 *                  Afterwards, you may either clear the context with
 *                  jhd_tls_md_free(), or call jhd_tls_md_starts() to reuse
 *                  the context for another digest operation with the same
 *                  algorithm.
 *
 * \param ctx       The generic message-digest context.
 * \param output    The buffer for the generic message-digest checksum result.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_finish(jhd_tls_md_context_t *ctx, unsigned char *output);

/**
 * \brief          This function calculates the message-digest of a buffer,
 *                 with respect to a configurable message-digest algorithm
 *                 in a single call.
 *
 *                 The result is calculated as
 *                 Output = message_digest(input buffer).
 *
 * \param md_info  The information structure of the message-digest algorithm
 *                 to use.
 * \param input    The buffer holding the data.
 * \param ilen     The length of the input data.
 * \param output   The generic message-digest checksum result.
 *
 * \return         \c 0 on success.
 * \return         #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                 failure.
 */
void jhd_tls_md(const jhd_tls_md_info_t *md_info, const unsigned char *input, size_t ilen, unsigned char *output);

/**
 * \brief           This function feeds an input buffer into an ongoing HMAC
 *                  computation.
 *
 *                  Call jhd_tls_md_hmac_starts() or jhd_tls_md_hmac_reset()
 *                  before calling this function.
 *                  You may call this function multiple times to pass the
 *                  input piecewise.
 *                  Afterwards, call jhd_tls_md_hmac_finish().
 *
 * \param ctx       The message digest context containing an embedded HMAC
 *                  context.
 * \param input     The buffer holding the input data.
 * \param ilen      The length of the input data.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_hmac_update(jhd_tls_md_context_t *ctx, const unsigned char *input, size_t ilen);
/**
 * \brief           This function prepares to authenticate a new message with
 *                  the same key as the previous HMAC operation.
 *
 *                  You may call this function after jhd_tls_md_hmac_finish().
 *                  Afterwards call jhd_tls_md_hmac_update() to pass the new
 *                  input.
 *
 * \param ctx       The message digest context containing an embedded HMAC
 *                  context.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_hmac_reset(jhd_tls_md_context_t *ctx);

/* Internal use */
void jhd_tls_md_process(jhd_tls_md_context_t *ctx, const unsigned char *data);

#else



#define jhd_tls_md_init(ctx ) jhd_tls_platform_zeroize(ctx,sizeof(jhd_tls_md_context_t))

#define jhd_tls_md_free(ctx)   \
	if((( jhd_tls_md_context_t *)(ctx))->md_info){	\
		((jhd_tls_md_context_t*)(ctx))->md_info->ctx_free_func((( jhd_tls_md_context_t *)(ctx))->md_ctx );\
		if((( jhd_tls_md_context_t *)(ctx))->hmac_ctx){jhd_tls_free( ((jhd_tls_md_context_t*)(ctx))->hmac_ctx );}		\
}

#define jhd_tls_md_starts( ctx ) (((jhd_tls_md_context_t*)(ctx))->md_info->starts_func( ((jhd_tls_md_context_t*)(ctx))->md_ctx ) )

#define jhd_tls_md_update( ctx, input,ilen )  (((jhd_tls_md_context_t*)(ctx))->md_info->update_func(  ((jhd_tls_md_context_t*)(ctx))->md_ctx, input, ilen))

#define jhd_tls_md_finish(ctx,output) (((jhd_tls_md_context_t*)(ctx))->md_info->finish_func(((jhd_tls_md_context_t*)(ctx))->md_ctx, output))

#define jhd_tls_md(md_info,input,ilen,output)   (((jhd_tls_md_info_t*)md_info)->digest_func(input, ilen, output))

#define jhd_tls_md_hmac_update(ctx,input,ilen)   (((jhd_tls_md_context_t*)(ctx))->md_info->update_func(((jhd_tls_md_context_t*)(ctx))->md_ctx, input, ilen))


#define jhd_tls_md_hmac_reset(ctx)  ((jhd_tls_md_context_t*)(ctx))->md_info->starts_func(((jhd_tls_md_context_t*)(ctx))->md_ctx);  \
	(((jhd_tls_md_context_t*)(ctx))->md_info->update_func(((jhd_tls_md_context_t*)(ctx))->md_ctx, (unsigned char *) ((jhd_tls_md_context_t*)(ctx))->hmac_ctx, ((jhd_tls_md_context_t*)(ctx))->md_info->block_size))

#define jhd_tls_md_process(ctx,data)  (((jhd_tls_md_context_t*)(ctx))->md_info->process_func(((jhd_tls_md_context_t*)(ctx))->md_ctx, data))


#define jhd_tls_md_get_size(md_info)  ((unsigned char)(((jhd_tls_md_info*)(md_info))->size))


#define jhd_tls_md_get_name(md_info) (NULL==(md_info)?(JHD_TLS_MD_NONE):((jhd_tls_md_info_t*)(md_info))->name)


#endif

/**
 * \brief           This function selects the message digest algorithm to use,
 *                  and allocates internal structures.
 *
 *                  It should be called after jhd_tls_md_init() or
 *                  jhd_tls_md_free(). Makes it necessary to call
 *                  jhd_tls_md_free() later.
 *
 * \param ctx       The context to set up.
 * \param md_info   The information structure of the message-digest algorithm
 *                  to use.
 * \param hmac      Defines if HMAC is used. 0: HMAC is not used (saves some memory),
 *                  or non-zero: HMAC is used with this context.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 * \return          #JHD_TLS_ERR_MD_ALLOC_FAILED on memory-allocation failure.
 */
int jhd_tls_md_setup(jhd_tls_md_context_t *ctx, const jhd_tls_md_info_t *md_info, int hmac);




/**
 * \brief           This function sets the HMAC key and prepares to
 *                  authenticate a new message.
 *
 *                  Call this function after jhd_tls_md_setup(), to use
 *                  the MD context for an HMAC calculation, then call
 *                  jhd_tls_md_hmac_update() to provide the input data, and
 *                  jhd_tls_md_hmac_finish() to get the HMAC value.
 *
 * \param ctx       The message digest context containing an embedded HMAC
 *                  context.
 * \param key       The HMAC secret key.
 * \param keylen    The length of the HMAC key in Bytes.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_hmac_starts(jhd_tls_md_context_t *ctx, const unsigned char *key, size_t keylen);



/**
 * \brief           This function finishes the HMAC operation, and writes
 *                  the result to the output buffer.
 *
 *                  Call this function after jhd_tls_md_hmac_starts() and
 *                  jhd_tls_md_hmac_update() to get the HMAC value. Afterwards
 *                  you may either call jhd_tls_md_free() to clear the context,
 *                  or call jhd_tls_md_hmac_reset() to reuse the context with
 *                  the same HMAC key.
 *
 * \param ctx       The message digest context containing an embedded HMAC
 *                  context.
 * \param output    The generic HMAC checksum result.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                  failure.
 */
void jhd_tls_md_hmac_finish(jhd_tls_md_context_t *ctx, unsigned char *output);



/**
 * \brief          This function calculates the full generic HMAC
 *                 on the input buffer with the provided key.
 *
 *                 The function allocates the context, performs the
 *                 calculation, and frees the context.
 *
 *                 The HMAC result is calculated as
 *                 output = generic HMAC(hmac key, input buffer).
 *
 * \param md_info  The information structure of the message-digest algorithm
 *                 to use.
 * \param key      The HMAC secret key.
 * \param keylen   The length of the HMAC secret key in Bytes.
 * \param input    The buffer holding the input data.
 * \param ilen     The length of the input data.
 * \param output   The generic HMAC result.
 *
 * \return         \c 0 on success.
 * \return         #JHD_TLS_ERR_MD_BAD_INPUT_DATA on parameter-verification
 *                 failure.
 */
int jhd_tls_md_hmac(const jhd_tls_md_info_t *md_info, const unsigned char *key, size_t keylen, const unsigned char *input, size_t ilen, unsigned char *output);



#if defined(JHD_TLS_INLINE)
extern int* supported_digests;
#endif

#endif /* JHD_TLS_MD_H */
