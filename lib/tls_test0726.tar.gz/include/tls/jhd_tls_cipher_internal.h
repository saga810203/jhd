#ifndef JHD_TLS_CIPHER_WRAP_H
#define JHD_TLS_CIPHER_WRAP_H


#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_cipher.h>

#include <tls/jhd_tls_cipher.h>

/**
 * Base cipher information. The non-mode specific functions and values.
 */
struct jhd_tls_cipher_base_t {
	/** Base Cipher type (e.g. JHD_TLS_CIPHER_ID_AES) */
	jhd_tls_cipher_id_t cipher;

	/** Encrypt using ECB */
	jhd_tls_cipher_ecb_pt ecb_func;

#if defined(JHD_TLS_CIPHER_MODE_CBC)
	/** Encrypt using CBC */
	jhd_tls_cipher_cbc_pt cbc_func;
#endif

#if defined(JHD_TLS_CIPHER_MODE_CFB)
	/** Encrypt using CFB (Full length) */
	jhd_tls_cipher_cfb_pt cfb_func;
#endif

#if defined(JHD_TLS_CIPHER_MODE_OFB)
	/** Encrypt using OFB (Full length) */
	jhd_tls_cipher_ofb_pt ofb_func;
#endif

#if defined(JHD_TLS_CIPHER_MODE_CTR)
	/** Encrypt using CTR */
	jhd_tls_cipher_ctr_pt ctr_func;
#endif

	/** Encrypt or decrypt using XTS. */
	jhd_tls_cipher_xts_pt xts_func;

#if defined(JHD_TLS_CIPHER_MODE_STREAM)
	/** Encrypt using STREAM */
	jhd_tls_cipher_stream_pt stream_func;
#endif

	/** Set key for encryption purposes */
	jhd_tls_cipher_setkey_enc_pt setkey_enc_func;

	/** Set key for decryption purposes */
	jhd_tls_cipher_setkey_dec_pt setkey_dec_func;

	/** Allocate a new context */
	jhd_tls_cipher_ctx_alloc_pt ctx_alloc_func;

	/** Free the given context */
	jhd_tls_cipher_ctx_free_pt ctx_free_func;

};

typedef struct {
	jhd_tls_cipher_type_t type;
	const jhd_tls_cipher_info_t *info;
} jhd_tls_cipher_definition_t;

extern const jhd_tls_cipher_definition_t jhd_tls_cipher_definitions[];

extern int jhd_tls_cipher_supported[];

#endif /* JHD_TLS_CIPHER_WRAP_H */
