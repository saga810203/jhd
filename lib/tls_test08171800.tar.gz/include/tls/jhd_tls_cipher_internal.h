#ifndef JHD_TLS_CIPHER_WRAP_H
#define JHD_TLS_CIPHER_WRAP_H


#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_cipher.h>

#include <tls/jhd_tls_cipher.h>

/**
 * Base cipher information. The non-mode specific functions and values.
 */
struct jhd_tls_cipher_base_t {
	jhd_tls_cipher_id_t cipher;
	jhd_tls_cipher_ecb_pt ecb_func;
	jhd_tls_cipher_cbc_pt cbc_func;
	jhd_tls_cipher_setkey_enc_pt setkey_enc_func;
	jhd_tls_cipher_setkey_dec_pt setkey_dec_func;
	jhd_tls_cipher_ctx_alloc_pt ctx_alloc_func;
	jhd_tls_cipher_ctx_free_pt ctx_free_func;
};

typedef struct {
	jhd_tls_cipher_type_t type;
	const jhd_tls_cipher_info_t *info;
} jhd_tls_cipher_definition_t;

extern const jhd_tls_cipher_definition_t jhd_tls_cipher_definitions[];

extern int jhd_tls_cipher_supported[];

#endif /* JHD_TLS_CIPHER_WRAP_H */
