#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_pk_internal.h>

/* Even if RSA not activated, for the sake of RSA-alt */
#include <tls/jhd_tls_rsa.h>

#include <string.h>


#include <tls/jhd_tls_ecp.h>


#include <tls/jhd_tls_ecdsa.h>

#include <tls/jhd_tls_platform.h>

#include <limits.h>
#include <stdint.h>

static inline int rsa_can_do(jhd_tls_pk_type_t type) {
	return (type == JHD_TLS_PK_RSA);
}

static size_t rsa_get_bitlen(const void *ctx) {
	const jhd_tls_rsa_context * rsa = (const jhd_tls_rsa_context *) ctx;
	return (8 * jhd_tls_rsa_get_len(rsa));
}

static int rsa_verify_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len) {
	int ret;
	jhd_tls_rsa_context * rsa = (jhd_tls_rsa_context *) ctx;
	size_t rsa_len = jhd_tls_rsa_get_len(rsa);

#if SIZE_MAX > UINT_MAX
	if( md_alg == JHD_TLS_MD_NONE && UINT_MAX < hash_len )
	return( JHD_TLS_ERR_PK_BAD_INPUT_DATA );
#endif /* SIZE_MAX > UINT_MAX */

	if (sig_len < rsa_len)
		return ( JHD_TLS_ERR_RSA_VERIFY_FAILED);

	if ((ret = jhd_tls_rsa_pkcs1_verify(rsa,
	JHD_TLS_RSA_PUBLIC, md_alg, (unsigned int) hash_len, hash, sig)) != 0)
		return (ret);

	/* The buffer contains a valid signature followed by extra data.
	 * We have a special error code for that so that so that callers can
	 * use jhd_tls_pk_verify() to check "Does the buffer start with a
	 * valid signature?" and not just "Does the buffer contain a valid
	 * signature?". */
	if (sig_len > rsa_len)
		return ( JHD_TLS_ERR_PK_SIG_LEN_MISMATCH);

	return (0);
}

static int rsa_sign_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, unsigned char *sig, size_t *sig_len) {
	jhd_tls_rsa_context * rsa = (jhd_tls_rsa_context *) ctx;

#if SIZE_MAX > UINT_MAX
	if( md_alg == JHD_TLS_MD_NONE && UINT_MAX < hash_len )
	return( JHD_TLS_ERR_PK_BAD_INPUT_DATA );
#endif /* SIZE_MAX > UINT_MAX */

	*sig_len = jhd_tls_rsa_get_len(rsa);

	return (jhd_tls_rsa_pkcs1_sign(rsa, JHD_TLS_RSA_PRIVATE, md_alg, (unsigned int) hash_len, hash, sig));
}

static int rsa_decrypt_wrap(void *ctx, const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, size_t osize) {
	jhd_tls_rsa_context * rsa = (jhd_tls_rsa_context *) ctx;

	if (ilen != jhd_tls_rsa_get_len(rsa))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	return (jhd_tls_rsa_pkcs1_decrypt(rsa,
	JHD_TLS_RSA_PRIVATE, olen, input, output, osize));
}

static int rsa_encrypt_wrap(void *ctx, const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, size_t osize) {
	jhd_tls_rsa_context * rsa = (jhd_tls_rsa_context *) ctx;
	*olen = jhd_tls_rsa_get_len(rsa);

	if (*olen > osize)
		return ( JHD_TLS_ERR_RSA_OUTPUT_TOO_LARGE);

	return (jhd_tls_rsa_pkcs1_encrypt(rsa, JHD_TLS_RSA_PUBLIC, ilen, input, output));
}

static int rsa_check_pair_wrap(const void *pub, const void *prv) {
	return (jhd_tls_rsa_check_pub_priv((const jhd_tls_rsa_context *) pub, (const jhd_tls_rsa_context *) prv));
}

static void *rsa_alloc_wrap(void) {
	void *ctx = jhd_tls_malloc(sizeof(jhd_tls_rsa_context));

	if (ctx != NULL)
		jhd_tls_rsa_init((jhd_tls_rsa_context *) ctx, 0, 0);

	return (ctx);
}

static void rsa_free_wrap(void *ctx) {
	jhd_tls_rsa_free((jhd_tls_rsa_context *) ctx);
	jhd_tls_free(ctx);
}

static void rsa_debug(const void *ctx, jhd_tls_pk_debug_item *items) {
	items->type = JHD_TLS_PK_DEBUG_MPI;
	items->name = "rsa.N";
	items->value = &(((jhd_tls_rsa_context *) ctx)->N);

	items++;

	items->type = JHD_TLS_PK_DEBUG_MPI;
	items->name = "rsa.E";
	items->value = &(((jhd_tls_rsa_context *) ctx)->E);
}

const jhd_tls_pk_info_t jhd_tls_rsa_info = { JHD_TLS_PK_RSA, "RSA", rsa_get_bitlen, rsa_can_do, rsa_verify_wrap, rsa_sign_wrap, rsa_decrypt_wrap,
        rsa_encrypt_wrap, rsa_check_pair_wrap, rsa_alloc_wrap, rsa_free_wrap, rsa_debug, };


/*
 * Generic EC key
 */
static inline int eckey_can_do(jhd_tls_pk_type_t type) {
	return (type == JHD_TLS_PK_ECDSA);
}

static size_t eckey_get_bitlen(const void *ctx) {
	return (((jhd_tls_ecp_keypair *) ctx)->grp.pbits);
}

/* Forward declarations */
static int ecdsa_verify_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len);

static int ecdsa_sign_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, unsigned char *sig, size_t *sig_len);

static int eckey_verify_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len) {
	int ret;
	jhd_tls_ecdsa_context ecdsa;

	jhd_tls_ecdsa_init(&ecdsa);

	if ((ret = jhd_tls_ecdsa_from_keypair(&ecdsa, ctx)) == 0)
		ret = ecdsa_verify_wrap(&ecdsa, md_alg, hash, hash_len, sig, sig_len);

	jhd_tls_ecdsa_free(&ecdsa);

	return (ret);
}

static int eckey_sign_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, unsigned char *sig, size_t *sig_len) {
	int ret;
	jhd_tls_ecdsa_context ecdsa;

	jhd_tls_ecdsa_init(&ecdsa);

	if ((ret = jhd_tls_ecdsa_from_keypair(&ecdsa, ctx)) == 0)
		ret = ecdsa_sign_wrap(&ecdsa, md_alg, hash, hash_len, sig, sig_len);

	jhd_tls_ecdsa_free(&ecdsa);

	return (ret);
}

static int eckey_check_pair(const void *pub, const void *prv) {
	return (jhd_tls_ecp_check_pub_priv((const jhd_tls_ecp_keypair *) pub, (const jhd_tls_ecp_keypair *) prv));
}

static void *eckey_alloc_wrap(void) {
	void *ctx = jhd_tls_malloc(sizeof(jhd_tls_ecp_keypair));

	if (ctx != NULL)
		jhd_tls_ecp_keypair_init(ctx);

	return (ctx);
}

static void eckey_free_wrap(void *ctx) {
	jhd_tls_ecp_keypair_free((jhd_tls_ecp_keypair *) ctx);
	jhd_tls_free(ctx);
}

static void eckey_debug(const void *ctx, jhd_tls_pk_debug_item *items) {
	items->type = JHD_TLS_PK_DEBUG_ECP;
	items->name = "eckey.Q";
	items->value = &(((jhd_tls_ecp_keypair *) ctx)->Q);
}








static int ecdsa_can_do(jhd_tls_pk_type_t type) {
	return (type == JHD_TLS_PK_ECDSA);
}

static int ecdsa_verify_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len) {
	int ret;
	((void) md_alg);

	ret = jhd_tls_ecdsa_read_signature((jhd_tls_ecdsa_context *) ctx, hash, hash_len, sig, sig_len);

	if (ret == JHD_TLS_ERR_ECP_SIG_LEN_MISMATCH)
		return ( JHD_TLS_ERR_PK_SIG_LEN_MISMATCH);

	return (ret);
}

static int ecdsa_sign_wrap(void *ctx, jhd_tls_md_type_t md_alg, const unsigned char *hash, size_t hash_len, unsigned char *sig, size_t *sig_len) {
	return (jhd_tls_ecdsa_write_signature((jhd_tls_ecdsa_context *) ctx, md_alg, hash, hash_len, sig, sig_len));
}

static void *ecdsa_alloc_wrap(void) {
	void *ctx = jhd_tls_malloc(sizeof(jhd_tls_ecdsa_context));

	if (ctx != NULL)
		jhd_tls_ecdsa_init((jhd_tls_ecdsa_context *) ctx);

	return (ctx);
}

static void ecdsa_free_wrap(void *ctx) {
	jhd_tls_ecdsa_free((jhd_tls_ecdsa_context *) ctx);
	jhd_tls_free(ctx);
}

const jhd_tls_pk_info_t jhd_tls_ecdsa_info = { JHD_TLS_PK_ECDSA, "ECDSA", eckey_get_bitlen, /* Compatible key structures */
ecdsa_can_do, ecdsa_verify_wrap, ecdsa_sign_wrap,
NULL,
NULL, eckey_check_pair, /* Compatible key structures */
ecdsa_alloc_wrap, ecdsa_free_wrap, eckey_debug, /* Compatible key structures */
};


