#include <tls/jhd_tls_config.h>
  unsigned char* 		jhd_cache_log_time;
   unsigned char* 		jhd_cache_http_date;
  uint64_t      	jhd_current_msec;
  time_t			jhd_cache_time;
  pid_t jhd_pid;



