#include <tls/jhd_tls_config.h>

void jhd_tls_noop_free(void*  ptr){}

