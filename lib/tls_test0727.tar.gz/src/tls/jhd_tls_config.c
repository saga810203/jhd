#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_ssl_ciphersuites.h>
#include <tls/jhd_tls_ctr_drbg.h>


int jhd_tls_config_init(){
	int ret= 0;
	jhd_tls_ssl_ciphersuites_init();
	jhd_tls_random_init();
	return ret;
}
