
#include <tls/jhd_tls_config.h>

#if defined(JHD_TLS_PLATFORM_C)

#include <tls/jhd_tls_platform.h>


#if defined(JHD_TLS_PLATFORM_MEMORY)
#if !defined(JHD_TLS_PLATFORM_STD_CALLOC)
static void *platform_calloc_uninit( size_t n, size_t size )
{
    ((void) n);
    ((void) size);
    return( NULL );
}

#define JHD_TLS_PLATFORM_STD_CALLOC   platform_calloc_uninit
#endif /* !JHD_TLS_PLATFORM_STD_CALLOC */

#if !defined(JHD_TLS_PLATFORM_STD_FREE)
static void platform_free_uninit( void *ptr )
{
    ((void) ptr);
}

#define JHD_TLS_PLATFORM_STD_FREE     platform_free_uninit
#endif /* !JHD_TLS_PLATFORM_STD_FREE */

static void * (*jhd_tls_calloc_func)( size_t, size_t ) = JHD_TLS_PLATFORM_STD_CALLOC;
static void (*jhd_tls_free_func)( void * ) = JHD_TLS_PLATFORM_STD_FREE;

void * jhd_tls_calloc( size_t nmemb, size_t size )
{
    return (*jhd_tls_calloc_func)( nmemb, size );
}

void jhd_tls_free( void * ptr )
{
    (*jhd_tls_free_func)( ptr );
}

int jhd_tls_platform_set_calloc_free( void * (*calloc_func)( size_t, size_t ),
                              void (*free_func)( void * ) )
{
    jhd_tls_calloc_func = calloc_func;
    jhd_tls_free_func = free_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_MEMORY */

#if defined(_WIN32)
#include <stdarg.h>
int jhd_tls_platform_win32_snprintf( char *s, size_t n, const char *fmt, ... )
{
    int ret;
    va_list argp;

    /* Avoid calling the invalid parameter handler by checking ourselves */
    if( s == NULL || n == 0 || fmt == NULL )
        return( -1 );

    va_start( argp, fmt );
#if defined(_TRUNCATE) && !defined(__MINGW32__)
    ret = _vsnprintf_s( s, n, _TRUNCATE, fmt, argp );
#else
    ret = _vsnprintf( s, n, fmt, argp );
    if( ret < 0 || (size_t) ret == n )
    {
        s[n-1] = '\0';
        ret = -1;
    }
#endif
    va_end( argp );

    return( ret );
}
#endif

#if defined(JHD_TLS_PLATFORM_SNPRINTF_ALT)
#if !defined(JHD_TLS_PLATFORM_STD_SNPRINTF)
/*
 * Make dummy function to prevent NULL pointer dereferences
 */
static int platform_snprintf_uninit( char * s, size_t n,
                                     const char * format, ... )
{
    ((void) s);
    ((void) n);
    ((void) format);
    return( 0 );
}

#define JHD_TLS_PLATFORM_STD_SNPRINTF    platform_snprintf_uninit
#endif /* !JHD_TLS_PLATFORM_STD_SNPRINTF */

int (*jhd_tls_snprintf)( char * s, size_t n,
                          const char * format,
                          ... ) = JHD_TLS_PLATFORM_STD_SNPRINTF;

int jhd_tls_platform_set_snprintf( int (*snprintf_func)( char * s, size_t n,
                                                 const char * format,
                                                 ... ) )
{
    jhd_tls_snprintf = snprintf_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_SNPRINTF_ALT */

#if defined(JHD_TLS_PLATFORM_PRINTF_ALT)
#if !defined(JHD_TLS_PLATFORM_STD_PRINTF)
/*
 * Make dummy function to prevent NULL pointer dereferences
 */
static int platform_printf_uninit( const char *format, ... )
{
    ((void) format);
    return( 0 );
}

#define JHD_TLS_PLATFORM_STD_PRINTF    platform_printf_uninit
#endif /* !JHD_TLS_PLATFORM_STD_PRINTF */

int (*jhd_tls_printf)( const char *, ... ) = JHD_TLS_PLATFORM_STD_PRINTF;

int jhd_tls_platform_set_printf( int (*printf_func)( const char *, ... ) )
{
    jhd_tls_printf = printf_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_PRINTF_ALT */

#if defined(JHD_TLS_PLATFORM_FPRINTF_ALT)
#if !defined(JHD_TLS_PLATFORM_STD_FPRINTF)
/*
 * Make dummy function to prevent NULL pointer dereferences
 */
static int platform_fprintf_uninit( FILE *stream, const char *format, ... )
{
    ((void) stream);
    ((void) format);
    return( 0 );
}

#define JHD_TLS_PLATFORM_STD_FPRINTF   platform_fprintf_uninit
#endif /* !JHD_TLS_PLATFORM_STD_FPRINTF */

int (*jhd_tls_fprintf)( FILE *, const char *, ... ) =
                                        JHD_TLS_PLATFORM_STD_FPRINTF;

int jhd_tls_platform_set_fprintf( int (*fprintf_func)( FILE *, const char *, ... ) )
{
    jhd_tls_fprintf = fprintf_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_FPRINTF_ALT */

#if defined(JHD_TLS_PLATFORM_EXIT_ALT)
#if !defined(JHD_TLS_PLATFORM_STD_EXIT)
/*
 * Make dummy function to prevent NULL pointer dereferences
 */
static void platform_exit_uninit( int status )
{
    ((void) status);
}

#define JHD_TLS_PLATFORM_STD_EXIT   platform_exit_uninit
#endif /* !JHD_TLS_PLATFORM_STD_EXIT */

void (*jhd_tls_exit)( int status ) = JHD_TLS_PLATFORM_STD_EXIT;

int jhd_tls_platform_set_exit( void (*exit_func)( int status ) )
{
    jhd_tls_exit = exit_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_EXIT_ALT */

#if defined(JHD_TLS_HAVE_TIME)

#if defined(JHD_TLS_PLATFORM_TIME_ALT)
#if !defined(JHD_TLS_PLATFORM_STD_TIME)
/*
 * Make dummy function to prevent NULL pointer dereferences
 */
static jhd_tls_time_t platform_time_uninit( jhd_tls_time_t* timer )
{
    ((void) timer);
    return( 0 );
}

#define JHD_TLS_PLATFORM_STD_TIME   platform_time_uninit
#endif /* !JHD_TLS_PLATFORM_STD_TIME */

jhd_tls_time_t (*jhd_tls_time)( jhd_tls_time_t* timer ) = JHD_TLS_PLATFORM_STD_TIME;

int jhd_tls_platform_set_time( jhd_tls_time_t (*time_func)( jhd_tls_time_t* timer ) )
{
    jhd_tls_time = time_func;
    return( 0 );
}
#endif /* JHD_TLS_PLATFORM_TIME_ALT */

#endif /* JHD_TLS_HAVE_TIME */


#if !defined(JHD_TLS_PLATFORM_SETUP_TEARDOWN_ALT)
/*
 * Placeholder platform setup that does nothing by default
 */
int jhd_tls_platform_setup( jhd_tls_platform_context *ctx )
{
    (void)ctx;

    return( 0 );
}

/*
 * Placeholder platform teardown that does nothing by default
 */
void jhd_tls_platform_teardown( jhd_tls_platform_context *ctx )
{
    (void)ctx;
}
#endif /* JHD_TLS_PLATFORM_SETUP_TEARDOWN_ALT */

#endif /* JHD_TLS_PLATFORM_C */
