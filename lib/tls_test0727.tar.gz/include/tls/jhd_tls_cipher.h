#ifndef JHD_TLS_CIPHER_H
#define JHD_TLS_CIPHER_H

#include <tls/jhd_tls_config.h>

#include <stddef.h>

#define JHD_TLS_CIPHER_MODE_AEAD


#define JHD_TLS_CIPHER_MODE_WITH_PADDING

#if ( defined(__ARMCC_VERSION) || defined(_MSC_VER) ) && \
    !defined(inline) && !defined(__cplusplus)
#define inline __inline
#endif

#define JHD_TLS_ERR_CIPHER_FEATURE_UNAVAILABLE  -0x6080  /**< The selected feature is not available. */
#define JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA       -0x6100  /**< Bad input parameters. */
#define JHD_TLS_ERR_CIPHER_ALLOC_FAILED         -0x6180  /**< Failed to allocate memory. */
#define JHD_TLS_ERR_CIPHER_INVALID_PADDING      -0x6200  /**< Input data contains invalid padding and is rejected. */
#define JHD_TLS_ERR_CIPHER_FULL_BLOCK_EXPECTED  -0x6280  /**< Decryption of block requires a full block. */
#define JHD_TLS_ERR_CIPHER_AUTH_FAILED          -0x6300  /**< Authentication failed (for AEAD modes). */
#define JHD_TLS_ERR_CIPHER_INVALID_CONTEXT      -0x6380  /**< The context is invalid. For example, because it was freed. */
#define JHD_TLS_ERR_CIPHER_HW_ACCEL_FAILED      -0x6400  /**< Cipher hardware accelerator failed. */

#define JHD_TLS_CIPHER_VARIABLE_IV_LEN     0x01    /**< Cipher accepts IVs of variable length. */
#define JHD_TLS_CIPHER_VARIABLE_KEY_LEN    0x02    /**< Cipher accepts keys of variable length. */

/**
 * \brief     Supported cipher types.
 *
 * \warning   RC4 and DES are considered weak ciphers and their use
 *            constitutes a security risk. Arm recommends considering stronger
 *            ciphers instead.
 */
typedef enum {
	JHD_TLS_CIPHER_ID_NONE = 0, /**< Placeholder to mark the end of cipher ID lists. */
	JHD_TLS_CIPHER_ID_NULL, /**< The identity cipher, treated as a stream cipher. */
	JHD_TLS_CIPHER_ID_AES, /**< The AES cipher. */
	JHD_TLS_CIPHER_ID_DES, /**< The DES cipher. */
	JHD_TLS_CIPHER_ID_3DES, /**< The Triple DES cipher. */
	JHD_TLS_CIPHER_ID_CAMELLIA, /**< The Camellia cipher. */
	JHD_TLS_CIPHER_ID_BLOWFISH, /**< The Blowfish cipher. */
	JHD_TLS_CIPHER_ID_ARC4, /**< The RC4 cipher. */
	JHD_TLS_CIPHER_ID_ARIA, /**< The Aria cipher. */
} jhd_tls_cipher_id_t;

/**
 * \brief     Supported {cipher type, cipher mode} pairs.
 *
 * \warning   RC4 and DES are considered weak ciphers and their use
 *            constitutes a security risk. Arm recommends considering stronger
 *            ciphers instead.
 */
typedef enum {
	JHD_TLS_CIPHER_NONE = 0, /**< Placeholder to mark the end of cipher-pair lists. */
	JHD_TLS_CIPHER_NULL, /**< The identity stream cipher. */
	JHD_TLS_CIPHER_AES_128_ECB, /**< AES cipher with 128-bit ECB mode. */
	JHD_TLS_CIPHER_AES_192_ECB, /**< AES cipher with 192-bit ECB mode. */
	JHD_TLS_CIPHER_AES_256_ECB, /**< AES cipher with 256-bit ECB mode. */
	JHD_TLS_CIPHER_AES_128_CBC, /**< AES cipher with 128-bit CBC mode. */
	JHD_TLS_CIPHER_AES_192_CBC, /**< AES cipher with 192-bit CBC mode. */
	JHD_TLS_CIPHER_AES_256_CBC, /**< AES cipher with 256-bit CBC mode. */
	JHD_TLS_CIPHER_AES_128_CFB128, /**< AES cipher with 128-bit CFB128 mode. */
	JHD_TLS_CIPHER_AES_192_CFB128, /**< AES cipher with 192-bit CFB128 mode. */
	JHD_TLS_CIPHER_AES_256_CFB128, /**< AES cipher with 256-bit CFB128 mode. */
	JHD_TLS_CIPHER_AES_128_CTR, /**< AES cipher with 128-bit CTR mode. */
	JHD_TLS_CIPHER_AES_192_CTR, /**< AES cipher with 192-bit CTR mode. */
	JHD_TLS_CIPHER_AES_256_CTR, /**< AES cipher with 256-bit CTR mode. */
	JHD_TLS_CIPHER_AES_128_GCM, /**< AES cipher with 128-bit GCM mode. */
	JHD_TLS_CIPHER_AES_192_GCM, /**< AES cipher with 192-bit GCM mode. */
	JHD_TLS_CIPHER_AES_256_GCM, /**< AES cipher with 256-bit GCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_ECB, /**< Camellia cipher with 128-bit ECB mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_ECB, /**< Camellia cipher with 192-bit ECB mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_ECB, /**< Camellia cipher with 256-bit ECB mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_CBC, /**< Camellia cipher with 128-bit CBC mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_CBC, /**< Camellia cipher with 192-bit CBC mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_CBC, /**< Camellia cipher with 256-bit CBC mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_CFB128, /**< Camellia cipher with 128-bit CFB128 mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_CFB128, /**< Camellia cipher with 192-bit CFB128 mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_CFB128, /**< Camellia cipher with 256-bit CFB128 mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_CTR, /**< Camellia cipher with 128-bit CTR mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_CTR, /**< Camellia cipher with 192-bit CTR mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_CTR, /**< Camellia cipher with 256-bit CTR mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_GCM, /**< Camellia cipher with 128-bit GCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_GCM, /**< Camellia cipher with 192-bit GCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_GCM, /**< Camellia cipher with 256-bit GCM mode. */
	JHD_TLS_CIPHER_DES_ECB, /**< DES cipher with ECB mode. */
	JHD_TLS_CIPHER_DES_CBC, /**< DES cipher with CBC mode. */
	JHD_TLS_CIPHER_DES_EDE_ECB, /**< DES cipher with EDE ECB mode. */
	JHD_TLS_CIPHER_DES_EDE_CBC, /**< DES cipher with EDE CBC mode. */
	JHD_TLS_CIPHER_DES_EDE3_ECB, /**< DES cipher with EDE3 ECB mode. */
	JHD_TLS_CIPHER_DES_EDE3_CBC, /**< DES cipher with EDE3 CBC mode. */
	JHD_TLS_CIPHER_BLOWFISH_ECB, /**< Blowfish cipher with ECB mode. */
	JHD_TLS_CIPHER_BLOWFISH_CBC, /**< Blowfish cipher with CBC mode. */
	JHD_TLS_CIPHER_BLOWFISH_CFB64, /**< Blowfish cipher with CFB64 mode. */
	JHD_TLS_CIPHER_BLOWFISH_CTR, /**< Blowfish cipher with CTR mode. */
	JHD_TLS_CIPHER_ARC4_128, /**< RC4 cipher with 128-bit mode. */
	JHD_TLS_CIPHER_AES_128_CCM, /**< AES cipher with 128-bit CCM mode. */
	JHD_TLS_CIPHER_AES_192_CCM, /**< AES cipher with 192-bit CCM mode. */
	JHD_TLS_CIPHER_AES_256_CCM, /**< AES cipher with 256-bit CCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_128_CCM, /**< Camellia cipher with 128-bit CCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_192_CCM, /**< Camellia cipher with 192-bit CCM mode. */
	JHD_TLS_CIPHER_CAMELLIA_256_CCM, /**< Camellia cipher with 256-bit CCM mode. */
	JHD_TLS_CIPHER_ARIA_128_ECB, /**< Aria cipher with 128-bit key and ECB mode. */
	JHD_TLS_CIPHER_ARIA_192_ECB, /**< Aria cipher with 192-bit key and ECB mode. */
	JHD_TLS_CIPHER_ARIA_256_ECB, /**< Aria cipher with 256-bit key and ECB mode. */
	JHD_TLS_CIPHER_ARIA_128_CBC, /**< Aria cipher with 128-bit key and CBC mode. */
	JHD_TLS_CIPHER_ARIA_192_CBC, /**< Aria cipher with 192-bit key and CBC mode. */
	JHD_TLS_CIPHER_ARIA_256_CBC, /**< Aria cipher with 256-bit key and CBC mode. */
	JHD_TLS_CIPHER_ARIA_128_CFB128, /**< Aria cipher with 128-bit key and CFB-128 mode. */
	JHD_TLS_CIPHER_ARIA_192_CFB128, /**< Aria cipher with 192-bit key and CFB-128 mode. */
	JHD_TLS_CIPHER_ARIA_256_CFB128, /**< Aria cipher with 256-bit key and CFB-128 mode. */
	JHD_TLS_CIPHER_ARIA_128_CTR, /**< Aria cipher with 128-bit key and CTR mode. */
	JHD_TLS_CIPHER_ARIA_192_CTR, /**< Aria cipher with 192-bit key and CTR mode. */
	JHD_TLS_CIPHER_ARIA_256_CTR, /**< Aria cipher with 256-bit key and CTR mode. */
	JHD_TLS_CIPHER_ARIA_128_GCM, /**< Aria cipher with 128-bit key and GCM mode. */
	JHD_TLS_CIPHER_ARIA_192_GCM, /**< Aria cipher with 192-bit key and GCM mode. */
	JHD_TLS_CIPHER_ARIA_256_GCM, /**< Aria cipher with 256-bit key and GCM mode. */
	JHD_TLS_CIPHER_ARIA_128_CCM, /**< Aria cipher with 128-bit key and CCM mode. */
	JHD_TLS_CIPHER_ARIA_192_CCM, /**< Aria cipher with 192-bit key and CCM mode. */
	JHD_TLS_CIPHER_ARIA_256_CCM, /**< Aria cipher with 256-bit key and CCM mode. */
	JHD_TLS_CIPHER_AES_128_OFB, /**< AES 128-bit cipher in OFB mode. */
	JHD_TLS_CIPHER_AES_192_OFB, /**< AES 192-bit cipher in OFB mode. */
	JHD_TLS_CIPHER_AES_256_OFB, /**< AES 256-bit cipher in OFB mode. */
	JHD_TLS_CIPHER_AES_128_XTS, /**< AES 128-bit cipher in XTS block mode. */
	JHD_TLS_CIPHER_AES_256_XTS, /**< AES 256-bit cipher in XTS block mode. */
} jhd_tls_cipher_type_t;

/** Supported cipher modes. */
typedef enum {
	JHD_TLS_MODE_NONE = 0, /**< None. */
	JHD_TLS_MODE_ECB, /**< The ECB cipher mode. */
	JHD_TLS_MODE_CBC, /**< The CBC cipher mode. */
	JHD_TLS_MODE_CFB, /**< The CFB cipher mode. */
	JHD_TLS_MODE_OFB, /**< The OFB cipher mode. */
	JHD_TLS_MODE_CTR, /**< The CTR cipher mode. */
	JHD_TLS_MODE_GCM, /**< The GCM cipher mode. */
	JHD_TLS_MODE_STREAM, /**< The stream cipher mode. */
	JHD_TLS_MODE_CCM, /**< The CCM cipher mode. */
	JHD_TLS_MODE_XTS, /**< The XTS cipher mode. */
} jhd_tls_cipher_mode_t;

/** Supported cipher padding types. */
typedef enum {
	JHD_TLS_PADDING_PKCS7 = 0, /**< PKCS7 padding (default).        */
	JHD_TLS_PADDING_ONE_AND_ZEROS, /**< ISO/IEC 7816-4 padding.         */
	JHD_TLS_PADDING_ZEROS_AND_LEN, /**< ANSI X.923 padding.             */
	JHD_TLS_PADDING_ZEROS, /**< Zero padding (not reversible). */
	JHD_TLS_PADDING_NONE, /**< Never pad (full blocks only).   */
} jhd_tls_cipher_padding_t;

/** Type of operation. */
typedef enum {
	JHD_TLS_OPERATION_NONE = -1, JHD_TLS_DECRYPT = 0, JHD_TLS_ENCRYPT,
} jhd_tls_operation_t;

enum {
	/** Undefined key length. */
	JHD_TLS_KEY_LENGTH_NONE = 0,
	/** Key length, in bits (including parity), for DES keys. */
	JHD_TLS_KEY_LENGTH_DES = 64,
	/** Key length in bits, including parity, for DES in two-key EDE. */
	JHD_TLS_KEY_LENGTH_DES_EDE = 128,
	/** Key length in bits, including parity, for DES in three-key EDE. */
	JHD_TLS_KEY_LENGTH_DES_EDE3 = 192,
};

/** Maximum length of any IV, in Bytes. */
#define JHD_TLS_MAX_IV_LENGTH      16
/** Maximum block size of any cipher, in Bytes. */
#define JHD_TLS_MAX_BLOCK_LENGTH   16

/**
 * Base cipher information (opaque struct).
 */
typedef struct jhd_tls_cipher_base_t jhd_tls_cipher_base_t;

/**
 * CMAC context (opaque struct).
 */
typedef struct jhd_tls_cmac_context_t jhd_tls_cmac_context_t;

/**
 * Cipher information. Allows calling cipher functions
 * in a generic way.
 */
typedef struct {
	/** Full cipher identifier. For example,
	 * JHD_TLS_CIPHER_AES_256_CBC.
	 */
	jhd_tls_cipher_type_t type;

	/** The cipher mode. For example, JHD_TLS_MODE_CBC. */
	jhd_tls_cipher_mode_t mode;

	/** The cipher key length, in bits. This is the
	 * default length for variable sized ciphers.
	 * Includes parity bits for ciphers like DES.
	 */
	unsigned int key_bitlen;

	/** Name of the cipher. */
	const char * name;

	/** IV or nonce size, in Bytes.
	 * For ciphers that accept variable IV sizes,
	 * this is the recommended size.
	 */
	unsigned int iv_size;

	/** Bitflag comprised of JHD_TLS_CIPHER_VARIABLE_IV_LEN and
	 *  JHD_TLS_CIPHER_VARIABLE_KEY_LEN indicating whether the
	 *  cipher supports variable IV or variable key sizes, respectively.
	 */
	int flags;

	/** The block size, in Bytes. */
	unsigned int block_size;

	/** Struct for base cipher information and functions. */
	const jhd_tls_cipher_base_t *base;

} jhd_tls_cipher_info_t;

/**
 * Generic cipher context.
 */
typedef struct {
	/** Information about the associated cipher. */
	const jhd_tls_cipher_info_t *cipher_info;

	/** Key length to use. */
	int key_bitlen;

	/** Operation that the key of the context has been
	 * initialized for.
	 */
	jhd_tls_operation_t operation;

#if defined(JHD_TLS_CIPHER_MODE_WITH_PADDING)
	/** Padding functions to use, if relevant for
	 * the specific cipher mode.
	 */
	void (*add_padding)(unsigned char *output, size_t olen, size_t data_len);
	int (*get_padding)(unsigned char *input, size_t ilen, size_t *data_len);
#endif

	/** Buffer for input that has not been processed yet. */
	unsigned char unprocessed_data[JHD_TLS_MAX_BLOCK_LENGTH];

	/** Number of Bytes that have not been processed yet. */
	size_t unprocessed_len;

	/** Current IV or NONCE_COUNTER for CTR-mode, data unit (or sector) number
	 * for XTS-mode. */
	unsigned char iv[JHD_TLS_MAX_IV_LENGTH];

	/** IV size in Bytes, for ciphers with variable-length IVs. */
	size_t iv_size;

	/** The cipher-specific context. */
	void *cipher_ctx;

#if defined(JHD_TLS_CMAC_C)
/** CMAC-specific context. */
jhd_tls_cmac_context_t *cmac_ctx;
#endif
} jhd_tls_cipher_context_t;

/** Encrypt using ECB */
typedef int (*jhd_tls_cipher_ecb_pt)(void *ctx, jhd_tls_operation_t mode, const unsigned char *input, unsigned char *output);

/** Encrypt using CBC */
typedef int (*jhd_tls_cipher_cbc_pt)(void *ctx, jhd_tls_operation_t mode, size_t length, unsigned char *iv, const unsigned char *input, unsigned char *output);


/** Encrypt using CFB (Full length) */
typedef int (*jhd_tls_cipher_cfb_pt)(void *ctx, jhd_tls_operation_t mode, size_t length, size_t *iv_off, unsigned char *iv, const unsigned char *input,
    unsigned char *output);

/** Encrypt using OFB (Full length) */
typedef int (*jhd_tls_cipher_ofb_pt)(void *ctx, size_t length, size_t *iv_off, unsigned char *iv, const unsigned char *input, unsigned char *output);


/** Encrypt using CTR */
typedef int (*jhd_tls_cipher_ctr_pt)(void *ctx, size_t length, size_t *nc_off, unsigned char *nonce_counter, unsigned char *stream_block,
    const unsigned char *input, unsigned char *output);


/** Encrypt or decrypt using XTS. */
typedef int (*jhd_tls_cipher_xts_pt)(void *ctx, jhd_tls_operation_t mode, size_t length, const unsigned char data_unit[16], const unsigned char *input,
    unsigned char *output);


/** Encrypt using STREAM */
typedef int (*jhd_tls_cipher_stream_pt)(void *ctx, size_t length, const unsigned char *input, unsigned char *output);


typedef int (*jhd_tls_cipher_setkey_enc_pt)(void *ctx, const unsigned char *key, unsigned int key_bitlen);

/** Set key for decryption purposes */
typedef int (*jhd_tls_cipher_setkey_dec_pt)(void *ctx, const unsigned char *key, unsigned int key_bitlen);

/** Allocate a new context */
typedef void * (*jhd_tls_cipher_ctx_alloc_pt)(void);

/** Free the given context */
typedef void (*jhd_tls_cipher_ctx_free_pt)(void *ctx);

/**
 * \brief This function retrieves the list of ciphers supported by the generic
 * cipher module.
 *
 * \return      A statically-allocated array of ciphers. The last entry
 *              is zero.
 */
const int *jhd_tls_cipher_list(void);

/**
 * \brief               This function retrieves the cipher-information
 *                      structure associated with the given cipher name.
 *
 * \param cipher_name   Name of the cipher to search for.
 *
 * \return              The cipher information structure associated with the
 *                      given \p cipher_name.
 * \return              NULL if the associated cipher information is not found.
 */
const jhd_tls_cipher_info_t *jhd_tls_cipher_info_from_string(const char *cipher_name);

/**
 * \brief               This function retrieves the cipher-information
 *                      structure associated with the given cipher type.
 *
 * \param cipher_type   Type of the cipher to search for.
 *
 * \return              The cipher information structure associated with the
 *                      given \p cipher_type.
 * \return              NULL if the associated cipher information is not found.
 */
const jhd_tls_cipher_info_t *jhd_tls_cipher_info_from_type(const jhd_tls_cipher_type_t cipher_type);

/**
 * \brief               This function retrieves the cipher-information
 *                      structure associated with the given cipher ID,
 *                      key size and mode.
 *
 * \param cipher_id     The ID of the cipher to search for. For example,
 *                      #JHD_TLS_CIPHER_ID_AES.
 * \param key_bitlen    The length of the key in bits.
 * \param mode          The cipher mode. For example, #JHD_TLS_MODE_CBC.
 *
 * \return              The cipher information structure associated with the
 *                      given \p cipher_id.
 * \return              NULL if the associated cipher information is not found.
 */
const jhd_tls_cipher_info_t *jhd_tls_cipher_info_from_values(const jhd_tls_cipher_id_t cipher_id, int key_bitlen, const jhd_tls_cipher_mode_t mode);

/**
 * \brief               This function initializes a \p cipher_context as NONE.
 */
void jhd_tls_cipher_init(jhd_tls_cipher_context_t *ctx);

/**
 * \brief               This function frees and clears the cipher-specific
 *                      context of \p ctx. Freeing \p ctx itself remains the
 *                      responsibility of the caller.
 */
void jhd_tls_cipher_free(jhd_tls_cipher_context_t *ctx);

/**
 * \brief               This function initializes and fills the cipher-context
 *                      structure with the appropriate values. It also clears
 *                      the structure.
 *
 * \param ctx           The context to initialize. May not be NULL.
 * \param cipher_info   The cipher to use.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              #JHD_TLS_ERR_CIPHER_ALLOC_FAILED if allocation of the
 *                      cipher-specific context fails.
 *
 * \internal Currently, the function also clears the structure.
 * In future versions, the caller will be required to call
 * jhd_tls_cipher_init() on the structure first.
 */
int jhd_tls_cipher_setup(jhd_tls_cipher_context_t *ctx, const jhd_tls_cipher_info_t *cipher_info);

/**
 * \brief        This function returns the block size of the given cipher.
 *
 * \param ctx    The context of the cipher. Must be initialized.
 *
 * \return       The size of the blocks of the cipher.
 * \return       0 if \p ctx has not been initialized.
 */
static inline unsigned int jhd_tls_cipher_get_block_size(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return 0;

return ctx->cipher_info->block_size;
}

/**
 * \brief        This function returns the mode of operation for
 *               the cipher. For example, JHD_TLS_MODE_CBC.
 *
 * \param ctx    The context of the cipher. Must be initialized.
 *
 * \return       The mode of operation.
 * \return       #JHD_TLS_MODE_NONE if \p ctx has not been initialized.
 */
static inline jhd_tls_cipher_mode_t jhd_tls_cipher_get_cipher_mode(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return JHD_TLS_MODE_NONE;

return ctx->cipher_info->mode;
}

/**
 * \brief       This function returns the size of the IV or nonce
 *              of the cipher, in Bytes.
 *
 * \param ctx   The context of the cipher. Must be initialized.
 *
 * \return      The recommended IV size if no IV has been set.
 * \return      \c 0 for ciphers not using an IV or a nonce.
 * \return      The actual size if an IV has been set.
 */
static inline int jhd_tls_cipher_get_iv_size(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return 0;

if (ctx->iv_size != 0)
	return (int) ctx->iv_size;

return (int) ctx->cipher_info->iv_size;
}

/**
 * \brief               This function returns the type of the given cipher.
 *
 * \param ctx           The context of the cipher. Must be initialized.
 *
 * \return              The type of the cipher.
 * \return              #JHD_TLS_CIPHER_NONE if \p ctx has not been initialized.
 */
static inline jhd_tls_cipher_type_t jhd_tls_cipher_get_type(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return JHD_TLS_CIPHER_NONE;

return ctx->cipher_info->type;
}

/**
 * \brief               This function returns the name of the given cipher
 *                      as a string.
 *
 * \param ctx           The context of the cipher. Must be initialized.
 *
 * \return              The name of the cipher.
 * \return              NULL if \p ctx has not been not initialized.
 */
static inline const char *jhd_tls_cipher_get_name(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return 0;

return ctx->cipher_info->name;
}

/**
 * \brief               This function returns the key length of the cipher.
 *
 * \param ctx           The context of the cipher. Must be initialized.
 *
 * \return              The key length of the cipher in bits.
 * \return              #JHD_TLS_KEY_LENGTH_NONE if ctx \p has not been
 *                      initialized.
 */
static inline int jhd_tls_cipher_get_key_bitlen(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return JHD_TLS_KEY_LENGTH_NONE;

return (int) ctx->cipher_info->key_bitlen;
}

/**
 * \brief          This function returns the operation of the given cipher.
 *
 * \param ctx      The context of the cipher. Must be initialized.
 *
 * \return         The type of operation: #JHD_TLS_ENCRYPT or #JHD_TLS_DECRYPT.
 * \return         #JHD_TLS_OPERATION_NONE if \p ctx has not been initialized.
 */
static inline jhd_tls_operation_t jhd_tls_cipher_get_operation(const jhd_tls_cipher_context_t *ctx) {
if ( NULL == ctx || NULL == ctx->cipher_info)
	return JHD_TLS_OPERATION_NONE;

return ctx->operation;
}

/**
 * \brief               This function sets the key to use with the given context.
 *
 * \param ctx           The generic cipher context. May not be NULL. Must have
 *                      been initialized using jhd_tls_cipher_info_from_type()
 *                      or jhd_tls_cipher_info_from_string().
 * \param key           The key to use.
 * \param key_bitlen    The key length to use, in bits.
 * \param operation     The operation that the key will be used for:
 *                      #JHD_TLS_ENCRYPT or #JHD_TLS_DECRYPT.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_setkey(jhd_tls_cipher_context_t *ctx, const unsigned char *key, int key_bitlen, const jhd_tls_operation_t operation);


/**
 * \brief               This function sets the padding mode, for cipher modes
 *                      that use padding.
 *
 *                      The default passing mode is PKCS7 padding.
 *
 * \param ctx           The generic cipher context.
 * \param mode          The padding mode.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_FEATURE_UNAVAILABLE
 *                      if the selected padding mode is not supported.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA if the cipher mode
 *                      does not support padding.
 */
int jhd_tls_cipher_set_padding_mode(jhd_tls_cipher_context_t *ctx, jhd_tls_cipher_padding_t mode);


/**
 * \brief           This function sets the initialization vector (IV)
 *                  or nonce.
 *
 * \note            Some ciphers do not use IVs nor nonce. For these
 *                  ciphers, this function has no effect.
 *
 * \param ctx       The generic cipher context.
 * \param iv        The IV to use, or NONCE_COUNTER for CTR-mode ciphers.
 * \param iv_len    The IV length for ciphers with variable-size IV.
 *                  This parameter is discarded by ciphers with fixed-size IV.
 *
 * \return          \c 0 on success.
 * \return          #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                  parameter-verification failure.
 */
int jhd_tls_cipher_set_iv(jhd_tls_cipher_context_t *ctx, const unsigned char *iv, size_t iv_len);

/**
 * \brief         This function resets the cipher state.
 *
 * \param ctx     The generic cipher context.
 *
 * \return        \c 0 on success.
 * \return        #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                parameter-verification failure.
 */
int jhd_tls_cipher_reset(jhd_tls_cipher_context_t *ctx);


/**
 * \brief               This function adds additional data for AEAD ciphers.
 *                      Only supported with GCM. Must be called
 *                      exactly once, after jhd_tls_cipher_reset().
 *
 * \param ctx           The generic cipher context.
 * \param ad            The additional data to use.
 * \param ad_len        the Length of \p ad.
 *
 * \return              \c 0 on success.
 * \return              A specific error code on failure.
 */
int jhd_tls_cipher_update_ad(jhd_tls_cipher_context_t *ctx, const unsigned char *ad, size_t ad_len);


/**
 * \brief               The generic cipher update function. It encrypts or
 *                      decrypts using the given cipher context. Writes as
 *                      many block-sized blocks of data as possible to output.
 *                      Any data that cannot be written immediately is either
 *                      added to the next block, or flushed when
 *                      jhd_tls_cipher_finish() is called.
 *                      Exception: For JHD_TLS_MODE_ECB, expects a single block
 *                      in size. For example, 16 Bytes for AES.
 *
 * \note                If the underlying cipher is used in GCM mode, all calls
 *                      to this function, except for the last one before
 *                      jhd_tls_cipher_finish(), must have \p ilen as a
 *                      multiple of the block size of the cipher.
 *
 * \param ctx           The generic cipher context.
 * \param input         The buffer holding the input data.
 * \param ilen          The length of the input data.
 * \param output        The buffer for the output data. Must be able to hold at
 *                      least \p ilen + block_size. Must not be the same buffer
 *                      as input.
 * \param olen          The length of the output data, to be updated with the
 *                      actual number of Bytes written.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              #JHD_TLS_ERR_CIPHER_FEATURE_UNAVAILABLE on an
 *                      unsupported mode for a cipher.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_update(jhd_tls_cipher_context_t *ctx, const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen);

/**
 * \brief               The generic cipher finalization function. If data still
 *                      needs to be flushed from an incomplete block, the data
 *                      contained in it is padded to the size of
 *                      the last block, and written to the \p output buffer.
 *
 * \param ctx           The generic cipher context.
 * \param output        The buffer to write data to. Needs block_size available.
 * \param olen          The length of the data written to the \p output buffer.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              #JHD_TLS_ERR_CIPHER_FULL_BLOCK_EXPECTED on decryption
 *                      expecting a full block but not receiving one.
 * \return              #JHD_TLS_ERR_CIPHER_INVALID_PADDING on invalid padding
 *                      while decrypting.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_finish(jhd_tls_cipher_context_t *ctx, unsigned char *output, size_t *olen);


/**
 * \brief               This function writes a tag for AEAD ciphers.
 *                      Only supported with GCM.
 *                      Must be called after jhd_tls_cipher_finish().
 *
 * \param ctx           The generic cipher context.
 * \param tag           The buffer to write the tag to.
 * \param tag_len       The length of the tag to write.
 *
 * \return              \c 0 on success.
 * \return              A specific error code on failure.
 */
int jhd_tls_cipher_write_tag(jhd_tls_cipher_context_t *ctx, unsigned char *tag, size_t tag_len);

/**
 * \brief               This function checks the tag for AEAD ciphers.
 *                      Only supported with GCM.
 *                      Must be called after jhd_tls_cipher_finish().
 *
 * \param ctx           The generic cipher context.
 * \param tag           The buffer holding the tag.
 * \param tag_len       The length of the tag to check.
 *
 * \return              \c 0 on success.
 * \return              A specific error code on failure.
 */
int jhd_tls_cipher_check_tag(jhd_tls_cipher_context_t *ctx, const unsigned char *tag, size_t tag_len);


/**
 * \brief               The generic all-in-one encryption/decryption function,
 *                      for all ciphers except AEAD constructs.
 *
 * \param ctx           The generic cipher context.
 * \param iv            The IV to use, or NONCE_COUNTER for CTR-mode ciphers.
 * \param iv_len        The IV length for ciphers with variable-size IV.
 *                      This parameter is discarded by ciphers with fixed-size
 *                      IV.
 * \param input         The buffer holding the input data.
 * \param ilen          The length of the input data.
 * \param output        The buffer for the output data. Must be able to hold at
 *                      least \p ilen + block_size. Must not be the same buffer
 *                      as input.
 * \param olen          The length of the output data, to be updated with the
 *                      actual number of Bytes written.
 *
 * \note                Some ciphers do not use IVs nor nonce. For these
 *                      ciphers, use \p iv = NULL and \p iv_len = 0.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              #JHD_TLS_ERR_CIPHER_FULL_BLOCK_EXPECTED on decryption
 *                      expecting a full block but not receiving one.
 * \return              #JHD_TLS_ERR_CIPHER_INVALID_PADDING on invalid padding
 *                      while decrypting.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_crypt(jhd_tls_cipher_context_t *ctx, const unsigned char *iv, size_t iv_len, const unsigned char *input, size_t ilen, unsigned char *output,
    size_t *olen);


/**
 * \brief               The generic autenticated encryption (AEAD) function.
 *
 * \param ctx           The generic cipher context.
 * \param iv            The IV to use, or NONCE_COUNTER for CTR-mode ciphers.
 * \param iv_len        The IV length for ciphers with variable-size IV.
 *                      This parameter is discarded by ciphers with fixed-size IV.
 * \param ad            The additional data to authenticate.
 * \param ad_len        The length of \p ad.
 * \param input         The buffer holding the input data.
 * \param ilen          The length of the input data.
 * \param output        The buffer for the output data.
 *                      Must be able to hold at least \p ilen.
 * \param olen          The length of the output data, to be updated with the
 *                      actual number of Bytes written.
 * \param tag           The buffer for the authentication tag.
 * \param tag_len       The desired length of the authentication tag.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_auth_encrypt(jhd_tls_cipher_context_t *ctx, const unsigned char *iv, size_t iv_len, const unsigned char *ad, size_t ad_len,
    const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, unsigned char *tag, size_t tag_len);

/**
 * \brief               The generic autenticated decryption (AEAD) function.
 *
 * \note                If the data is not authentic, then the output buffer
 *                      is zeroed out to prevent the unauthentic plaintext being
 *                      used, making this interface safer.
 *
 * \param ctx           The generic cipher context.
 * \param iv            The IV to use, or NONCE_COUNTER for CTR-mode ciphers.
 * \param iv_len        The IV length for ciphers with variable-size IV.
 *                      This parameter is discarded by ciphers with fixed-size IV.
 * \param ad            The additional data to be authenticated.
 * \param ad_len        The length of \p ad.
 * \param input         The buffer holding the input data.
 * \param ilen          The length of the input data.
 * \param output        The buffer for the output data.
 *                      Must be able to hold at least \p ilen.
 * \param olen          The length of the output data, to be updated with the
 *                      actual number of Bytes written.
 * \param tag           The buffer holding the authentication tag.
 * \param tag_len       The length of the authentication tag.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CIPHER_BAD_INPUT_DATA on
 *                      parameter-verification failure.
 * \return              #JHD_TLS_ERR_CIPHER_AUTH_FAILED if data is not authentic.
 * \return              A cipher-specific error code on failure.
 */
int jhd_tls_cipher_auth_decrypt(jhd_tls_cipher_context_t *ctx, const unsigned char *iv, size_t iv_len, const unsigned char *ad, size_t ad_len,
    const unsigned char *input, size_t ilen, unsigned char *output, size_t *olen, const unsigned char *tag, size_t tag_len);

#endif /* JHD_TLS_CIPHER_H */
