#include <tls/jhd_tls_config.h>

#if defined(JHD_TLS_SSL_CLI_C)

#include <tls/jhd_tls_platform.h>

#include <tls/jhd_tls_ssl.h>
#include <tls/jhd_tls_ssl_internal.h>

#include <string.h>

#include <stdint.h>

#if defined(JHD_TLS_HAVE_TIME)
#include <tls/jhd_tls_platform_time.h>
#endif

static void ssl_write_hostname_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	size_t hostname_len;

	*olen = 0;

	if (ssl->hostname == NULL)
		return;

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding server name extension: %s", ssl->hostname));

	hostname_len = strlen(ssl->hostname);

	if (end < p || (size_t) (end - p) < hostname_len + 9) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	/*
	 * Sect. 3, RFC 6066 (TLS Extensions Definitions)
	 *
	 * In order to provide any of the server names, clients MAY include an
	 * extension of type "server_name" in the (extended) client hello. The
	 * "extension_data" field of this extension SHALL contain
	 * "ServerNameList" where:
	 *
	 * struct {
	 *     NameType name_type;
	 *     select (name_type) {
	 *         case host_name: HostName;
	 *     } name;
	 * } ServerName;
	 *
	 * enum {
	 *     host_name(0), (255)
	 * } NameType;
	 *
	 * opaque HostName<1..2^16-1>;
	 *
	 * struct {
	 *     ServerName server_name_list<1..2^16-1>
	 * } ServerNameList;
	 *
	 */
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SERVERNAME >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SERVERNAME) & 0xFF);

	*p++ = (unsigned char) (((hostname_len + 5) >> 8) & 0xFF);
	*p++ = (unsigned char) (((hostname_len + 5)) & 0xFF);

	*p++ = (unsigned char) (((hostname_len + 3) >> 8) & 0xFF);
	*p++ = (unsigned char) (((hostname_len + 3)) & 0xFF);

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SERVERNAME_HOSTNAME) & 0xFF);
	*p++ = (unsigned char) ((hostname_len >> 8) & 0xFF);
	*p++ = (unsigned char) ((hostname_len) & 0xFF);

	memcpy(p, ssl->hostname, hostname_len);

	*olen = hostname_len + 9;
}

/*
 * Only if we handle at least one key exchange that needs signatures.
 */

static void ssl_write_signature_algorithms_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	size_t sig_alg_len = 0;
	const int *md;

	unsigned char *sig_alg_list = buf + 6;

	*olen = 0;

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding signature_algorithms extension"));

	for (md = jhd_tls_ssl_preset_default_hashes; *md != JHD_TLS_MD_NONE; md++) {
		sig_alg_len += 2;
		sig_alg_len += 2;

	}

	if (end < p || (size_t) (end - p) < sig_alg_len + 6) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	/*
	 * Prepare signature_algorithms extension (TLS 1.2)
	 */
	sig_alg_len = 0;

	for (md = jhd_tls_ssl_preset_default_hashes; *md != JHD_TLS_MD_NONE; md++) {
#if defined(JHD_TLS_ECDSA_C)
		sig_alg_list[sig_alg_len++] = jhd_tls_ssl_hash_from_md_alg(*md);
		sig_alg_list[sig_alg_len++] = JHD_TLS_SSL_SIG_ECDSA;
#endif

		sig_alg_list[sig_alg_len++] = jhd_tls_ssl_hash_from_md_alg(*md);
		sig_alg_list[sig_alg_len++] = JHD_TLS_SSL_SIG_RSA;

	}

	/*
	 * enum {
	 *     none(0), md5(1), sha1(2), sha224(3), sha256(4), sha384(5),
	 *     sha512(6), (255)
	 * } HashAlgorithm;
	 *
	 * enum { anonymous(0), rsa(1), dsa(2), ecdsa(3), (255) }
	 *   SignatureAlgorithm;
	 *
	 * struct {
	 *     HashAlgorithm hash;
	 *     SignatureAlgorithm signature;
	 * } SignatureAndHashAlgorithm;
	 *
	 * SignatureAndHashAlgorithm
	 *   supported_signature_algorithms<2..2^16-2>;
	 */
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SIG_ALG >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SIG_ALG) & 0xFF);

	*p++ = (unsigned char) (((sig_alg_len + 2) >> 8) & 0xFF);
	*p++ = (unsigned char) (((sig_alg_len + 2)) & 0xFF);

	*p++ = (unsigned char) ((sig_alg_len >> 8) & 0xFF);
	*p++ = (unsigned char) ((sig_alg_len) & 0xFF);

	*olen = 6 + sig_alg_len;
}

static void ssl_write_supported_elliptic_curves_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	unsigned char *elliptic_curve_list = p + 6;
	size_t elliptic_curve_len = 0;
	const jhd_tls_ecp_curve_info *info;

	const jhd_tls_ecp_group_id *grp_id;

	*olen = 0;

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding supported_elliptic_curves extension"));

	for (grp_id = jhd_tls_ecp_grp_id_list(); *grp_id != JHD_TLS_ECP_DP_NONE; grp_id++)

	{

		info = jhd_tls_ecp_curve_info_from_grp_id(*grp_id);

		if (info == NULL) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("invalid curve in ssl configuration"));
			return;
		}

		elliptic_curve_len += 2;
	}

	if (end < p || (size_t) (end - p) < 6 + elliptic_curve_len) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	elliptic_curve_len = 0;

	for (grp_id = jhd_tls_ecp_grp_id_list(); *grp_id != JHD_TLS_ECP_DP_NONE; grp_id++)

	{

		info = jhd_tls_ecp_curve_info_from_grp_id(*grp_id);

		elliptic_curve_list[elliptic_curve_len++] = info->tls_id >> 8;
		elliptic_curve_list[elliptic_curve_len++] = info->tls_id & 0xFF;
	}

	if (elliptic_curve_len == 0)
		return;

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SUPPORTED_ELLIPTIC_CURVES >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SUPPORTED_ELLIPTIC_CURVES) & 0xFF);

	*p++ = (unsigned char) (((elliptic_curve_len + 2) >> 8) & 0xFF);
	*p++ = (unsigned char) (((elliptic_curve_len + 2)) & 0xFF);

	*p++ = (unsigned char) (((elliptic_curve_len) >> 8) & 0xFF);
	*p++ = (unsigned char) (((elliptic_curve_len)) & 0xFF);

	*olen = 6 + elliptic_curve_len;
}

static void ssl_write_supported_point_formats_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;

	*olen = 0;

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding supported_point_formats extension"));

	if (end < p || (size_t) (end - p) < 6) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SUPPORTED_POINT_FORMATS >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_SUPPORTED_POINT_FORMATS) & 0xFF);

	*p++ = 0x00;
	*p++ = 2;

	*p++ = 1;
	*p++ = JHD_TLS_ECP_PF_UNCOMPRESSED;

	*olen = 6;
}

static void ssl_write_max_fragment_length_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;

	*olen = 0;

	if (ssl->conf->mfl_code == JHD_TLS_SSL_MAX_FRAG_LEN_NONE) {
		return;
	}

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding max_fragment_length extension"));

	if (end < p || (size_t) (end - p) < 5) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_MAX_FRAGMENT_LENGTH >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_MAX_FRAGMENT_LENGTH) & 0xFF);

	*p++ = 0x00;
	*p++ = 1;

	*p++ = ssl->conf->mfl_code;

	*olen = 5;
}

static void ssl_write_truncated_hmac_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	*olen = 0;
	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding truncated_hmac extension"));
	if (end < p || (size_t) (end - p) < 4) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_TRUNCATED_HMAC >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_TRUNCATED_HMAC) & 0xFF);
	*p++ = 0x00;
	*p++ = 0x00;
	*olen = 4;
}

static void ssl_write_encrypt_then_mac_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;

	*olen = 0;
	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding encrypt_then_mac " "extension"));

	if (end < p || (size_t) (end - p) < 4) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_ENCRYPT_THEN_MAC >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_ENCRYPT_THEN_MAC) & 0xFF);

	*p++ = 0x00;
	*p++ = 0x00;

	*olen = 4;
}

static void ssl_write_extended_ms_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	*olen = 0;
	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding extended_master_secret " "extension"));
	if (end < p || (size_t) (end - p) < 4) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_EXTENDED_MASTER_SECRET >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_EXTENDED_MASTER_SECRET) & 0xFF);
	*p++ = 0x00;
	*p++ = 0x00;
	*olen = 4;
}

static void ssl_write_alpn_ext(jhd_tls_ssl_context *ssl, unsigned char *buf, size_t *olen) {
	unsigned char *p = buf;
	const unsigned char *end = ssl->out_msg + JHD_TLS_SSL_MAX_CONTENT_LEN;
	size_t alpnlen = 0;
	const char **cur;

	*olen = 0;

	if (ssl->conf->alpn_list == NULL) {
		return;
	}

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, adding alpn extension"));

	for (cur = ssl->conf->alpn_list; *cur != NULL; cur++)
		alpnlen += (unsigned char) (strlen(*cur) & 0xFF) + 1;

	if (end < p || (size_t) (end - p) < 6 + alpnlen) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small"));
		return;
	}

	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_ALPN >> 8) & 0xFF);
	*p++ = (unsigned char) (( JHD_TLS_TLS_EXT_ALPN) & 0xFF);

	/*
	 * opaque ProtocolName<1..2^8-1>;
	 *
	 * struct {
	 *     ProtocolName protocol_name_list<2..2^16-1>
	 * } ProtocolNameList;
	 */

	/* Skip writing extension and list length for now */
	p += 4;

	for (cur = ssl->conf->alpn_list; *cur != NULL; cur++) {
		*p = (unsigned char) (strlen(*cur) & 0xFF);
		memcpy(p + 1, *cur, *p);
		p += 1 + *p;
	}

	*olen = p - buf;

	/* List length = olen - 2 (ext_type) - 2 (ext_len) - 2 (list_len) */
	buf[4] = (unsigned char) (((*olen - 6) >> 8) & 0xFF);
	buf[5] = (unsigned char) (((*olen - 6)) & 0xFF);

	/* Extension length = olen - 2 (ext_type) - 2 (ext_len) */
	buf[2] = (unsigned char) (((*olen - 4) >> 8) & 0xFF);
	buf[3] = (unsigned char) (((*olen - 4)) & 0xFF);
}

/**
 * \brief           Validate cipher suite against config in SSL context.
 *
 * \param suite_info    cipher suite to validate
 * \param ssl           SSL context
 * \param min_minor_ver Minimal minor version to accept a cipher suite
 * \param max_minor_ver Maximal minor version to accept a cipher suite
 *
 * \return          0 if valid, else 1
 */
static int ssl_validate_ciphersuite(const jhd_tls_ssl_ciphersuite_t * suite_info, const jhd_tls_ssl_context * ssl, int min_minor_ver, int max_minor_ver) {
	(void) ssl;
	if (suite_info == NULL)
		return (1);

	if (suite_info->min_minor_ver > max_minor_ver || suite_info->max_minor_ver < min_minor_ver)
		return (1);
	return (0);
}

static int ssl_write_client_hello(jhd_tls_ssl_context *ssl) {
	int ret;
	size_t i, n, olen, ext_len = 0;
	unsigned char *buf;
	unsigned char *p, *q;
	const int *ciphersuites = jhd_tls_ssl_list_ciphersuites();
	const jhd_tls_ssl_ciphersuite_t *ciphersuite_info;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> write client hello"));

	ssl->major_ver = JHD_TLS_SSL_MAX_MAJOR_VERSION;
	ssl->minor_ver = JHD_TLS_SSL_MIN_MINOR_VERSION;

	/*
	 *     0  .   0   handshake type
	 *     1  .   3   handshake length
	 *     4  .   5   highest version supported
	 *     6  .   9   current UNIX time
	 *    10  .  37   random bytes
	 */
	buf = ssl->out_msg;
	p = buf + 4;

	jhd_tls_ssl_write_version(JHD_TLS_SSL_MAX_MAJOR_VERSION, JHD_TLS_SSL_MAX_MINOR_VERSION, p);
	p += 2;

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, max version: [%d:%d]", buf[4], buf[5]));

	jhd_tls_random32_with_time(ssl->handshake->randbytes);

	memcpy(p, ssl->handshake->randbytes, 32);
	JHD_TLS_SSL_DEBUG_BUF(3, "client hello, random bytes", p, 32);
	p += 32;

	/*
	 *    38  .  38   session id length
	 *    39  . 39+n  session id
	 *   39+n . 39+n  DTLS only: cookie length (1 byte)
	 *   40+n .  ..   DTSL only: cookie
	 *   ..   . ..    ciphersuitelist length (2 bytes)
	 *   ..   . ..    ciphersuitelist
	 *   ..   . ..    compression methods length (1 byte)
	 *   ..   . ..    compression methods
	 *   ..   . ..    extensions length (2 bytes)
	 *   ..   . ..    extensions
	 */
//	n = ssl->session_negotiate->id_len;
//
//	if (n < 16 || n > 32 ||	ssl->renego_status != JHD_TLS_SSL_INITIAL_HANDSHAKE ||	ssl->handshake->resume == 0) {
//		n = 0;
//	}
	*p++ = (unsigned char) 0;

//	for (i = 0; i < n; i++)
//		*p++ = ssl->session_negotiate->id[i];

//	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, session id len.: %d", n));
//	JHD_TLS_SSL_DEBUG_BUF(3, "client hello, session id", buf + 39, n);

	/* Skip writing ciphersuite length for now */
	n = 0;
	q = p;
	p += 2;

	for (i = 0; ciphersuites[i] != 0; i++) {
		ciphersuite_info = jhd_tls_ssl_ciphersuite_from_id(ciphersuites[i]);

		if (ssl_validate_ciphersuite(ciphersuite_info, ssl, JHD_TLS_SSL_MIN_MINOR_VERSION, JHD_TLS_SSL_MAX_MINOR_VERSION) != 0)
			continue;

		JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, add ciphersuite: %04x", ciphersuites[i]));

		n++;
		*p++ = (unsigned char) (ciphersuites[i] >> 8);
		*p++ = (unsigned char) (ciphersuites[i]);
	}

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, got %d ciphersuites (excluding SCSVs)", n));

	/*
	 * Add TLS_EMPTY_RENEGOTIATION_INFO_SCSV
	 */

	JHD_TLS_SSL_DEBUG_MSG(3, ("adding EMPTY_RENEGOTIATION_INFO_SCSV"));
	*p++ = (unsigned char) ( JHD_TLS_SSL_EMPTY_RENEGOTIATION_INFO >> 8);
	*p++ = (unsigned char) ( JHD_TLS_SSL_EMPTY_RENEGOTIATION_INFO);
	n++;

	/* Some versions of OpenSSL don't handle it correctly if not at end */
#if defined(JHD_TLS_SSL_FALLBACK_SCSV)
	if (ssl->conf->fallback == JHD_TLS_SSL_IS_FALLBACK) {
		JHD_TLS_SSL_DEBUG_MSG(3, ("adding FALLBACK_SCSV"));
		*p++ = (unsigned char) ( JHD_TLS_SSL_FALLBACK_SCSV_VALUE >> 8);
		*p++ = (unsigned char) ( JHD_TLS_SSL_FALLBACK_SCSV_VALUE);
		n++;
	}
#endif

	*q++ = (unsigned char) (n >> 7);
	*q++ = (unsigned char) (n << 1);

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, compress len.: %d", 1));
	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, compress alg.: %d", JHD_TLS_SSL_COMPRESS_NULL));

	*p++ = 1;
	*p++ = JHD_TLS_SSL_COMPRESS_NULL;

	// First write extensions, then the total length
	//

	ssl_write_hostname_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	/* Note that TLS_EMPTY_RENEGOTIATION_INFO_SCSV is always added
	 * even if JHD_TLS_SSL_RENEGOTIATION is not defined. */

	ssl_write_signature_algorithms_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	ssl_write_supported_elliptic_curves_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	ssl_write_supported_point_formats_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;
	ssl_write_max_fragment_length_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	ssl_write_truncated_hmac_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	ssl_write_encrypt_then_mac_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;
	ssl_write_extended_ms_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	ssl_write_alpn_ext(ssl, p + 2 + ext_len, &olen);
	ext_len += olen;

	/* olen unused if all extensions are disabled */
	((void) olen);

	JHD_TLS_SSL_DEBUG_MSG(3, ("client hello, total extension length: %d", ext_len));

	if (ext_len > 0) {
		*p++ = (unsigned char) ((ext_len >> 8) & 0xFF);
		*p++ = (unsigned char) ((ext_len) & 0xFF);
		p += ext_len;
	}

	ssl->out_msglen = p - buf;
	ssl->out_msgtype = JHD_TLS_SSL_MSG_HANDSHAKE;
	ssl->out_msg[0] = JHD_TLS_SSL_HS_CLIENT_HELLO;

	ssl->state++;

	if ((ret = jhd_tls_ssl_write_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_write_record", ret);
		return (ret);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= write client hello"));

	return (0);
}

static int ssl_parse_renegotiation_info(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {

	if (len != 1 || buf[0] != 0x00) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-zero length renegotiation info"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}
	return (0);
}

static int ssl_parse_max_fragment_length_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	/*
	 * server should use the extension only if we did,
	 * and if so the server's value should match ours (and len is always 1)
	 */
	if (ssl->conf->mfl_code == JHD_TLS_SSL_MAX_FRAG_LEN_NONE || len != 1 || buf[0] != ssl->conf->mfl_code) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-matching max fragment length extension"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}
	return (0);
}

static int ssl_parse_truncated_hmac_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	if (len != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-matching truncated HMAC extension"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}
	((void) buf);
	ssl->session_negotiate->trunc_hmac = JHD_TLS_SSL_TRUNC_HMAC_ENABLED;
	return (0);
}

static int ssl_parse_encrypt_then_mac_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	if (len != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-matching encrypt-then-MAC extension"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}
	((void) buf);
	ssl->session_negotiate->encrypt_then_mac = JHD_TLS_SSL_ETM_ENABLED;
	return (0);
}

static int ssl_parse_extended_ms_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	if (len != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-matching extended master secret extension"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}
	ssl->handshake->extended_ms = JHD_TLS_SSL_EXTENDED_MS_ENABLED;
	return (0);
}

static int ssl_parse_supported_point_formats_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	size_t list_size;
	const unsigned char *p;

	list_size = buf[0];
	if (list_size + 1 != len) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	p = buf + 1;
	while (list_size > 0) {
		if (p[0] == JHD_TLS_ECP_PF_UNCOMPRESSED || p[0] == JHD_TLS_ECP_PF_COMPRESSED) {

			ssl->handshake->ecdh_ctx.point_format = p[0];
			JHD_TLS_SSL_DEBUG_MSG(4, ("point format selected: %d", p[0]));
			return (0);
		}

		list_size--;
		p++;
	}

	JHD_TLS_SSL_DEBUG_MSG(1, ("no point format in common"));
	jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
	JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
	return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
}

static int ssl_parse_alpn_ext(jhd_tls_ssl_context *ssl, const unsigned char *buf, size_t len) {
	size_t list_len, name_len;
	const char **p;

	/* If we didn't send it, the server shouldn't send it */
	if (ssl->conf->alpn_list == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("non-matching ALPN extension"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	/*
	 * opaque ProtocolName<1..2^8-1>;
	 *
	 * struct {
	 *     ProtocolName protocol_name_list<2..2^16-1>
	 * } ProtocolNameList;
	 *
	 * the "ProtocolNameList" MUST contain exactly one "ProtocolName"
	 */

	/* Min length is 2 (list_len) + 1 (name_len) + 1 (name) */
	if (len < 4) {
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	list_len = (buf[0] << 8) | buf[1];
	if (list_len != len - 2) {
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	name_len = buf[2];
	if (name_len != list_len - 1) {
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	/* Check that the server chosen protocol was in our list and save it */
	for (p = ssl->conf->alpn_list; *p != NULL; p++) {
		if (name_len == strlen(*p) && memcmp(buf + 3, *p, name_len) == 0) {
			ssl->alpn_chosen = *p;
			return (0);
		}
	}

	JHD_TLS_SSL_DEBUG_MSG(1, ("ALPN extension: no matching protocol"));
	jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
	JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
	return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
}

static int ssl_parse_server_hello(jhd_tls_ssl_context *ssl) {
	int ret, i;
	size_t n;
	size_t ext_len;
	unsigned char *buf, *ext;
	const jhd_tls_ssl_ciphersuite_t *suite_info;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> parse server hello"));

	buf = ssl->in_msg;

	if ((ret = jhd_tls_ssl_read_record(ssl)) != 0) {
		/* No alert on a read error. */
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_read_record", ret);
		return (ret);
	}

	if (ssl->in_msgtype != JHD_TLS_SSL_MSG_HANDSHAKE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_UNEXPECTED_MESSAGE);
		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}

	if (ssl->in_hslen < 38 + jhd_tls_ssl_hs_hdr_len(ssl) || buf[0] != JHD_TLS_SSL_HS_SERVER_HELLO) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	/*
	 *  0   .  1    server_version
	 *  2   . 33    random (maybe including 4 bytes of Unix time)
	 * 34   . 34    session_id length = n
	 * 35   . 34+n  session_id
	 * 35+n . 36+n  cipher_suite
	 * 37+n . 37+n  compression_method
	 *
	 * 38+n . 39+n  extensions length (optional)
	 * 40+n .  ..   extensions
	 */
	buf += jhd_tls_ssl_hs_hdr_len(ssl);

	JHD_TLS_SSL_DEBUG_BUF(3, "server hello, version", buf + 0, 2);
	jhd_tls_ssl_read_version(&ssl->major_ver, &ssl->minor_ver, buf + 0);

	if (ssl->major_ver < JHD_TLS_SSL_MIN_MAJOR_VERSION || ssl->minor_ver < JHD_TLS_SSL_MIN_MINOR_VERSION || ssl->major_ver > JHD_TLS_SSL_MAX_MAJOR_VERSION
	        || ssl->minor_ver > JHD_TLS_SSL_MAX_MINOR_VERSION) {
		JHD_TLS_SSL_DEBUG_MSG(1,
		        ("server version out of bounds - " " min: [%d:%d], server: [%d:%d], max: [%d:%d]",JHS_TLS_SSL_MIN_MAJOR_VERSION, JHD_TLS_SSL_MIN_MINOR_VERSION, ssl->major_ver, ssl->minor_ver, JHD_TLS_SSL_MAX_MAJOR_VERSION, JHD_TLS_SSL_MAX_MINOR_VERSION));

		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_PROTOCOL_VERSION);

		return ( JHD_TLS_ERR_SSL_BAD_HS_PROTOCOL_VERSION);
	}

	JHD_TLS_SSL_DEBUG_MSG(3,
	        ("server hello, current time: %lu", ((uint32_t) buf[2] << 24) | ((uint32_t) buf[3] << 16) | ((uint32_t) buf[4] << 8) | ((uint32_t) buf[5])));

	memcpy(ssl->handshake->randbytes + 32, buf + 2, 32);

	n = buf[34];

	JHD_TLS_SSL_DEBUG_BUF(3, "server hello, random bytes", buf + 2, 32);

	if (n > 32) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	if (ssl->in_hslen > jhd_tls_ssl_hs_hdr_len(ssl) + 39 + n) {
		ext_len = ((buf[38 + n] << 8) | (buf[39 + n]));

		if ((ext_len > 0 && ext_len < 4) || ssl->in_hslen != jhd_tls_ssl_hs_hdr_len(ssl) + 40 + n + ext_len) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
		}
	} else if (ssl->in_hslen == jhd_tls_ssl_hs_hdr_len(ssl) + 38 + n) {
		ext_len = 0;
	} else {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	/* ciphersuite (used later) */
	i = (buf[35 + n] << 8) | buf[36 + n];

	/*
	 * Read and check compression
	 */

	if (buf[37 + n] != JHD_TLS_SSL_COMPRESS_NULL) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("server hello, bad compression: %d", comp));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
		return ( JHD_TLS_ERR_SSL_FEATURE_UNAVAILABLE);
	}

	/*
	 * Initialize update checksum functions
	 */
	ssl->transform_negotiate->ciphersuite_info = jhd_tls_ssl_ciphersuite_from_id(i);

	if (ssl->transform_negotiate->ciphersuite_info == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("ciphersuite info for %04x not found", i));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_INTERNAL_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_INPUT_DATA);
	}

	jhd_tls_ssl_optimize_checksum(ssl, ssl->transform_negotiate->ciphersuite_info);

	JHD_TLS_SSL_DEBUG_MSG(3, ("server hello, session id len.: %d", n));
	JHD_TLS_SSL_DEBUG_BUF(3, "server hello, session id", buf + 35, n);

	/*
	 * Check if the session can be resumed
	 */
	if (n == 0 || ssl->session_negotiate->ciphersuite != i) {
		ssl->state++;
		ssl->session_negotiate->ciphersuite = i;
//		ssl->session_negotiate->id_len = n;
//		memcpy(ssl->session_negotiate->id, buf + 35, n);
	} else {
		ssl->state = JHD_TLS_SSL_SERVER_CHANGE_CIPHER_SPEC;

		if ((ret = jhd_tls_ssl_derive_keys(ssl)) != 0) {
			JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_derive_keys", ret);
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_INTERNAL_ERROR);
			return (ret);
		}
	}

	JHD_TLS_SSL_DEBUG_MSG(3, ("%s session has been resumed", ssl->handshake->resume ? "a" : "no"));

	JHD_TLS_SSL_DEBUG_MSG(3, ("server hello, chosen ciphersuite: %04x", i));
	JHD_TLS_SSL_DEBUG_MSG(3, ("server hello, compress alg.: %d", buf[37 + n]));

	/*
	 * Perform cipher suite validation in same way as in ssl_write_client_hello.
	 */
	i = 0;
	while (1) {
		if (jhd_tls_ssl_list_ciphersuites()[i] == 0) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
		}

		if (jhd_tls_ssl_list_ciphersuites()[i++] == ssl->session_negotiate->ciphersuite) {
			break;
		}
	}

	suite_info = jhd_tls_ssl_ciphersuite_from_id(ssl->session_negotiate->ciphersuite);
	if (ssl_validate_ciphersuite(suite_info, ssl, ssl->minor_ver, ssl->minor_ver) != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
	}

	JHD_TLS_SSL_DEBUG_MSG(3, ("server hello, chosen ciphersuite: %s", suite_info->name));

	ext = buf + 40 + n;

	JHD_TLS_SSL_DEBUG_MSG(2, ("server hello, total extension length: %d", ext_len));

	while (ext_len) {
		unsigned int ext_id = ((ext[0] << 8) | (ext[1]));
		unsigned int ext_size = ((ext[2] << 8) | (ext[3]));

		if (ext_size + 4 > ext_len) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
		}

		switch (ext_id) {
			case JHD_TLS_TLS_EXT_RENEGOTIATION_INFO:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found renegotiation extension"));

				if ((ret = ssl_parse_renegotiation_info(ssl, ext + 4, ext_size)) != 0)
					return (ret);

				break;

			case JHD_TLS_TLS_EXT_MAX_FRAGMENT_LENGTH:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found max_fragment_length extension"));
				if ((ret = ssl_parse_max_fragment_length_ext(ssl, ext + 4, ext_size)) != 0) {
					return (ret);
				}

				break;
			case JHD_TLS_TLS_EXT_TRUNCATED_HMAC:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found truncated_hmac extension"));

				if ((ret = ssl_parse_truncated_hmac_ext(ssl, ext + 4, ext_size)) != 0) {
					return (ret);
				}

				break;
			case JHD_TLS_TLS_EXT_ENCRYPT_THEN_MAC:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found encrypt_then_mac extension"));

				if ((ret = ssl_parse_encrypt_then_mac_ext(ssl, ext + 4, ext_size)) != 0) {
					return (ret);
				}

				break;
			case JHD_TLS_TLS_EXT_EXTENDED_MASTER_SECRET:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found extended_master_secret extension"));

				if ((ret = ssl_parse_extended_ms_ext(ssl, ext + 4, ext_size)) != 0) {
					return (ret);
				}
				break;
			case JHD_TLS_TLS_EXT_SUPPORTED_POINT_FORMATS:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found supported_point_formats extension"));

				if ((ret = ssl_parse_supported_point_formats_ext(ssl, ext + 4, ext_size)) != 0) {
					return (ret);
				}

				break;

			case JHD_TLS_TLS_EXT_ALPN:
				JHD_TLS_SSL_DEBUG_MSG(3, ("found alpn extension"));

				if ((ret = ssl_parse_alpn_ext(ssl, ext + 4, ext_size)) != 0)
					return (ret);

				break;
			default:
				JHD_TLS_SSL_DEBUG_MSG(3, ("unknown extension found: %d (ignoring)", ext_id));
		}

		ext_len -= 4 + ext_size;
		ext += 4 + ext_size;

		if (ext_len > 0 && ext_len < 4) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello message"));
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO);
		}
	}
	JHD_TLS_SSL_DEBUG_MSG(2, ("<= parse server hello"));

	return (0);
}

static int ssl_check_server_ecdh_params(const jhd_tls_ssl_context *ssl) {
	const jhd_tls_ecp_curve_info *curve_info;

	curve_info = jhd_tls_ecp_curve_info_from_grp_id(ssl->handshake->ecdh_ctx.grp.id);
	if (curve_info == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
		return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("ECDH curve: %s", curve_info->name));

	if (jhd_tls_ssl_check_curve(ssl, ssl->handshake->ecdh_ctx.grp.id) != 0)
		return (-1);

	JHD_TLS_SSL_DEBUG_ECP(3, "ECDH: Qp", &ssl->handshake->ecdh_ctx.Qp);

	return (0);
}

#if defined(JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED) || defined(JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED)
static int ssl_parse_server_ecdh_params(jhd_tls_ssl_context *ssl, unsigned char **p, unsigned char *end) {
	int ret = JHD_TLS_ERR_SSL_FEATURE_UNAVAILABLE;

	/*
	 * Ephemeral ECDH parameters:
	 *
	 * struct {
	 *     ECParameters curve_params;
	 *     ECPoint      public;
	 * } ServerECDHParams;
	 */
	if ((ret = jhd_tls_ecdh_read_params(&ssl->handshake->ecdh_ctx, (const unsigned char **) p, end)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, ("jhd_tls_ecdh_read_params"), ret);
		return (ret);
	}

	if (ssl_check_server_ecdh_params(ssl) != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message (ECDHE curve)"));
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
	}

	return (ret);
}
#endif /* JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED ||JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED  */

/*
 * Generate a pre-master secret and encrypt it with the server's RSA key
 */
static int ssl_write_encrypted_pms(jhd_tls_ssl_context *ssl, size_t offset, size_t *olen, size_t pms_offset) {
	int ret;
	size_t len_bytes = ssl->minor_ver == JHD_TLS_SSL_MINOR_VERSION_0 ? 0 : 2;
	unsigned char *p = ssl->handshake->premaster + pms_offset;

	if (offset + len_bytes > JHD_TLS_SSL_MAX_CONTENT_LEN) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("buffer too small for encrypted pms"));
		return ( JHD_TLS_ERR_SSL_BUFFER_TOO_SMALL);
	}

	/*
	 * Generate (part of) the pre-master as
	 *  struct {
	 *      ProtocolVersion client_version;
	 *      opaque random[46];
	 *  } PreMasterSecret;
	 */
	jhd_tls_ssl_write_version(JHD_TLS_SSL_MAX_MAJOR_VERSION, JHD_TLS_SSL_MAX_MINOR_VERSION, p);

	jhd_tls_random(p + 2, 46);

	ssl->handshake->pmslen = 48;

	if (ssl->session_negotiate->peer_cert == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(2, ("certificate required"));
		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}

	/*
	 * Now write it out, encrypted
	 */
	if (!jhd_tls_pk_can_do(&ssl->session_negotiate->peer_cert->pk, JHD_TLS_PK_RSA)) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("certificate key type mismatch"));
		return ( JHD_TLS_ERR_SSL_PK_TYPE_MISMATCH);
	}

	if ((ret = jhd_tls_pk_encrypt(&ssl->session_negotiate->peer_cert->pk, p, ssl->handshake->pmslen, ssl->out_msg + offset + len_bytes, olen,
	JHD_TLS_SSL_MAX_CONTENT_LEN - offset - len_bytes)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_rsa_pkcs1_encrypt", ret);
		return (ret);
	}

	if (len_bytes == 2) {
		ssl->out_msg[offset + 0] = (unsigned char) (*olen >> 8);
		ssl->out_msg[offset + 1] = (unsigned char) (*olen);
		*olen += 2;
	}

	return (0);
}

#if defined(JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED) ||                     \
    defined(JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED)
static int ssl_parse_signature_algorithm(jhd_tls_ssl_context *ssl, unsigned char **p, unsigned char *end, jhd_tls_md_type_t *md_alg, jhd_tls_pk_type_t *pk_alg) {
	((void) ssl);
	*md_alg = JHD_TLS_MD_NONE;
	*pk_alg = JHD_TLS_PK_NONE;

	/* Only in TLS 1.2 */
	if (ssl->minor_ver != JHD_TLS_SSL_MINOR_VERSION_3) {
		return (0);
	}

	if ((*p) + 2 > end)
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);

	/*
	 * Get hash algorithm
	 */
	if ((*md_alg = jhd_tls_ssl_md_alg_from_hash((*p)[0])) == JHD_TLS_MD_NONE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("Server used unsupported " "HashAlgorithm %d", *(p)[0]));
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
	}

	/*
	 * Get signature algorithm
	 */
	if ((*pk_alg = jhd_tls_ssl_pk_alg_from_sig((*p)[1])) == JHD_TLS_PK_NONE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("server used unsupported " "SignatureAlgorithm %d", (*p)[1]));
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
	}

	/*
	 * Check if the hash is acceptable
	 */
	if (jhd_tls_ssl_check_sig_hash(ssl, *md_alg) != 0) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("server used HashAlgorithm %d that was not offered", *(p)[0]));
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("Server used SignatureAlgorithm %d", (*p)[1]));
	JHD_TLS_SSL_DEBUG_MSG(2, ("Server used HashAlgorithm %d", (*p)[0]));
	*p += 2;

	return (0);
}
#endif /* JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED ||
          JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED */

static int ssl_parse_server_key_exchange(jhd_tls_ssl_context *ssl) {
	int ret;
	const jhd_tls_ssl_ciphersuite_t *ciphersuite_info = ssl->transform_negotiate->ciphersuite_info;
	unsigned char *p = NULL, *end = NULL;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> parse server key exchange"));

	if (ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_RSA) {
		JHD_TLS_SSL_DEBUG_MSG(2, ("<= skip parse server key exchange"));
		ssl->state++;
		return (0);
	}
	((void) p);
	((void) end);

	if ((ret = jhd_tls_ssl_read_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_read_record", ret);
		return (ret);
	}

	if (ssl->in_msgtype != JHD_TLS_SSL_MSG_HANDSHAKE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_UNEXPECTED_MESSAGE);
		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}

	/*
	 * ServerKeyExchange may be skipped with PSK and RSA-PSK when the server
	 * doesn't use a psk_identity_hint
	 */
	if (ssl->in_msg[0] != JHD_TLS_SSL_HS_SERVER_KEY_EXCHANGE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("server key exchange message must " "not be skipped"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_UNEXPECTED_MESSAGE);

		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}

	p = ssl->in_msg + jhd_tls_ssl_hs_hdr_len(ssl);
	end = ssl->in_msg + ssl->in_hslen;
	JHD_TLS_SSL_DEBUG_BUF(3, "server key exchange", p, end - p);

#if defined(JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED) ||                     \
    defined(JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED)
	if (ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_ECDHE_RSA || ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA) {
		if (ssl_parse_server_ecdh_params(ssl, &p, end) != 0) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
		}
	} else
#endif /* JHD_TLS_KEY_EXCHANGE_ECDHE_RSA_ENABLED ||
          JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA_ENABLED */
	{
		JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
		return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
	}

	if (jhd_tls_ssl_ciphersuite_uses_server_signature(ciphersuite_info)) {
		size_t sig_len, hashlen;
		unsigned char hash[64];
		jhd_tls_md_type_t md_alg = JHD_TLS_MD_NONE;
		jhd_tls_pk_type_t pk_alg = JHD_TLS_PK_NONE;
		unsigned char *params = ssl->in_msg + jhd_tls_ssl_hs_hdr_len(ssl);
		size_t params_len = p - params;

		/*
		 * Handle the digitally-signed structure
		 */

		if (ssl->minor_ver == JHD_TLS_SSL_MINOR_VERSION_3) {
			if (ssl_parse_signature_algorithm(ssl, &p, end, &md_alg, &pk_alg) != 0) {
				JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
				jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
				JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
				return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
			}

			if (pk_alg != jhd_tls_ssl_get_ciphersuite_sig_pk_alg(ciphersuite_info)) {
				JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
				jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
				JHD_TLS_SSL_ALERT_MSG_ILLEGAL_PARAMETER);
				return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
			}
		} else

#if  defined(JHD_TLS_SSL_PROTO_TLS1) || defined(JHD_TLS_SSL_PROTO_TLS1_1)
		if (ssl->minor_ver < JHD_TLS_SSL_MINOR_VERSION_3) {
			pk_alg = jhd_tls_ssl_get_ciphersuite_sig_pk_alg(ciphersuite_info);

			/* Default hash for ECDSA is SHA-1 */
			if (pk_alg == JHD_TLS_PK_ECDSA && md_alg == JHD_TLS_MD_NONE)
				md_alg = JHD_TLS_MD_SHA1;
		} else
#endif
		{
			JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
			return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
		}

		/*
		 * Read signature
		 */

		if (p > end - 2) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
		}
		sig_len = (p[0] << 8) | p[1];
		p += 2;

		if (p != end - sig_len) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_KEY_EXCHANGE);
		}

		JHD_TLS_SSL_DEBUG_BUF(3, "signature", p, sig_len);

		/*
		 * Compute the hash that has been signed
		 */
#if  defined(JHD_TLS_SSL_PROTO_TLS1) ||  defined(JHD_TLS_SSL_PROTO_TLS1_1)
		if (md_alg == JHD_TLS_MD_NONE) {
			hashlen = 36;
			ret = jhd_tls_ssl_get_key_exchange_md_ssl_tls(ssl, hash, params, params_len);
			if (ret != 0)
				return (ret);
		} else
#endif /*  JHD_TLS_SSL_PROTO_TLS1 || JHD_TLS_SSL_PROTO_TLS1_1 */

		if (md_alg != JHD_TLS_MD_NONE) {
			ret = jhd_tls_ssl_get_key_exchange_md_tls1_2(ssl, hash, &hashlen, params, params_len, md_alg);
			if (ret != 0)
				return (ret);
		} else {
			JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
			return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
		}

		JHD_TLS_SSL_DEBUG_BUF(3, "parameters hash", hash, hashlen);

		if (ssl->session_negotiate->peer_cert == NULL) {
			JHD_TLS_SSL_DEBUG_MSG(2, ("certificate required"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
			return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
		}

		/*
		 * Verify signature
		 */
		if (!jhd_tls_pk_can_do(&ssl->session_negotiate->peer_cert->pk, pk_alg)) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server key exchange message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_HANDSHAKE_FAILURE);
			return ( JHD_TLS_ERR_SSL_PK_TYPE_MISMATCH);
		}

		if ((ret = jhd_tls_pk_verify(&ssl->session_negotiate->peer_cert->pk, md_alg, hash, hashlen, p, sig_len)) != 0) {
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
			JHD_TLS_SSL_ALERT_MSG_DECRYPT_ERROR);
			JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_pk_verify", ret);
			return (ret);
		}
	}

	ssl->state++;

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= parse server key exchange"));

	return (0);
}

#if ! defined(JHD_TLS_KEY_EXCHANGE__CERT_REQ_ALLOWED__ENABLED)
static int ssl_parse_certificate_request( jhd_tls_ssl_context *ssl )
{
	const jhd_tls_ssl_ciphersuite_t *ciphersuite_info =
	ssl->transform_negotiate->ciphersuite_info;

	JHD_TLS_SSL_DEBUG_MSG( 2, ( "=> parse certificate request" ) );

	if( ! jhd_tls_ssl_ciphersuite_cert_req_allowed( ciphersuite_info ) )
	{
		JHD_TLS_SSL_DEBUG_MSG( 2, ( "<= skip parse certificate request" ) );
		ssl->state++;
		return( 0 );
	}

	JHD_TLS_SSL_DEBUG_MSG( 1, ( "should never happen" ) );
	return( JHD_TLS_ERR_SSL_INTERNAL_ERROR );
}
#else /* JHD_TLS_KEY_EXCHANGE__CERT_REQ_ALLOWED__ENABLED */
static int ssl_parse_certificate_request(jhd_tls_ssl_context *ssl) {
	int ret;
	unsigned char *buf;
	size_t n = 0;
	size_t cert_type_len = 0, dn_len = 0;

	if ((ret = jhd_tls_ssl_read_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_read_record", ret);
		return (ret);
	}
	if (ssl->in_msgtype != JHD_TLS_SSL_MSG_HANDSHAKE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad certificate request message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_UNEXPECTED_MESSAGE);
		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}
	ssl->state++;
	if ((ssl->in_msg[0] != JHD_TLS_SSL_HS_CERTIFICATE_REQUEST)) {
		JHD_TLS_SSL_DEBUG_MSG(2, ("=> parse server hello done"));
		ssl->client_auth = 0;
		if (ssl->in_hslen != jhd_tls_ssl_hs_hdr_len(ssl) || ssl->in_msg[0] != JHD_TLS_SSL_HS_SERVER_HELLO_DONE) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello done message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO_DONE);
		}

		ssl->state++;

		JHD_TLS_SSL_DEBUG_MSG(2, ("<= parse server hello done"));

		return (0);

	}
	JHD_TLS_SSL_DEBUG_MSG(2, ("=> parse certificate request"));
	ssl->client_auth = 1;
	/*
	 *  struct {
	 *      ClientCertificateType certificate_types<1..2^8-1>;
	 *      SignatureAndHashAlgorithm
	 *        supported_signature_algorithms<2^16-1>; -- TLS 1.2 only
	 *      DistinguishedName certificate_authorities<0..2^16-1>;
	 *  } CertificateRequest;
	 *
	 *  Since we only support a single certificate on clients, let's just
	 *  ignore all the information that's supposed to help us pick a
	 *  certificate.
	 *
	 *  We could check that our certificate matches the request, and bail out
	 *  if it doesn't, but it's simpler to just send the certificate anyway,
	 *  and give the server the opportunity to decide if it should terminate
	 *  the connection when it doesn't like our certificate.
	 *
	 *  Same goes for the hash in TLS 1.2's signature_algorithms: at this
	 *  point we only have one hash available (see comments in
	 *  write_certificate_verify), so let's just use what we have.
	 *
	 *  However, we still minimally parse the message to check it is at least
	 *  superficially sane.
	 */
	buf = ssl->in_msg;

	/* certificate_types */
	if (ssl->in_hslen <= jhd_tls_ssl_hs_hdr_len(ssl)) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad certificate request message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_CERTIFICATE_REQUEST);
	}
	cert_type_len = buf[jhd_tls_ssl_hs_hdr_len(ssl)];
	n = cert_type_len;

	/*
	 * In the subsequent code there are two paths that read from buf:
	 *     * the length of the signature algorithms field (if minor version of
	 *       SSL is 3),
	 *     * distinguished name length otherwise.
	 * Both reach at most the index:
	 *    ...hdr_len + 2 + n,
	 * therefore the buffer length at this point must be greater than that
	 * regardless of the actual code path.
	 */
	if (ssl->in_hslen <= jhd_tls_ssl_hs_hdr_len(ssl) + 2 + n) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad certificate request message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_CERTIFICATE_REQUEST);
	}

	/* supported_signature_algorithms */

	if (ssl->minor_ver == JHD_TLS_SSL_MINOR_VERSION_3) {
		size_t sig_alg_len = ((buf[jhd_tls_ssl_hs_hdr_len(ssl) + 1 + n] << 8) | (buf[jhd_tls_ssl_hs_hdr_len(ssl) + 2 + n]));
#if defined(JHD_TLS_DEBUG_C)
		unsigned char* sig_alg;
		size_t i;
#endif

		/*
		 * The furthest access in buf is in the loop few lines below:
		 *     sig_alg[i + 1],
		 * where:
		 *     sig_alg = buf + ...hdr_len + 3 + n,
		 *     max(i) = sig_alg_len - 1.
		 * Therefore the furthest access is:
		 *     buf[...hdr_len + 3 + n + sig_alg_len - 1 + 1],
		 * which reduces to:
		 *     buf[...hdr_len + 3 + n + sig_alg_len],
		 * which is one less than we need the buf to be.
		 */
		if (ssl->in_hslen <= jhd_tls_ssl_hs_hdr_len(ssl) + 3 + n + sig_alg_len) {
			JHD_TLS_SSL_DEBUG_MSG(1, ("bad certificate request message"));
			jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL, JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
			return ( JHD_TLS_ERR_SSL_BAD_HS_CERTIFICATE_REQUEST);
		}
#if defined(JHD_TLS_DEBUG_C)
		sig_alg = buf + jhd_tls_ssl_hs_hdr_len(ssl) + 3 + n;
		for (i = 0; i < sig_alg_len; i += 2) {
			(void) sig_alg;
			JHD_TLS_SSL_DEBUG_MSG(3, ("Supported Signature Algorithm found: %d" ",%d", sig_alg[i], sig_alg[i + 1]));
		}
#endif

		n += 2 + sig_alg_len;
	}

	/* certificate_authorities */
	dn_len = ((buf[jhd_tls_ssl_hs_hdr_len(ssl) + 1 + n] << 8) | (buf[jhd_tls_ssl_hs_hdr_len(ssl) + 2 + n]));

	n += dn_len;
	if (ssl->in_hslen != jhd_tls_ssl_hs_hdr_len(ssl) + 3 + n) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad certificate request message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_CERTIFICATE_REQUEST);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= parse certificate request"));

	return (0);

}
#endif /* JHD_TLS_KEY_EXCHANGE__CERT_REQ_ALLOWED__ENABLED */

static int ssl_parse_server_hello_done(jhd_tls_ssl_context *ssl) {
	int ret;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> parse server hello done"));

	if ((ret = jhd_tls_ssl_read_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_read_record", ret);
		return (ret);
	}

	if (ssl->in_msgtype != JHD_TLS_SSL_MSG_HANDSHAKE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello done message"));
		return ( JHD_TLS_ERR_SSL_UNEXPECTED_MESSAGE);
	}

	if (ssl->in_hslen != jhd_tls_ssl_hs_hdr_len(ssl) || ssl->in_msg[0] != JHD_TLS_SSL_HS_SERVER_HELLO_DONE) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("bad server hello done message"));
		jhd_tls_ssl_send_alert_message(ssl, JHD_TLS_SSL_ALERT_LEVEL_FATAL,
		JHD_TLS_SSL_ALERT_MSG_DECODE_ERROR);
		return ( JHD_TLS_ERR_SSL_BAD_HS_SERVER_HELLO_DONE);
	}

	ssl->state++;

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= parse server hello done"));

	return (0);
}

static int ssl_write_client_key_exchange(jhd_tls_ssl_context *ssl) {
	int ret;
	size_t i, n;
	const jhd_tls_ssl_ciphersuite_t *ciphersuite_info = ssl->transform_negotiate->ciphersuite_info;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> write client key exchange"));

	if (ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_ECDHE_RSA || ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_ECDHE_ECDSA) {
		/*
		 * ECDH key exchange -- send client public value
		 */
		i = 4;

		ret = jhd_tls_ecdh_make_public(&ssl->handshake->ecdh_ctx, &n, &ssl->out_msg[i], 1000);
		if (ret != 0) {
			JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ecdh_make_public", ret);
			return (ret);
		}

		JHD_TLS_SSL_DEBUG_ECP(3, "ECDH: Q", &ssl->handshake->ecdh_ctx.Q);

		if ((ret = jhd_tls_ecdh_calc_secret(&ssl->handshake->ecdh_ctx, &ssl->handshake->pmslen, ssl->handshake->premaster,
		JHD_TLS_MPI_MAX_SIZE)) != 0) {
			JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ecdh_calc_secret", ret);
			return (ret);
		}

		JHD_TLS_SSL_DEBUG_MPI(3, "ECDH: z", &ssl->handshake->ecdh_ctx.z);
	} else

	if (ciphersuite_info->key_exchange == JHD_TLS_KEY_EXCHANGE_RSA) {
		i = 4;
		if ((ret = ssl_write_encrypted_pms(ssl, i, &n, 0)) != 0)
			return (ret);
	} else {
		((void) ciphersuite_info);
		JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
		return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
	}

	ssl->out_msglen = i + n;
	ssl->out_msgtype = JHD_TLS_SSL_MSG_HANDSHAKE;
	ssl->out_msg[0] = JHD_TLS_SSL_HS_CLIENT_KEY_EXCHANGE;

	ssl->state++;

	if ((ret = jhd_tls_ssl_write_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_write_record", ret);
		return (ret);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= write client key exchange"));

	return (0);
}

static int ssl_write_certificate_verify(jhd_tls_ssl_context *ssl) {
	int ret = JHD_TLS_ERR_SSL_FEATURE_UNAVAILABLE;
//	const jhd_tls_ssl_ciphersuite_t *ciphersuite_info = ssl->transform_negotiate->ciphersuite_info;
	size_t n = 0, offset = 0;
	unsigned char hash[48];
	unsigned char *hash_start = hash;
	jhd_tls_md_type_t md_alg = JHD_TLS_MD_NONE;
	unsigned int hashlen;

	JHD_TLS_SSL_DEBUG_MSG(2, ("=> write certificate verify"));

	if ((ret = jhd_tls_ssl_derive_keys(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_derive_keys", ret);
		return (ret);
	}

	if (ssl->client_auth == 0 || jhd_tls_ssl_own_cert(ssl) == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(2, ("<= skip write certificate verify"));
		ssl->state++;
		return (0);
	}

	if (jhd_tls_ssl_own_key(ssl) == NULL) {
		JHD_TLS_SSL_DEBUG_MSG(1, ("got no private key for certificate"));
		return ( JHD_TLS_ERR_SSL_PRIVATE_KEY_REQUIRED);
	}

	/*
	 * Make an RSA signature of the handshake digests
	 */
	ssl->handshake->calc_verify(ssl, hash);

	if (ssl->minor_ver != JHD_TLS_SSL_MINOR_VERSION_3) {
		/*
		 * digitally-signed struct {
		 *     opaque md5_hash[16];
		 *     opaque sha_hash[20];
		 * };
		 *
		 * md5_hash
		 *     MD5(handshake_messages);
		 *
		 * sha_hash
		 *     SHA(handshake_messages);
		 */
		hashlen = 36;
		md_alg = JHD_TLS_MD_NONE;

		/*
		 * For ECDSA, default hash is SHA-1 only
		 */
		if (jhd_tls_pk_can_do(jhd_tls_ssl_own_key(ssl), JHD_TLS_PK_ECDSA)) {
			hash_start += 16;
			hashlen -= 16;
			md_alg = JHD_TLS_MD_SHA1;
		}
	} else

	if (ssl->minor_ver == JHD_TLS_SSL_MINOR_VERSION_3) {
		/*
		 * digitally-signed struct {
		 *     opaque handshake_messages[handshake_messages_length];
		 * };
		 *
		 * Taking shortcut here. We assume that the server always allows the
		 * PRF Hash function and has sent it in the allowed signature
		 * algorithms list received in the Certificate Request message.
		 *
		 * Until we encounter a server that does not, we will take this
		 * shortcut.
		 *
		 * Reason: Otherwise we should have running hashes for SHA512 and SHA224
		 *         in order to satisfy 'weird' needs from the server side.
		 */
		if (ssl->transform_negotiate->ciphersuite_info->mac == JHD_TLS_MD_SHA384) {
			md_alg = JHD_TLS_MD_SHA384;
			ssl->out_msg[4] = JHD_TLS_SSL_HASH_SHA384;
		} else {
			md_alg = JHD_TLS_MD_SHA256;
			ssl->out_msg[4] = JHD_TLS_SSL_HASH_SHA256;
		}
		ssl->out_msg[5] = jhd_tls_ssl_sig_from_pk(jhd_tls_ssl_own_key(ssl));

		/* Info from md_alg will be used instead */
		hashlen = 0;
		offset = 2;
	} else

	{
		JHD_TLS_SSL_DEBUG_MSG(1, ("should never happen"));
		return ( JHD_TLS_ERR_SSL_INTERNAL_ERROR);
	}

	if ((ret = jhd_tls_pk_sign(jhd_tls_ssl_own_key(ssl), md_alg, hash_start, hashlen, ssl->out_msg + 6 + offset, &n)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_pk_sign", ret);
		return (ret);
	}

	ssl->out_msg[4 + offset] = (unsigned char) (n >> 8);
	ssl->out_msg[5 + offset] = (unsigned char) (n);

	ssl->out_msglen = 6 + n + offset;
	ssl->out_msgtype = JHD_TLS_SSL_MSG_HANDSHAKE;
	ssl->out_msg[0] = JHD_TLS_SSL_HS_CERTIFICATE_VERIFY;

	ssl->state++;

	if ((ret = jhd_tls_ssl_write_record(ssl)) != 0) {
		JHD_TLS_SSL_DEBUG_RET(1, "jhd_tls_ssl_write_record", ret);
		return (ret);
	}

	JHD_TLS_SSL_DEBUG_MSG(2, ("<= write certificate verify"));

	return (ret);
}

/*
 * SSL handshake -- client side -- single step
 */
int jhd_tls_ssl_handshake_client_step(jhd_tls_ssl_context *ssl) {
	int ret = 0;

	if (ssl->state == JHD_TLS_SSL_HANDSHAKE_OVER || ssl->handshake == NULL)
		return ( JHD_TLS_ERR_SSL_BAD_INPUT_DATA);

	JHD_TLS_SSL_DEBUG_MSG(2, ("client state: %d", ssl->state));

	if ((ret = jhd_tls_ssl_flush_output(ssl)) != 0)
		return (ret);

	switch (ssl->state) {
		case JHD_TLS_SSL_HELLO_REQUEST:
			ssl->state = JHD_TLS_SSL_CLIENT_HELLO;
			break;

			/*
			 *  ==>   ClientHello
			 */
		case JHD_TLS_SSL_CLIENT_HELLO:
			ret = ssl_write_client_hello(ssl);
			break;

			/*
			 *  <==   ServerHello
			 *        Certificate
			 *      ( ServerKeyExchange  )
			 *      ( CertificateRequest )
			 *        ServerHelloDone
			 */
		case JHD_TLS_SSL_SERVER_HELLO:
			ret = ssl_parse_server_hello(ssl);
			break;

		case JHD_TLS_SSL_SERVER_CERTIFICATE:
			ret = jhd_tls_ssl_parse_certificate(ssl);
			break;

		case JHD_TLS_SSL_SERVER_KEY_EXCHANGE:
			ret = ssl_parse_server_key_exchange(ssl);
			break;

		case JHD_TLS_SSL_CERTIFICATE_REQUEST:
			ret = ssl_parse_certificate_request(ssl);
			break;

		case JHD_TLS_SSL_SERVER_HELLO_DONE:
			ret = ssl_parse_server_hello_done(ssl);
			break;

			/*
			 *  ==> ( Certificate/Alert  )
			 *        ClientKeyExchange
			 *      ( CertificateVerify  )
			 *        ChangeCipherSpec
			 *        Finished
			 */
		case JHD_TLS_SSL_CLIENT_CERTIFICATE:
			ret = jhd_tls_ssl_write_certificate(ssl);
			break;

		case JHD_TLS_SSL_CLIENT_KEY_EXCHANGE:
			ret = ssl_write_client_key_exchange(ssl);
			break;

		case JHD_TLS_SSL_CERTIFICATE_VERIFY:
			ret = ssl_write_certificate_verify(ssl);
			break;

		case JHD_TLS_SSL_CLIENT_CHANGE_CIPHER_SPEC:
			ret = jhd_tls_ssl_write_change_cipher_spec(ssl);
			break;

		case JHD_TLS_SSL_CLIENT_FINISHED:
			ret = jhd_tls_ssl_write_finished(ssl);
			break;

		case JHD_TLS_SSL_SERVER_CHANGE_CIPHER_SPEC:
			ret = jhd_tls_ssl_parse_change_cipher_spec(ssl);
			break;

		case JHD_TLS_SSL_SERVER_FINISHED:
			ret = jhd_tls_ssl_parse_finished(ssl);
			break;

		case JHD_TLS_SSL_FLUSH_BUFFERS:
			JHD_TLS_SSL_DEBUG_MSG(2, ("handshake: done"));
			ssl->state = JHD_TLS_SSL_HANDSHAKE_WRAPUP;
			break;

		case JHD_TLS_SSL_HANDSHAKE_WRAPUP:
			jhd_tls_ssl_handshake_wrapup(ssl);
			break;

		default:
			JHD_TLS_SSL_DEBUG_MSG(1, ("invalid state %d", ssl->state));
			return ( JHD_TLS_ERR_SSL_BAD_INPUT_DATA);
	}

	return (ret);
}
#endif /* JHD_TLS_SSL_CLI_C */
