#ifndef JHD_TLS_MD_WRAP_H
#define JHD_TLS_MD_WRAP_H

#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_md.h>



struct jhd_tls_md_info_t
{
    /** Digest identifier */
    jhd_tls_md_type_t type;

    /** Name of the message digest */
    const char * name;

    /** Output length of the digest function in bytes */
    int size;

    /** Block length of the digest function in bytes */
    int block_size;

    /** Digest initialisation function */
    void (*starts_func)( void *ctx );

    /** Digest update function */
    void (*update_func)( void *ctx, const unsigned char *input, size_t ilen );

    /** Digest finalisation function */
    void (*finish_func)( void *ctx, unsigned char *output );

    /** Generic digest function */
    void (*digest_func)( const unsigned char *input, size_t ilen,unsigned char *output );

    /** Allocate a new context */
    void * (*ctx_alloc_func)( void );

    /** Free the given context */
    void (*ctx_free_func)( void *ctx );

    /** Internal use only */
    void (*process_func)( void *ctx, const unsigned char *input );
};


extern const jhd_tls_md_info_t jhd_tls_md5_info;

extern const jhd_tls_md_info_t jhd_tls_ripemd160_info;

extern const jhd_tls_md_info_t jhd_tls_sha1_info;

extern const jhd_tls_md_info_t jhd_tls_sha224_info;
extern const jhd_tls_md_info_t jhd_tls_sha256_info;

extern const jhd_tls_md_info_t jhd_tls_sha384_info;
extern const jhd_tls_md_info_t jhd_tls_sha512_info;
#endif /* JHD_TLS_MD_WRAP_H */
