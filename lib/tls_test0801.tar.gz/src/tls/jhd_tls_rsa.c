#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_rsa.h>
#include <tls/jhd_tls_rsa_internal.h>
#include <tls/jhd_tls_oid.h>
#include <tls/jhd_tls_ctr_drbg.h>
#include <string.h>

#if defined(JHD_TLS_PKCS1_V21)
#include <tls/jhd_tls_md.h>
#endif

#if defined(JHD_TLS_PKCS1_V15) && !defined(__OpenBSD__)
#include <stdlib.h>
#endif

#include <tls/jhd_tls_platform.h>

#if !defined(JHD_TLS_RSA_ALT)

#if defined(JHD_TLS_PKCS1_V15)
/* constant-time buffer comparison */
static inline int jhd_tls_safer_memcmp(const void *a, const void *b, size_t n) {
	size_t i;
	const unsigned char *A = (const unsigned char *) a;
	const unsigned char *B = (const unsigned char *) b;
	unsigned char diff = 0;

	for (i = 0; i < n; i++)
		diff |= A[i] ^ B[i];

	return (diff);
}
#endif /* JHD_TLS_PKCS1_V15 */

int jhd_tls_rsa_import(jhd_tls_rsa_context *ctx, const jhd_tls_mpi *N, const jhd_tls_mpi *P, const jhd_tls_mpi *Q, const jhd_tls_mpi *D, const jhd_tls_mpi *E) {
	int ret;

	if ((N != NULL && (ret = jhd_tls_mpi_copy(&ctx->N, N)) != 0) || (P != NULL && (ret = jhd_tls_mpi_copy(&ctx->P, P)) != 0) || (Q != NULL && (ret =
	        jhd_tls_mpi_copy(&ctx->Q, Q)) != 0) || (D != NULL && (ret = jhd_tls_mpi_copy(&ctx->D, D)) != 0)
	        || (E != NULL && (ret = jhd_tls_mpi_copy(&ctx->E, E)) != 0)) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);
	}

	if (N != NULL)
		ctx->len = jhd_tls_mpi_size(&ctx->N);

	return (0);
}

int jhd_tls_rsa_import_raw(jhd_tls_rsa_context *ctx, unsigned char const *N, size_t N_len, unsigned char const *P, size_t P_len, unsigned char const *Q,
        size_t Q_len, unsigned char const *D, size_t D_len, unsigned char const *E, size_t E_len) {
	int ret = 0;

	if (N != NULL) {
		JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&ctx->N, N, N_len));
		ctx->len = jhd_tls_mpi_size(&ctx->N);
	}

	if (P != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&ctx->P, P, P_len));

	if (Q != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&ctx->Q, Q, Q_len));

	if (D != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&ctx->D, D, D_len));

	if (E != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&ctx->E, E, E_len));

	cleanup:

	if (ret != 0)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);

	return (0);
}

/*
 * Checks whether the context fields are set in such a way
 * that the RSA primitives will be able to execute without error.
 * It does *not* make guarantees for consistency of the parameters.
 */
static int rsa_check_context(jhd_tls_rsa_context const *ctx, int is_priv, int blinding_needed) {
#if !defined(JHD_TLS_RSA_NO_CRT)
	/* blinding_needed is only used for NO_CRT to decide whether
	 * P,Q need to be present or not. */
	((void) blinding_needed);
#endif

	if (ctx->len != jhd_tls_mpi_size(&ctx->N) || ctx->len > JHD_TLS_MPI_MAX_SIZE) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}

	/*
	 * 1. Modular exponentiation needs positive, odd moduli.
	 */

	/* Modular exponentiation wrt. N is always used for
	 * RSA public key operations. */
	if (jhd_tls_mpi_cmp_int(&ctx->N, 0) <= 0 || jhd_tls_mpi_get_bit(&ctx->N, 0) == 0) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}

#if !defined(JHD_TLS_RSA_NO_CRT)
	/* Modular exponentiation for P and Q is only
	 * used for private key operations and if CRT
	 * is used. */
	if (is_priv
	        && (jhd_tls_mpi_cmp_int(&ctx->P, 0) <= 0 || jhd_tls_mpi_get_bit(&ctx->P, 0) == 0 || jhd_tls_mpi_cmp_int(&ctx->Q, 0) <= 0
	                || jhd_tls_mpi_get_bit(&ctx->Q, 0) == 0)) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}
#endif /* !JHD_TLS_RSA_NO_CRT */

	/*
	 * 2. Exponents must be positive
	 */

	/* Always need E for public key operations */
	if (jhd_tls_mpi_cmp_int(&ctx->E, 0) <= 0)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

#if defined(JHD_TLS_RSA_NO_CRT)
	/* For private key operations, use D or DP & DQ
	 * as (unblinded) exponents. */
	if( is_priv && jhd_tls_mpi_cmp_int( &ctx->D, 0 ) <= 0 )
	return( JHD_TLS_ERR_RSA_BAD_INPUT_DATA );
#else
	if (is_priv && (jhd_tls_mpi_cmp_int(&ctx->DP, 0) <= 0 || jhd_tls_mpi_cmp_int(&ctx->DQ, 0) <= 0)) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}
#endif /* JHD_TLS_RSA_NO_CRT */

	/* Blinding shouldn't make exponents negative either,
	 * so check that P, Q >= 1 if that hasn't yet been
	 * done as part of 1. */
#if defined(JHD_TLS_RSA_NO_CRT)
	if( is_priv && blinding_needed &&
			( jhd_tls_mpi_cmp_int( &ctx->P, 0 ) <= 0 ||
					jhd_tls_mpi_cmp_int( &ctx->Q, 0 ) <= 0 ) )
	{
		return( JHD_TLS_ERR_RSA_BAD_INPUT_DATA );
	}
#endif

	/* It wouldn't lead to an error if it wasn't satisfied,
	 * but check for QP >= 1 nonetheless. */
#if !defined(JHD_TLS_RSA_NO_CRT)
	if (is_priv && jhd_tls_mpi_cmp_int(&ctx->QP, 0) <= 0) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}
#endif

	return (0);
}

int jhd_tls_rsa_complete(jhd_tls_rsa_context *ctx) {
	int ret = 0;

	const int have_N = (jhd_tls_mpi_cmp_int(&ctx->N, 0) != 0);
	const int have_P = (jhd_tls_mpi_cmp_int(&ctx->P, 0) != 0);
	const int have_Q = (jhd_tls_mpi_cmp_int(&ctx->Q, 0) != 0);
	const int have_D = (jhd_tls_mpi_cmp_int(&ctx->D, 0) != 0);
	const int have_E = (jhd_tls_mpi_cmp_int(&ctx->E, 0) != 0);

	/*
	 * Check whether provided parameters are enough
	 * to deduce all others. The following incomplete
	 * parameter sets for private keys are supported:
	 *
	 * (1) P, Q missing.
	 * (2) D and potentially N missing.
	 *
	 */

	const int n_missing = have_P && have_Q && have_D && have_E;
	const int pq_missing = have_N && !have_P && !have_Q && have_D && have_E;
	const int d_missing = have_P && have_Q && !have_D && have_E;
	const int is_pub = have_N && !have_P && !have_Q && !have_D && have_E;

	/* These three alternatives are mutually exclusive */
	const int is_priv = n_missing || pq_missing || d_missing;

	if (!is_priv && !is_pub)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	/*
	 * Step 1: Deduce N if P, Q are provided.
	 */

	if (!have_N && have_P && have_Q) {
		if ((ret = jhd_tls_mpi_mul_mpi(&ctx->N, &ctx->P, &ctx->Q)) != 0) {
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);
		}

		ctx->len = jhd_tls_mpi_size(&ctx->N);
	}

	/*
	 * Step 2: Deduce and verify all remaining core parameters.
	 */

	if (pq_missing) {
		ret = jhd_tls_rsa_deduce_primes(&ctx->N, &ctx->E, &ctx->D, &ctx->P, &ctx->Q);
		if (ret != 0)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);

	} else if (d_missing) {
		if ((ret = jhd_tls_rsa_deduce_private_exponent(&ctx->P, &ctx->Q, &ctx->E, &ctx->D)) != 0) {
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);
		}
	}

	/*
	 * Step 3: Deduce all additional parameters specific
	 *         to our current RSA implementation.
	 */

#if !defined(JHD_TLS_RSA_NO_CRT)
	if (is_priv) {
		ret = jhd_tls_rsa_deduce_crt(&ctx->P, &ctx->Q, &ctx->D, &ctx->DP, &ctx->DQ, &ctx->QP);
		if (ret != 0)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);
	}
#endif /* JHD_TLS_RSA_NO_CRT */

	/*
	 * Step 3: Basic sanity checks
	 */

	return (rsa_check_context(ctx, is_priv, 1));
}

int jhd_tls_rsa_export_raw(const jhd_tls_rsa_context *ctx, unsigned char *N, size_t N_len, unsigned char *P, size_t P_len, unsigned char *Q, size_t Q_len,
        unsigned char *D, size_t D_len, unsigned char *E, size_t E_len) {
	int ret = 0;

	/* Check if key is private or public */
	const int is_priv = jhd_tls_mpi_cmp_int(&ctx->N, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->P, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->Q, 0) != 0
	        && jhd_tls_mpi_cmp_int(&ctx->D, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->E, 0) != 0;

	if (!is_priv) {
		/* If we're trying to export private parameters for a public key,
		 * something must be wrong. */
		if (P != NULL || Q != NULL || D != NULL)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	}

	if (N != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&ctx->N, N, N_len));

	if (P != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&ctx->P, P, P_len));

	if (Q != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&ctx->Q, Q, Q_len));

	if (D != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&ctx->D, D, D_len));

	if (E != NULL)
		JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&ctx->E, E, E_len));

	cleanup:

	return (ret);
}

int jhd_tls_rsa_export(const jhd_tls_rsa_context *ctx, jhd_tls_mpi *N, jhd_tls_mpi *P, jhd_tls_mpi *Q, jhd_tls_mpi *D, jhd_tls_mpi *E) {
	int ret;

	/* Check if key is private or public */
	int is_priv = jhd_tls_mpi_cmp_int(&ctx->N, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->P, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->Q, 0) != 0
	        && jhd_tls_mpi_cmp_int(&ctx->D, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->E, 0) != 0;

	if (!is_priv) {
		/* If we're trying to export private parameters for a public key,
		 * something must be wrong. */
		if (P != NULL || Q != NULL || D != NULL)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	}

	/* Export all requested core parameters. */

	if ((N != NULL && (ret = jhd_tls_mpi_copy(N, &ctx->N)) != 0) || (P != NULL && (ret = jhd_tls_mpi_copy(P, &ctx->P)) != 0) || (Q != NULL && (ret =
	        jhd_tls_mpi_copy(Q, &ctx->Q)) != 0) || (D != NULL && (ret = jhd_tls_mpi_copy(D, &ctx->D)) != 0)
	        || (E != NULL && (ret = jhd_tls_mpi_copy(E, &ctx->E)) != 0)) {
		return (ret);
	}

	return (0);
}

/*
 * Export CRT parameters
 * This must also be implemented if CRT is not used, for being able to
 * write DER encoded RSA keys. The helper function jhd_tls_rsa_deduce_crt
 * can be used in this case.
 */
int jhd_tls_rsa_export_crt(const jhd_tls_rsa_context *ctx, jhd_tls_mpi *DP, jhd_tls_mpi *DQ, jhd_tls_mpi *QP) {
	int ret;

	/* Check if key is private or public */
	int is_priv = jhd_tls_mpi_cmp_int(&ctx->N, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->P, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->Q, 0) != 0
	        && jhd_tls_mpi_cmp_int(&ctx->D, 0) != 0 && jhd_tls_mpi_cmp_int(&ctx->E, 0) != 0;

	if (!is_priv)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

#if !defined(JHD_TLS_RSA_NO_CRT)
	/* Export all requested blinding parameters. */
	if ((DP != NULL && (ret = jhd_tls_mpi_copy(DP, &ctx->DP)) != 0) || (DQ != NULL && (ret = jhd_tls_mpi_copy(DQ, &ctx->DQ)) != 0) || (QP != NULL && (ret =
	        jhd_tls_mpi_copy(QP, &ctx->QP)) != 0)) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret);
	}
#else
	if( ( ret = jhd_tls_rsa_deduce_crt( &ctx->P, &ctx->Q, &ctx->D,
							DP, DQ, QP ) ) != 0 )
	{
		return( JHD_TLS_ERR_RSA_BAD_INPUT_DATA + ret );
	}
#endif

	return (0);
}

/*
 * Initialize an RSA context
 */
void jhd_tls_rsa_init(jhd_tls_rsa_context *ctx, int padding, int hash_id) {
	memset(ctx, 0, sizeof(jhd_tls_rsa_context));

	jhd_tls_rsa_set_padding(ctx, padding, hash_id);

}

/*
 * Set padding for an existing RSA context
 */
void jhd_tls_rsa_set_padding(jhd_tls_rsa_context *ctx, int padding, int hash_id) {
	ctx->padding = padding;
	ctx->hash_id = hash_id;
}

/*
 * Get length in bytes of RSA modulus
 */

size_t jhd_tls_rsa_get_len(const jhd_tls_rsa_context *ctx) {
	return (ctx->len);
}

#if defined(JHD_TLS_GENPRIME)

/*
 * Generate an RSA keypair
 *
 * This generation method follows the RSA key pair generation procedure of
 * FIPS 186-4 if 2^16 < exponent < 2^256 and nbits = 2048 or nbits = 3072.
 */
int jhd_tls_rsa_gen_key(jhd_tls_rsa_context *ctx, unsigned int nbits, int exponent) {
	int ret;
	jhd_tls_mpi H, G, L;

	if (nbits < 128 || exponent < 3)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	if (nbits % 2)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	jhd_tls_mpi_init(&H);
	jhd_tls_mpi_init(&G);
	jhd_tls_mpi_init(&L);

	/*
	 * find primes P and Q with Q < P so that:
	 * 1.  |P-Q| > 2^( nbits / 2 - 100 )
	 * 2.  GCD( E, (P-1)*(Q-1) ) == 1
	 * 3.  E^-1 mod LCM(P-1, Q-1) > 2^( nbits / 2 )
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_lset(&ctx->E, exponent));

	do {
		JHD_TLS_MPI_CHK(jhd_tls_mpi_gen_prime(&ctx->P, nbits >> 1, 0));

		JHD_TLS_MPI_CHK(jhd_tls_mpi_gen_prime(&ctx->Q, nbits >> 1, 0));

		/* make sure the difference between p and q is not too small (FIPS 186-4 §B.3.3 step 5.4) */
		JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_mpi(&H, &ctx->P, &ctx->Q));
		if (jhd_tls_mpi_bitlen(&H) <= ((nbits >= 200) ? ((nbits >> 1) - 99) : 0))
			continue;

		/* not required by any standards, but some users rely on the fact that P > Q */
		if (H.s < 0)
			jhd_tls_mpi_swap(&ctx->P, &ctx->Q);

		/* Temporarily replace P,Q by P-1, Q-1 */
		JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_int(&ctx->P, &ctx->P, 1));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_int(&ctx->Q, &ctx->Q, 1));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&H, &ctx->P, &ctx->Q));

		/* check GCD( E, (P-1)*(Q-1) ) == 1 (FIPS 186-4 §B.3.1 criterion 2(a)) */
		JHD_TLS_MPI_CHK(jhd_tls_mpi_gcd(&G, &ctx->E, &H));
		if (jhd_tls_mpi_cmp_int(&G, 1) != 0)
			continue;

		/* compute smallest possible D = E^-1 mod LCM(P-1, Q-1) (FIPS 186-4 §B.3.1 criterion 3(b)) */
		JHD_TLS_MPI_CHK(jhd_tls_mpi_gcd(&G, &ctx->P, &ctx->Q));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_div_mpi( &L, NULL, &H, &G ));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_inv_mod(&ctx->D, &ctx->E, &L));

		if (jhd_tls_mpi_bitlen(&ctx->D) <= ((nbits + 1) / 2)) // (FIPS 186-4 §B.3.1 criterion 3(a))
			continue;

		break;
	} while (1);

	/* Restore P,Q */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_add_int(&ctx->P, &ctx->P, 1));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_add_int(&ctx->Q, &ctx->Q, 1));

	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&ctx->N, &ctx->P, &ctx->Q));

	ctx->len = jhd_tls_mpi_size(&ctx->N);

#if !defined(JHD_TLS_RSA_NO_CRT)
	/*
	 * DP = D mod (P - 1)
	 * DQ = D mod (Q - 1)
	 * QP = Q^-1 mod P
	 */
	JHD_TLS_MPI_CHK(jhd_tls_rsa_deduce_crt(&ctx->P, &ctx->Q, &ctx->D, &ctx->DP, &ctx->DQ, &ctx->QP));
#endif /* JHD_TLS_RSA_NO_CRT */

	/* Double-check */
	JHD_TLS_MPI_CHK(jhd_tls_rsa_check_privkey(ctx));

	cleanup:

	jhd_tls_mpi_free(&H);
	jhd_tls_mpi_free(&G);
	jhd_tls_mpi_free(&L);

	if (ret != 0) {
		jhd_tls_rsa_free(ctx);
		return ( JHD_TLS_ERR_RSA_KEY_GEN_FAILED + ret);
	}

	return (0);
}

#endif /* JHD_TLS_GENPRIME */

/*
 * Check a public RSA key
 */
int jhd_tls_rsa_check_pubkey(const jhd_tls_rsa_context *ctx) {
	if (rsa_check_context(ctx, 0 /* public */, 0 /* no blinding */) != 0)
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);

	if (jhd_tls_mpi_bitlen(&ctx->N) < 128) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

	if (jhd_tls_mpi_get_bit(&ctx->E, 0) == 0 || jhd_tls_mpi_bitlen(&ctx->E) < 2 || jhd_tls_mpi_cmp_mpi(&ctx->E, &ctx->N) >= 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

	return (0);
}

/*
 * Check for the consistency of all fields in an RSA private key context
 */
int jhd_tls_rsa_check_privkey(const jhd_tls_rsa_context *ctx) {
	if (jhd_tls_rsa_check_pubkey(ctx) != 0 || rsa_check_context(ctx, 1 /* private */, 1 /* blinding */) != 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

	if (jhd_tls_rsa_validate_params(&ctx->N, &ctx->P, &ctx->Q, &ctx->D, &ctx->E) != 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

#if !defined(JHD_TLS_RSA_NO_CRT)
	else if (jhd_tls_rsa_validate_crt(&ctx->P, &ctx->Q, &ctx->D, &ctx->DP, &ctx->DQ, &ctx->QP) != 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}
#endif

	return (0);
}

/*
 * Check if contexts holding a public and private key match
 */
int jhd_tls_rsa_check_pub_priv(const jhd_tls_rsa_context *pub, const jhd_tls_rsa_context *prv) {
	if (jhd_tls_rsa_check_pubkey(pub) != 0 || jhd_tls_rsa_check_privkey(prv) != 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

	if (jhd_tls_mpi_cmp_mpi(&pub->N, &prv->N) != 0 || jhd_tls_mpi_cmp_mpi(&pub->E, &prv->E) != 0) {
		return ( JHD_TLS_ERR_RSA_KEY_CHECK_FAILED);
	}

	return (0);
}

/*
 * Do an RSA public key operation
 */
int jhd_tls_rsa_public(jhd_tls_rsa_context *ctx, const unsigned char *input, unsigned char *output) {
	int ret;
	size_t olen;
	jhd_tls_mpi T;

	if (rsa_check_context(ctx, 0 /* public */, 0 /* no blinding */))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	jhd_tls_mpi_init(&T);

	JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&T, input, ctx->len));

	if (jhd_tls_mpi_cmp_mpi(&T, &ctx->N) >= 0) {
		ret = JHD_TLS_ERR_MPI_BAD_INPUT_DATA;
		goto cleanup;
	}

	olen = ctx->len;
	JHD_TLS_MPI_CHK(jhd_tls_mpi_exp_mod(&T, &T, &ctx->E, &ctx->N, &ctx->RN));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&T, output, olen));

	cleanup:

	jhd_tls_mpi_free(&T);

	if (ret != 0)
		return ( JHD_TLS_ERR_RSA_PUBLIC_FAILED + ret);

	return (0);
}

/*
 * Generate or update blinding values, see section 10 of:
 *  KOCHER, Paul C. Timing attacks on implementations of Diffie-Hellman, RSA,
 *  DSS, and other systems. In : Advances in Cryptology-CRYPTO'96. Springer
 *  Berlin Heidelberg, 1996. p. 104-113.
 */
static int rsa_prepare_blinding(jhd_tls_rsa_context *ctx) {
	int ret, count = 0;

	if (ctx->Vf.p != NULL) {
		/* We already have blinding values, just update them by squaring */
		JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&ctx->Vi, &ctx->Vi, &ctx->Vi));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_mod_mpi(&ctx->Vi, &ctx->Vi, &ctx->N));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&ctx->Vf, &ctx->Vf, &ctx->Vf));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_mod_mpi(&ctx->Vf, &ctx->Vf, &ctx->N));

		goto cleanup;
	}

	/* Unblinding value: Vf = random number, invertible mod N */
	do {
		if (count++ > 10)
			return ( JHD_TLS_ERR_RSA_RNG_FAILED);

		JHD_TLS_MPI_CHK(jhd_tls_mpi_fill_random(&ctx->Vf, ctx->len - 1));
		JHD_TLS_MPI_CHK(jhd_tls_mpi_gcd(&ctx->Vi, &ctx->Vf, &ctx->N));
	} while (jhd_tls_mpi_cmp_int(&ctx->Vi, 1) != 0);

	/* Blinding value: Vi =  Vf^(-e) mod N */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_inv_mod(&ctx->Vi, &ctx->Vf, &ctx->N));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_exp_mod(&ctx->Vi, &ctx->Vi, &ctx->E, &ctx->N, &ctx->RN));

	cleanup: return (ret);
}

/*
 * Exponent blinding supposed to prevent side-channel attacks using multiple
 * traces of measurements to recover the RSA key. The more collisions are there,
 * the more bits of the key can be recovered. See [3].
 *
 * Collecting n collisions with m bit long blinding value requires 2^(m-m/n)
 * observations on avarage.
 *
 * For example with 28 byte blinding to achieve 2 collisions the adversary has
 * to make 2^112 observations on avarage.
 *
 * (With the currently (as of 2017 April) known best algorithms breaking 2048
 * bit RSA requires approximately as much time as trying out 2^112 random keys.
 * Thus in this sense with 28 byte blinding the security is not reduced by
 * side-channel attacks like the one in [3])
 *
 * This countermeasure does not help if the key recovery is possible with a
 * single trace.
 */
#define RSA_EXPONENT_BLINDING 28

/*
 * Do an RSA private key operation
 */
int jhd_tls_rsa_private(jhd_tls_rsa_context *ctx, const unsigned char *input, unsigned char *output) {
	int ret;
	size_t olen;

	/* Temporary holding the result */
	jhd_tls_mpi T;

	/* Temporaries holding P-1, Q-1 and the
	 * exponent blinding factor, respectively. */
	jhd_tls_mpi P1, Q1, R;

#if !defined(JHD_TLS_RSA_NO_CRT)
	/* Temporaries holding the results mod p resp. mod q. */
	jhd_tls_mpi TP, TQ;

	/* Temporaries holding the blinded exponents for
	 * the mod p resp. mod q computation (if used). */
	jhd_tls_mpi DP_blind, DQ_blind;

	/* Pointers to actual exponents to be used - either the unblinded
	 * or the blinded ones, depending on the presence of a PRNG. */
	jhd_tls_mpi *DP = &ctx->DP;
	jhd_tls_mpi *DQ = &ctx->DQ;
#else
	/* Temporary holding the blinded exponent (if used). */
	jhd_tls_mpi D_blind;

	/* Pointer to actual exponent to be used - either the unblinded
	 * or the blinded one, depending on the presence of a PRNG. */
	jhd_tls_mpi *D = &ctx->D;
#endif /* JHD_TLS_RSA_NO_CRT */

	/* Temporaries holding the initial input and the double
	 * checked result; should be the same in the end. */
	jhd_tls_mpi I, C;

	if (rsa_check_context(ctx, 1 /* private key checks */, 1 /* blinding y/n       */) != 0) {
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}

	/* MPI Initialization */
	jhd_tls_mpi_init(&T);

	jhd_tls_mpi_init(&P1);
	jhd_tls_mpi_init(&Q1);
	jhd_tls_mpi_init(&R);

#if defined(JHD_TLS_RSA_NO_CRT)
	jhd_tls_mpi_init( &D_blind );
#else
	jhd_tls_mpi_init(&DP_blind);
	jhd_tls_mpi_init(&DQ_blind);
#endif

#if !defined(JHD_TLS_RSA_NO_CRT)
	jhd_tls_mpi_init(&TP);
	jhd_tls_mpi_init(&TQ);
#endif

	jhd_tls_mpi_init(&I);
	jhd_tls_mpi_init(&C);

	/* End of MPI initialization */

	JHD_TLS_MPI_CHK(jhd_tls_mpi_read_binary(&T, input, ctx->len));
	if (jhd_tls_mpi_cmp_mpi(&T, &ctx->N) >= 0) {
		ret = JHD_TLS_ERR_MPI_BAD_INPUT_DATA;
		goto cleanup;
	}

	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&I, &T));

	/*
	 * Blinding
	 * T = T * Vi mod N
	 */
	JHD_TLS_MPI_CHK(rsa_prepare_blinding(ctx));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&T, &T, &ctx->Vi));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mod_mpi(&T, &T, &ctx->N));

	/*
	 * Exponent blinding
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_int(&P1, &ctx->P, 1));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_int(&Q1, &ctx->Q, 1));

#if defined(JHD_TLS_RSA_NO_CRT)
	/*
	 * D_blind = ( P - 1 ) * ( Q - 1 ) * R + D
	 */
	JHD_TLS_MPI_CHK( jhd_tls_mpi_fill_random( &R, RSA_EXPONENT_BLINDING,
					f_rng, p_rng ) );
	JHD_TLS_MPI_CHK( jhd_tls_mpi_mul_mpi( &D_blind, &P1, &Q1 ) );
	JHD_TLS_MPI_CHK( jhd_tls_mpi_mul_mpi( &D_blind, &D_blind, &R ) );
	JHD_TLS_MPI_CHK( jhd_tls_mpi_add_mpi( &D_blind, &D_blind, &ctx->D ) );

	D = &D_blind;
#else
	/*
	 * DP_blind = ( P - 1 ) * R + DP
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_fill_random( &R, RSA_EXPONENT_BLINDING));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&DP_blind, &P1, &R));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_add_mpi(&DP_blind, &DP_blind, &ctx->DP));

	DP = &DP_blind;

	/*
	 * DQ_blind = ( Q - 1 ) * R + DQ
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_fill_random( &R, RSA_EXPONENT_BLINDING));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&DQ_blind, &Q1, &R));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_add_mpi(&DQ_blind, &DQ_blind, &ctx->DQ));

	DQ = &DQ_blind;
#endif /* JHD_TLS_RSA_NO_CRT */

#if defined(JHD_TLS_RSA_NO_CRT)
	JHD_TLS_MPI_CHK( jhd_tls_mpi_exp_mod( &T, &T, D, &ctx->N, &ctx->RN ) );
#else
	/*
	 * Faster decryption using the CRT
	 *
	 * TP = input ^ dP mod P
	 * TQ = input ^ dQ mod Q
	 */

	JHD_TLS_MPI_CHK(jhd_tls_mpi_exp_mod(&TP, &T, DP, &ctx->P, &ctx->RP));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_exp_mod(&TQ, &T, DQ, &ctx->Q, &ctx->RQ));

	/*
	 * T = (TP - TQ) * (Q^-1 mod P) mod P
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_sub_mpi(&T, &TP, &TQ));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&TP, &T, &ctx->QP));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mod_mpi(&T, &TP, &ctx->P));

	/*
	 * T = TQ + T * Q
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&TP, &T, &ctx->Q));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_add_mpi(&T, &TQ, &TP));
#endif /* JHD_TLS_RSA_NO_CRT */

	/*
	 * Unblind
	 * T = T * Vf mod N
	 */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mul_mpi(&T, &T, &ctx->Vf));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_mod_mpi(&T, &T, &ctx->N));

	/* Verify the result to prevent glitching attacks. */
	JHD_TLS_MPI_CHK(jhd_tls_mpi_exp_mod(&C, &T, &ctx->E, &ctx->N, &ctx->RN));
	if (jhd_tls_mpi_cmp_mpi(&C, &I) != 0) {
		ret = JHD_TLS_ERR_RSA_VERIFY_FAILED;
		goto cleanup;
	}

	olen = ctx->len;
	JHD_TLS_MPI_CHK(jhd_tls_mpi_write_binary(&T, output, olen));

	cleanup:

	jhd_tls_mpi_free(&P1);
	jhd_tls_mpi_free(&Q1);
	jhd_tls_mpi_free(&R);

#if defined(JHD_TLS_RSA_NO_CRT)
	jhd_tls_mpi_free( &D_blind );
#else
	jhd_tls_mpi_free(&DP_blind);
	jhd_tls_mpi_free(&DQ_blind);
#endif

	jhd_tls_mpi_free(&T);

#if !defined(JHD_TLS_RSA_NO_CRT)
	jhd_tls_mpi_free(&TP);
	jhd_tls_mpi_free(&TQ);
#endif

	jhd_tls_mpi_free(&C);
	jhd_tls_mpi_free(&I);

	if (ret != 0)
		return ( JHD_TLS_ERR_RSA_PRIVATE_FAILED + ret);

	return (0);
}

#if defined(JHD_TLS_PKCS1_V21)
/**
 * Generate and apply the MGF1 operation (from PKCS#1 v2.1) to a buffer.
 *
 * \param dst       buffer to mask
 * \param dlen      length of destination buffer
 * \param src       source of the mask generation
 * \param slen      length of the source buffer
 * \param md_ctx    message digest context to use
 */
static int mgf_mask(unsigned char *dst, size_t dlen, unsigned char *src, size_t slen, jhd_tls_md_context_t *md_ctx) {
	unsigned char mask[JHD_TLS_MD_MAX_SIZE];
	unsigned char counter[4];
	unsigned char *p;
	unsigned int hlen;
	size_t i, use_len;
	memset(mask, 0, JHD_TLS_MD_MAX_SIZE);
	memset(counter, 0, 4);

	hlen = jhd_tls_md_get_size(md_ctx->md_info);

	/* Generate and apply dbMask */
	p = dst;

	while (dlen > 0) {
		use_len = hlen;
		if (dlen < hlen)
			use_len = dlen;

		jhd_tls_md_starts(md_ctx);

		jhd_tls_md_update(md_ctx, src, slen);

		jhd_tls_md_update(md_ctx, counter, 4);

		jhd_tls_md_finish(md_ctx, mask);

		for (i = 0; i < use_len; ++i)
			*p++ ^= mask[i];

		counter[3]++;

		dlen -= use_len;
	}

	return (0);
}
#endif /* JHD_TLS_PKCS1_V21 */

#if defined(JHD_TLS_PKCS1_V21)
/*
 * Implementation of the PKCS#1 v2.1 RSAES-OAEP-ENCRYPT function
 */
int jhd_tls_rsa_rsaes_oaep_encrypt(jhd_tls_rsa_context *ctx, int mode, const unsigned char *label, size_t label_len, size_t ilen, const unsigned char *input,
        unsigned char *output) {
	size_t olen;
	int ret;
	unsigned char *p = output;
	unsigned int hlen;
	const jhd_tls_md_info_t *md_info;
	jhd_tls_md_context_t md_ctx;

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V21)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	md_info = jhd_tls_md_info_from_type((jhd_tls_md_type_t) ctx->hash_id);
	if (md_info == NULL)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	olen = ctx->len;
	hlen = jhd_tls_md_get_size(md_info);

	/* first comparison checks for overflow */
	if (ilen + 2 * hlen + 2 < ilen || olen < ilen + 2 * hlen + 2)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	memset(output, 0, olen);

	*p++ = 0;

	/* Generate a random octet string seed */
	jhd_tls_random(p, hlen);

	p += hlen;

	/* Construct DB */
	  jhd_tls_md(md_info, label, label_len, p) ;
	p += hlen;
	p += olen - 2 * hlen - 2 - ilen;
	*p++ = 1;
	memcpy(p, input, ilen);

	jhd_tls_md_init(&md_ctx);
	if ((ret = jhd_tls_md_setup(&md_ctx, md_info, 0)) != 0)
		goto exit;

	/* maskedDB: Apply dbMask to DB */
	if ((ret = mgf_mask(output + hlen + 1, olen - hlen - 1, output + 1, hlen, &md_ctx)) != 0)
		goto exit;

	/* maskedSeed: Apply seedMask to seed */
	if ((ret = mgf_mask(output + 1, hlen, output + hlen + 1, olen - hlen - 1, &md_ctx)) != 0)
		goto exit;

	exit: jhd_tls_md_free(&md_ctx);

	if (ret != 0)
		return (ret);

	return ((mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, output, output) : jhd_tls_rsa_private(ctx, output, output));
}
#endif /* JHD_TLS_PKCS1_V21 */

#if defined(JHD_TLS_PKCS1_V15)
/*
 * Implementation of the PKCS#1 v2.1 RSAES-PKCS1-V1_5-ENCRYPT function
 */
int jhd_tls_rsa_rsaes_pkcs1_v15_encrypt(jhd_tls_rsa_context *ctx, int mode, size_t ilen, const unsigned char *input, unsigned char *output) {
	size_t nb_pad, olen;
	unsigned char *p = output;

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V15)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	// We don't check p_rng because it won't be dereferenced here
	if (input == NULL || output == NULL)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	olen = ctx->len;

	/* first comparison checks for overflow */
	if (ilen + 11 < ilen || olen < ilen + 11)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	nb_pad = olen - 3 - ilen;

	*p++ = 0;
	if (mode == JHD_TLS_RSA_PUBLIC) {
		*p++ = JHD_TLS_RSA_CRYPT;

		while (nb_pad-- > 0) {

			do {
				jhd_tls_random(p, 1);
			} while (*p == 0);

			p++;
		}
	} else {
		*p++ = JHD_TLS_RSA_SIGN;

		while (nb_pad-- > 0)
			*p++ = 0xFF;
	}

	*p++ = 0;
	memcpy(p, input, ilen);

	return ((mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, output, output) : jhd_tls_rsa_private(ctx, output, output));
}
#endif /* JHD_TLS_PKCS1_V15 */

/*
 * Add the message padding, then do an RSA operation
 */
int jhd_tls_rsa_pkcs1_encrypt(jhd_tls_rsa_context *ctx, int mode, size_t ilen, const unsigned char *input, unsigned char *output) {
	switch (ctx->padding) {
#if defined(JHD_TLS_PKCS1_V15)
		case JHD_TLS_RSA_PKCS_V15:
			return jhd_tls_rsa_rsaes_pkcs1_v15_encrypt(ctx, mode, ilen, input, output);
#endif

#if defined(JHD_TLS_PKCS1_V21)
		case JHD_TLS_RSA_PKCS_V21:
			return jhd_tls_rsa_rsaes_oaep_encrypt(ctx, mode, NULL, 0, ilen, input, output);
#endif

		default:
			return ( JHD_TLS_ERR_RSA_INVALID_PADDING);
	}
}

#if defined(JHD_TLS_PKCS1_V21)
/*
 * Implementation of the PKCS#1 v2.1 RSAES-OAEP-DECRYPT function
 */
int jhd_tls_rsa_rsaes_oaep_decrypt(jhd_tls_rsa_context *ctx, int mode, const unsigned char *label, size_t label_len, size_t *olen, const unsigned char *input,
        unsigned char *output, size_t output_max_len) {
	int ret;
	size_t ilen, i, pad_len;
	unsigned char *p, bad, pad_done;
	unsigned char buf[JHD_TLS_MPI_MAX_SIZE];
	unsigned char lhash[JHD_TLS_MD_MAX_SIZE];
	unsigned int hlen;
	const jhd_tls_md_info_t *md_info;
	jhd_tls_md_context_t md_ctx;

	/*
	 * Parameters sanity checks
	 */
	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V21)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	ilen = ctx->len;

	if (ilen < 16 || ilen > sizeof(buf))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	md_info = jhd_tls_md_info_from_type((jhd_tls_md_type_t) ctx->hash_id);
	if (md_info == NULL)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	hlen = jhd_tls_md_get_size(md_info);

	// checking for integer underflow
	if (2 * hlen + 2 > ilen)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	/*
	 * RSA operation
	 */
	ret = (mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, input, buf) : jhd_tls_rsa_private(ctx, input, buf);

	if (ret != 0)
		goto cleanup;

	/*
	 * Unmask data and generate lHash
	 */
	jhd_tls_md_init(&md_ctx);
	if ((ret = jhd_tls_md_setup(&md_ctx, md_info, 0)) != 0) {
		jhd_tls_md_free(&md_ctx);
		goto cleanup;
	}

	/* seed: Apply seedMask to maskedSeed */
	if ((ret = mgf_mask(buf + 1, hlen, buf + hlen + 1, ilen - hlen - 1, &md_ctx)) != 0 ||
	/* DB: Apply dbMask to maskedDB */
	(ret = mgf_mask(buf + hlen + 1, ilen - hlen - 1, buf + 1, hlen, &md_ctx)) != 0) {
		jhd_tls_md_free(&md_ctx);
		goto cleanup;
	}

	jhd_tls_md_free(&md_ctx);

	/* Generate lHash */
	 jhd_tls_md(md_info, label, label_len, lhash) ;

	/*
	 * Check contents, in "constant-time"
	 */
	p = buf;
	bad = 0;

	bad |= *p++; /* First byte must be 0 */

	p += hlen; /* Skip seed */

	/* Check lHash */
	for (i = 0; i < hlen; i++)
		bad |= lhash[i] ^ *p++;

	/* Get zero-padding len, but always read till end of buffer
	 * (minus one, for the 01 byte) */
	pad_len = 0;
	pad_done = 0;
	for (i = 0; i < ilen - 2 * hlen - 2; i++) {
		pad_done |= p[i];
		pad_len += ((pad_done | (unsigned char) -pad_done) >> 7) ^ 1;
	}

	p += pad_len;
	bad |= *p++ ^ 0x01;

	/*
	 * The only information "leaked" is whether the padding was correct or not
	 * (eg, no data is copied if it was not correct). This meets the
	 * recommendations in PKCS#1 v2.2: an opponent cannot distinguish between
	 * the different error conditions.
	 */
	if (bad != 0) {
		ret = JHD_TLS_ERR_RSA_INVALID_PADDING;
		goto cleanup;
	}

	if (ilen - (p - buf) > output_max_len) {
		ret = JHD_TLS_ERR_RSA_OUTPUT_TOO_LARGE;
		goto cleanup;
	}

	*olen = ilen - (p - buf);
	memcpy(output, p, *olen);
	ret = 0;

	cleanup:
	jhd_tls_platform_zeroize(buf, sizeof(buf));
	jhd_tls_platform_zeroize(lhash, sizeof(lhash));

	return (ret);
}
#endif /* JHD_TLS_PKCS1_V21 */

#if defined(JHD_TLS_PKCS1_V15)
/*
 * Implementation of the PKCS#1 v2.1 RSAES-PKCS1-V1_5-DECRYPT function
 */
int jhd_tls_rsa_rsaes_pkcs1_v15_decrypt(jhd_tls_rsa_context *ctx, int mode, size_t *olen, const unsigned char *input, unsigned char *output,
        size_t output_max_len) {
	int ret;
	size_t ilen, pad_count = 0, i;
	unsigned char *p, bad, pad_done = 0;
	unsigned char buf[JHD_TLS_MPI_MAX_SIZE];

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V15)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	ilen = ctx->len;

	if (ilen < 16 || ilen > sizeof(buf))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	ret = (mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, input, buf) : jhd_tls_rsa_private(ctx, input, buf);

	if (ret != 0)
		goto cleanup;

	p = buf;
	bad = 0;

	/*
	 * Check and get padding len in "constant-time"
	 */
	bad |= *p++; /* First byte must be 0 */

	/* This test does not depend on secret data */
	if (mode == JHD_TLS_RSA_PRIVATE) {
		bad |= *p++ ^ JHD_TLS_RSA_CRYPT;

		/* Get padding len, but always read till end of buffer
		 * (minus one, for the 00 byte) */
		for (i = 0; i < ilen - 3; i++) {
			pad_done |= ((p[i] | (unsigned char) -p[i]) >> 7) ^ 1;
			pad_count += ((pad_done | (unsigned char) -pad_done) >> 7) ^ 1;
		}

		p += pad_count;
		bad |= *p++; /* Must be zero */
	} else {
		bad |= *p++ ^ JHD_TLS_RSA_SIGN;

		/* Get padding len, but always read till end of buffer
		 * (minus one, for the 00 byte) */
		for (i = 0; i < ilen - 3; i++) {
			pad_done |= (p[i] != 0xFF);
			pad_count += (pad_done == 0);
		}

		p += pad_count;
		bad |= *p++; /* Must be zero */
	}

	bad |= (pad_count < 8);

	if (bad) {
		ret = JHD_TLS_ERR_RSA_INVALID_PADDING;
		goto cleanup;
	}

	if (ilen - (p - buf) > output_max_len) {
		ret = JHD_TLS_ERR_RSA_OUTPUT_TOO_LARGE;
		goto cleanup;
	}

	*olen = ilen - (p - buf);
	memcpy(output, p, *olen);
	ret = 0;

	cleanup:
	jhd_tls_platform_zeroize(buf, sizeof(buf));

	return (ret);
}
#endif /* JHD_TLS_PKCS1_V15 */

/*
 * Do an RSA operation, then remove the message padding
 */
int jhd_tls_rsa_pkcs1_decrypt(jhd_tls_rsa_context *ctx, int mode, size_t *olen, const unsigned char *input, unsigned char *output, size_t output_max_len) {
	switch (ctx->padding) {
#if defined(JHD_TLS_PKCS1_V15)
		case JHD_TLS_RSA_PKCS_V15:
			return jhd_tls_rsa_rsaes_pkcs1_v15_decrypt(ctx, mode, olen, input, output, output_max_len);
#endif

#if defined(JHD_TLS_PKCS1_V21)
		case JHD_TLS_RSA_PKCS_V21:
			return jhd_tls_rsa_rsaes_oaep_decrypt(ctx, mode, NULL, 0, olen, input, output, output_max_len);
#endif

		default:
			return ( JHD_TLS_ERR_RSA_INVALID_PADDING);
	}
}

#if defined(JHD_TLS_PKCS1_V21)
/*
 * Implementation of the PKCS#1 v2.1 RSASSA-PSS-SIGN function
 */
int jhd_tls_rsa_rsassa_pss_sign(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        unsigned char *sig) {
	size_t olen;
	unsigned char *p = sig;
	unsigned char salt[JHD_TLS_MD_MAX_SIZE];
	unsigned int slen, hlen, offset = 0;
	int ret;
	size_t msb;
	const jhd_tls_md_info_t *md_info;
	jhd_tls_md_context_t md_ctx;

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V21)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	olen = ctx->len;

	if (md_alg != JHD_TLS_MD_NONE) {
		/* Gather length of hash to sign */
		md_info = jhd_tls_md_info_from_type(md_alg);
		if (md_info == NULL)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		hashlen = jhd_tls_md_get_size(md_info);
	}

	md_info = jhd_tls_md_info_from_type((jhd_tls_md_type_t) ctx->hash_id);
	if (md_info == NULL)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	hlen = jhd_tls_md_get_size(md_info);
	slen = hlen;

	if (olen < hlen + slen + 2)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	memset(sig, 0, olen);

	jhd_tls_random(salt, slen);

	/* Note: EMSA-PSS encoding is over the length of N - 1 bits */
	msb = jhd_tls_mpi_bitlen(&ctx->N) - 1;
	p += olen - hlen * 2 - 2;
	*p++ = 0x01;
	memcpy(p, salt, slen);
	p += slen;

	jhd_tls_md_init(&md_ctx);
	if ((ret = jhd_tls_md_setup(&md_ctx, md_info, 0)) != 0)
		goto exit;

	/* Generate H = Hash( M' ) */
	 jhd_tls_md_starts(&md_ctx);

	 jhd_tls_md_update(&md_ctx, p, 8);

	 jhd_tls_md_update(&md_ctx, hash, hashlen);

	 jhd_tls_md_update(&md_ctx, salt, slen);

	 jhd_tls_md_finish(&md_ctx, p);


	/* Compensate for boundary condition when applying mask */
	if (msb % 8 == 0)
		offset = 1;

	/* maskedDB: Apply dbMask to DB */
	if ((ret = mgf_mask(sig + offset, olen - hlen - 1 - offset, p, hlen, &md_ctx)) != 0)
		goto exit;

	msb = jhd_tls_mpi_bitlen(&ctx->N) - 1;
	sig[0] &= 0xFF >> (olen * 8 - msb);

	p += hlen;
	*p++ = 0xBC;

	jhd_tls_platform_zeroize(salt, sizeof(salt));

	exit: jhd_tls_md_free(&md_ctx);

	if (ret != 0)
		return (ret);

	return ((mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, sig, sig) : jhd_tls_rsa_private(ctx, sig, sig));
}
#endif /* JHD_TLS_PKCS1_V21 */

#if defined(JHD_TLS_PKCS1_V15)
/*
 * Implementation of the PKCS#1 v2.1 RSASSA-PKCS1-V1_5-SIGN function
 */

/* Construct a PKCS v1.5 encoding of a hashed message
 *
 * This is used both for signature generation and verification.
 *
 * Parameters:
 * - md_alg:  Identifies the hash algorithm used to generate the given hash;
 *            JHD_TLS_MD_NONE if raw data is signed.
 * - hashlen: Length of hash in case hashlen is JHD_TLS_MD_NONE.
 * - hash:    Buffer containing the hashed message or the raw data.
 * - dst_len: Length of the encoded message.
 * - dst:     Buffer to hold the encoded message.
 *
 * Assumptions:
 * - hash has size hashlen if md_alg == JHD_TLS_MD_NONE.
 * - hash has size corresponding to md_alg if md_alg != JHD_TLS_MD_NONE.
 * - dst points to a buffer of size at least dst_len.
 *
 */
static int rsa_rsassa_pkcs1_v15_encode(jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash, size_t dst_len, unsigned char *dst) {
	size_t oid_size = 0;
	size_t nb_pad = dst_len;
	unsigned char *p = dst;
	const char *oid = NULL;

	/* Are we signing hashed or raw data? */
	if (md_alg != JHD_TLS_MD_NONE) {
		const jhd_tls_md_info_t *md_info = jhd_tls_md_info_from_type(md_alg);
		if (md_info == NULL)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		if (jhd_tls_oid_get_oid_by_md(md_alg, &oid, &oid_size) != 0)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		hashlen = jhd_tls_md_get_size(md_info);

		/* Double-check that 8 + hashlen + oid_size can be used as a
		 * 1-byte ASN.1 length encoding and that there's no overflow. */
		if (8 + hashlen + oid_size >= 0x80 || 10 + hashlen < hashlen || 10 + hashlen + oid_size < 10 + hashlen)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		/*
		 * Static bounds check:
		 * - Need 10 bytes for five tag-length pairs.
		 *   (Insist on 1-byte length encodings to protect against variants of
		 *    Bleichenbacher's forgery attack against lax PKCS#1v1.5 verification)
		 * - Need hashlen bytes for hash
		 * - Need oid_size bytes for hash alg OID.
		 */
		if (nb_pad < 10 + hashlen + oid_size)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
		nb_pad -= 10 + hashlen + oid_size;
	} else {
		if (nb_pad < hashlen)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		nb_pad -= hashlen;
	}

	/* Need space for signature header and padding delimiter (3 bytes),
	 * and 8 bytes for the minimal padding */
	if (nb_pad < 3 + 8)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	nb_pad -= 3;

	/* Now nb_pad is the amount of memory to be filled
	 * with padding, and at least 8 bytes long. */

	/* Write signature header and padding */
	*p++ = 0;
	*p++ = JHD_TLS_RSA_SIGN;
	memset(p, 0xFF, nb_pad);
	p += nb_pad;
	*p++ = 0;

	/* Are we signing raw data? */
	if (md_alg == JHD_TLS_MD_NONE) {
		memcpy(p, hash, hashlen);
		return (0);
	}

	/* Signing hashed data, add corresponding ASN.1 structure
	 *
	 * DigestInfo ::= SEQUENCE {
	 *   digestAlgorithm DigestAlgorithmIdentifier,
	 *   digest Digest }
	 * DigestAlgorithmIdentifier ::= AlgorithmIdentifier
	 * Digest ::= OCTET STRING
	 *
	 * Schematic:
	 * TAG-SEQ + LEN [ TAG-SEQ + LEN [ TAG-OID  + LEN [ OID  ]
	 *                                 TAG-NULL + LEN [ NULL ] ]
	 *                 TAG-OCTET + LEN [ HASH ] ]
	 */
	*p++ = JHD_TLS_ASN1_SEQUENCE | JHD_TLS_ASN1_CONSTRUCTED;
	*p++ = (unsigned char) (0x08 + oid_size + hashlen);
	*p++ = JHD_TLS_ASN1_SEQUENCE | JHD_TLS_ASN1_CONSTRUCTED;
	*p++ = (unsigned char) (0x04 + oid_size);
	*p++ = JHD_TLS_ASN1_OID;
	*p++ = (unsigned char) oid_size;
	memcpy(p, oid, oid_size);
	p += oid_size;
	*p++ = JHD_TLS_ASN1_NULL;
	*p++ = 0x00;
	*p++ = JHD_TLS_ASN1_OCTET_STRING;
	*p++ = (unsigned char) hashlen;
	memcpy(p, hash, hashlen);
	p += hashlen;

	/* Just a sanity-check, should be automatic
	 * after the initial bounds check. */
	if (p != dst + dst_len) {
		jhd_tls_platform_zeroize(dst, dst_len);
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	}

	return (0);
}

/*
 * Do an RSA operation to sign the message digest
 */
int jhd_tls_rsa_rsassa_pkcs1_v15_sign(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        unsigned char *sig) {
	int ret;
	unsigned char *sig_try = NULL, *verif = NULL;

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V15)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	/*
	 * Prepare PKCS1-v1.5 encoding (padding and hash identifier)
	 */

	if ((ret = rsa_rsassa_pkcs1_v15_encode(md_alg, hashlen, hash, ctx->len, sig)) != 0)
		return (ret);

	/*
	 * Call respective RSA primitive
	 */

	if (mode == JHD_TLS_RSA_PUBLIC) {
		/* Skip verification on a public key operation */
		return (jhd_tls_rsa_public(ctx, sig, sig));
	}

	/* Private key operation
	 *
	 * In order to prevent Lenstra's attack, make the signature in a
	 * temporary buffer and check it before returning it.
	 */

	sig_try = jhd_tls_malloc(ctx->len);
	if (sig_try == NULL)
		return ( JHD_TLS_ERR_MPI_ALLOC_FAILED);

	verif = jhd_tls_malloc(ctx->len);
	if (verif == NULL) {
		jhd_tls_free(sig_try);
		return ( JHD_TLS_ERR_MPI_ALLOC_FAILED);
	}

	JHD_TLS_MPI_CHK(jhd_tls_rsa_private(ctx, sig, sig_try));
	JHD_TLS_MPI_CHK(jhd_tls_rsa_public(ctx, sig_try, verif));

	if (jhd_tls_safer_memcmp(verif, sig, ctx->len) != 0) {
		ret = JHD_TLS_ERR_RSA_PRIVATE_FAILED;
		goto cleanup;
	}

	memcpy(sig, sig_try, ctx->len);

	cleanup:
	jhd_tls_free(sig_try);
	jhd_tls_free(verif);

	return (ret);
}
#endif /* JHD_TLS_PKCS1_V15 */

/*
 * Do an RSA operation to sign the message digest
 */
int jhd_tls_rsa_pkcs1_sign(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash, unsigned char *sig) {
	switch (ctx->padding) {
#if defined(JHD_TLS_PKCS1_V15)
		case JHD_TLS_RSA_PKCS_V15:
			return jhd_tls_rsa_rsassa_pkcs1_v15_sign(ctx, mode, md_alg, hashlen, hash, sig);
#endif

#if defined(JHD_TLS_PKCS1_V21)
		case JHD_TLS_RSA_PKCS_V21:
			return jhd_tls_rsa_rsassa_pss_sign(ctx, mode, md_alg, hashlen, hash, sig);
#endif

		default:
			return ( JHD_TLS_ERR_RSA_INVALID_PADDING);
	}
}

#if defined(JHD_TLS_PKCS1_V21)
/*
 * Implementation of the PKCS#1 v2.1 RSASSA-PSS-VERIFY function
 */
int jhd_tls_rsa_rsassa_pss_verify_ext(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        jhd_tls_md_type_t mgf1_hash_id, int expected_salt_len, const unsigned char *sig) {
	int ret;
	size_t siglen;
	unsigned char *p;
	unsigned char *hash_start;
	unsigned char result[JHD_TLS_MD_MAX_SIZE];
	unsigned char zeros[8];
	unsigned int hlen;
	size_t observed_salt_len, msb;
	const jhd_tls_md_info_t *md_info;
	jhd_tls_md_context_t md_ctx;
	unsigned char buf[JHD_TLS_MPI_MAX_SIZE];

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V21)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	siglen = ctx->len;

	if (siglen < 16 || siglen > sizeof(buf))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	ret = (mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, sig, buf) : jhd_tls_rsa_private(ctx, sig, buf);

	if (ret != 0)
		return (ret);

	p = buf;

	if (buf[siglen - 1] != 0xBC)
		return ( JHD_TLS_ERR_RSA_INVALID_PADDING);

	if (md_alg != JHD_TLS_MD_NONE) {
		/* Gather length of hash to sign */
		md_info = jhd_tls_md_info_from_type(md_alg);
		if (md_info == NULL)
			return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

		hashlen = jhd_tls_md_get_size(md_info);
	}

	md_info = jhd_tls_md_info_from_type(mgf1_hash_id);
	if (md_info == NULL)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	hlen = jhd_tls_md_get_size(md_info);

	memset(zeros, 0, 8);

	/*
	 * Note: EMSA-PSS verification is over the length of N - 1 bits
	 */
	msb = jhd_tls_mpi_bitlen(&ctx->N) - 1;

	if (buf[0] >> (8 - siglen * 8 + msb))
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	/* Compensate for boundary condition when applying mask */
	if (msb % 8 == 0) {
		p++;
		siglen -= 1;
	}

	if (siglen < hlen + 2)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);
	hash_start = p + siglen - hlen - 1;

	jhd_tls_md_init(&md_ctx);
	if ((ret = jhd_tls_md_setup(&md_ctx, md_info, 0)) != 0)
		goto exit;

	ret = mgf_mask(p, siglen - hlen - 1, hash_start, hlen, &md_ctx);
	if (ret != 0)
		goto exit;

	buf[0] &= 0xFF >> (siglen * 8 - msb);

	while (p < hash_start - 1 && *p == 0)
		p++;

	if (*p++ != 0x01) {
		ret = JHD_TLS_ERR_RSA_INVALID_PADDING;
		goto exit;
	}

	observed_salt_len = hash_start - p;

	if (expected_salt_len != JHD_TLS_RSA_SALT_LEN_ANY && observed_salt_len != (size_t) expected_salt_len) {
		ret = JHD_TLS_ERR_RSA_INVALID_PADDING;
		goto exit;
	}

	/*
	 * Generate H = Hash( M' )
	 */
	  jhd_tls_md_starts(&md_ctx);

	 jhd_tls_md_update(&md_ctx, zeros, 8);

	  jhd_tls_md_update(&md_ctx, hash, hashlen);

	  jhd_tls_md_update(&md_ctx, p, observed_salt_len);

	  jhd_tls_md_finish(&md_ctx, result);

	if (memcmp(hash_start, result, hlen) != 0) {
		ret = JHD_TLS_ERR_RSA_VERIFY_FAILED;
		goto exit;
	}

	exit: jhd_tls_md_free(&md_ctx);

	return (ret);
}

/*
 * Simplified PKCS#1 v2.1 RSASSA-PSS-VERIFY function
 */
int jhd_tls_rsa_rsassa_pss_verify(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        const unsigned char *sig) {
	jhd_tls_md_type_t mgf1_hash_id = (ctx->hash_id != JHD_TLS_MD_NONE) ? (jhd_tls_md_type_t) ctx->hash_id : md_alg;

	return (jhd_tls_rsa_rsassa_pss_verify_ext(ctx, mode, md_alg, hashlen, hash, mgf1_hash_id, JHD_TLS_RSA_SALT_LEN_ANY, sig));

}
#endif /* JHD_TLS_PKCS1_V21 */

#if defined(JHD_TLS_PKCS1_V15)
/*
 * Implementation of the PKCS#1 v2.1 RSASSA-PKCS1-v1_5-VERIFY function
 */
int jhd_tls_rsa_rsassa_pkcs1_v15_verify(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        const unsigned char *sig) {
	int ret = 0;
	const size_t sig_len = ctx->len;
	unsigned char *encoded = NULL, *encoded_expected = NULL;

	if (mode == JHD_TLS_RSA_PRIVATE && ctx->padding != JHD_TLS_RSA_PKCS_V15)
		return ( JHD_TLS_ERR_RSA_BAD_INPUT_DATA);

	/*
	 * Prepare expected PKCS1 v1.5 encoding of hash.
	 */

	if ((encoded = jhd_tls_malloc(sig_len)) == NULL || (encoded_expected = jhd_tls_malloc(sig_len)) == NULL) {
		ret = JHD_TLS_ERR_MPI_ALLOC_FAILED;
		goto cleanup;
	}

	if ((ret = rsa_rsassa_pkcs1_v15_encode(md_alg, hashlen, hash, sig_len, encoded_expected)) != 0)
		goto cleanup;

	/*
	 * Apply RSA primitive to get what should be PKCS1 encoded hash.
	 */

	ret = (mode == JHD_TLS_RSA_PUBLIC) ? jhd_tls_rsa_public(ctx, sig, encoded) : jhd_tls_rsa_private(ctx, sig, encoded);
	if (ret != 0)
		goto cleanup;

	/*
	 * Compare
	 */

	if ((ret = jhd_tls_safer_memcmp(encoded, encoded_expected, sig_len)) != 0) {
		ret = JHD_TLS_ERR_RSA_VERIFY_FAILED;
		goto cleanup;
	}

	cleanup:

	if (encoded != NULL) {
		jhd_tls_platform_zeroize(encoded, sig_len);
		jhd_tls_free(encoded);
	}

	if (encoded_expected != NULL) {
		jhd_tls_platform_zeroize(encoded_expected, sig_len);
		jhd_tls_free(encoded_expected);
	}

	return (ret);
}
#endif /* JHD_TLS_PKCS1_V15 */

/*
 * Do an RSA operation and check the message digest
 */
int jhd_tls_rsa_pkcs1_verify(jhd_tls_rsa_context *ctx, int mode, jhd_tls_md_type_t md_alg, unsigned int hashlen, const unsigned char *hash,
        const unsigned char *sig) {
	switch (ctx->padding) {
#if defined(JHD_TLS_PKCS1_V15)
		case JHD_TLS_RSA_PKCS_V15:
			return jhd_tls_rsa_rsassa_pkcs1_v15_verify(ctx, mode, md_alg, hashlen, hash, sig);
#endif

#if defined(JHD_TLS_PKCS1_V21)
		case JHD_TLS_RSA_PKCS_V21:
			return jhd_tls_rsa_rsassa_pss_verify(ctx, mode, md_alg, hashlen, hash, sig);
#endif

		default:
			return ( JHD_TLS_ERR_RSA_INVALID_PADDING);
	}
}

/*
 * Copy the components of an RSA key
 */
int jhd_tls_rsa_copy(jhd_tls_rsa_context *dst, const jhd_tls_rsa_context *src) {
	int ret;

	dst->ver = src->ver;
	dst->len = src->len;

	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->N, &src->N));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->E, &src->E));

	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->D, &src->D));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->P, &src->P));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->Q, &src->Q));

#if !defined(JHD_TLS_RSA_NO_CRT)
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->DP, &src->DP));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->DQ, &src->DQ));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->QP, &src->QP));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->RP, &src->RP));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->RQ, &src->RQ));
#endif

	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->RN, &src->RN));

	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->Vi, &src->Vi));
	JHD_TLS_MPI_CHK(jhd_tls_mpi_copy(&dst->Vf, &src->Vf));

	dst->padding = src->padding;
	dst->hash_id = src->hash_id;

	cleanup: if (ret != 0)
		jhd_tls_rsa_free(dst);

	return (ret);
}

/*
 * Free the components of an RSA key
 */
void jhd_tls_rsa_free(jhd_tls_rsa_context *ctx) {
	jhd_tls_mpi_free(&ctx->Vi);
	jhd_tls_mpi_free(&ctx->Vf);
	jhd_tls_mpi_free(&ctx->RN);
	jhd_tls_mpi_free(&ctx->D);
	jhd_tls_mpi_free(&ctx->Q);
	jhd_tls_mpi_free(&ctx->P);
	jhd_tls_mpi_free(&ctx->E);
	jhd_tls_mpi_free(&ctx->N);

#if !defined(JHD_TLS_RSA_NO_CRT)
	jhd_tls_mpi_free(&ctx->RQ);
	jhd_tls_mpi_free(&ctx->RP);
	jhd_tls_mpi_free(&ctx->QP);
	jhd_tls_mpi_free(&ctx->DQ);
	jhd_tls_mpi_free(&ctx->DP);
#endif /* JHD_TLS_RSA_NO_CRT */

}

#endif /* !JHD_TLS_RSA_ALT */

