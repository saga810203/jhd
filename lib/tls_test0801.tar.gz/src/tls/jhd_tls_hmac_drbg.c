#include <tls/jhd_tls_config.h>

#if defined(JHD_TLS_HMAC_DRBG_C)

#include <tls/jhd_tls_hmac_drbg.h>

#include <string.h>

#if defined(JHD_TLS_FS_IO)
#include <stdio.h>
#endif

#if defined(JHD_TLS_SELF_TEST)

#include <tls/jhd_tls_platform.h>

#endif /* JHD_TLS_PLATFORM_C */
#if !defined(JHD_TLS_INLINE)
/*
 * HMAC_DRBG context initialization
 */
void jhd_tls_hmac_drbg_init(jhd_tls_hmac_drbg_context *ctx) {
	memset(ctx, 0, sizeof(jhd_tls_hmac_drbg_context));

}
#endif
/*
 * HMAC_DRBG update, using optional additional data (10.1.2.2)
 */
void jhd_tls_hmac_drbg_update(jhd_tls_hmac_drbg_context *ctx, const unsigned char *additional, size_t add_len) {
	size_t md_len = jhd_tls_md_get_size(ctx->md_ctx->md_info);
	unsigned char rounds = (additional != NULL && add_len != 0) ? 2 : 1;
	unsigned char sep[1];
	unsigned char K[JHD_TLS_MD_MAX_SIZE];

	for (sep[0] = 0; sep[0] < rounds; sep[0]++) {
		/* Step 1 or 4 */
		jhd_tls_md_hmac_reset(ctx->md_ctx);
		jhd_tls_md_hmac_update(ctx->md_ctx, ctx->V, md_len);
		jhd_tls_md_hmac_update(ctx->md_ctx, sep, 1);
		if (rounds == 2)
			jhd_tls_md_hmac_update(ctx->md_ctx, additional, add_len);
		jhd_tls_md_hmac_finish(ctx->md_ctx, K);

		/* Step 2 or 5 */
		jhd_tls_md_hmac_starts(ctx->md_ctx, K, md_len);
		jhd_tls_md_hmac_update(ctx->md_ctx, ctx->V, md_len);
		jhd_tls_md_hmac_finish(ctx->md_ctx, ctx->V);
	}
}

/*
 * Simplified HMAC_DRBG initialisation (for use with deterministic ECDSA)
 */
void jhd_tls_hmac_drbg_seed_buf(jhd_tls_hmac_drbg_context *ctx, jhd_tls_md_context_t * md_ctx, const unsigned char *data, size_t data_len) {
	ctx->md_ctx = md_ctx;
	jhd_tls_md_hmac_starts(ctx->md_ctx, ctx->V, jhd_tls_md_get_size(md_ctx->md_info));
	memset(ctx->V, 0x01, jhd_tls_md_get_size(md_ctx->md_info));
	jhd_tls_hmac_drbg_update(ctx, data, data_len);
}

/*
 * HMAC_DRBG random function with optional additional data:
 * 10.1.2.5 (arabic) + 9.3 (Roman)
 */
void jhd_tls_hmac_drbg_random(void *p_rng, unsigned char *output, size_t out_len) {

	jhd_tls_hmac_drbg_context *ctx = (jhd_tls_hmac_drbg_context *) p_rng;
	size_t md_len = jhd_tls_md_get_size(ctx->md_ctx->md_info);
	size_t left;
	unsigned char *out = output;

	/* II. Check request length */
	if (out_len > JHD_TLS_HMAC_DRBG_MAX_REQUEST) {
		out_len = JHD_TLS_HMAC_DRBG_MAX_REQUEST;
	}
	left = out_len;
	while (left != 0) {
		size_t use_len = left > md_len ? md_len : left;

		jhd_tls_md_hmac_reset(ctx->md_ctx);
		jhd_tls_md_hmac_update(ctx->md_ctx, ctx->V, md_len);
		jhd_tls_md_hmac_finish(ctx->md_ctx, ctx->V);

		memcpy(out, ctx->V, use_len);
		out += use_len;
		left -= use_len;
	}

	jhd_tls_hmac_drbg_update(ctx, NULL, 0);

}

#endif /* JHD_TLS_HMAC_DRBG_C */
