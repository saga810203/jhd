/*
 *  Minimal SSL client, used for memory measurements.
 *  (meant to be used with config-suite-b.h or config-ccm-psk-tls1_2.h)
 *
 *  Copyright (C) 2006-2015, ARM Limited, All Rights Reserved
 *  SPDX-License-Identifier: Apache-2.0
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may
 *  not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 *  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This file is part of mbed TLS (https://tls.mbed.org)
 */

#if !defined(MBEDTLS_CONFIG_FILE)
#include "./mbedtls/config.h"
#else
#include MBEDTLS_CONFIG_FILE
#endif

#include "./mbedtls/debug.h"
/*
 * We're creating and connecting the socket "manually" rather than using the
 * NET module, in order to avoid the overhead of getaddrinfo() which tends to
 * dominate memory usage in small configurations. For the sake of simplicity,
 * only a Unix version is implemented.
 *
 * Warning: we are breaking some of the abtractions from the NET layer here.
 * This is not a good example for general use. This programs has the specific
 * goal of minimizing use of the libc functions on full-blown OSes.
 */
#if defined(unix) || defined(__unix__) || defined(__unix) || defined(__APPLE__)
#define UNIX
#endif

#if !defined(MBEDTLS_CTR_DRBG_C) || !defined(MBEDTLS_ENTROPY_C) || \
    !defined(MBEDTLS_NET_C) || !defined(MBEDTLS_SSL_CLI_C) || \
    !defined(UNIX)

#if defined(MBEDTLS_PLATFORM_C)
#include "../mbedtls/platform.h"
#else
#include <stdio.h>
#define mbedtls_printf printf
#endif

int main( void )
{
    mbedtls_printf( "MBEDTLS_CTR_DRBG_C and/or MBEDTLS_ENTROPY_C and/or "
            "MBEDTLS_NET_C and/or MBEDTLS_SSL_CLI_C and/or UNIX "
            "not defined.\n");
    return( 0 );
}
#else

#if defined(MBEDTLS_PLATFORM_C)
#include "./mbedtls/platform.h"
#else
#include <stdlib.h>
#endif

#include <string.h>

#include "./mbedtls/net_sockets.h"
#include "./mbedtls/ssl.h"
#include "./mbedtls/entropy.h"
#include "./mbedtls/ctr_drbg.h"
#include "./mbedtls/ccm.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "./test_inc.h"

/*
 * Hardcoded values for server host and port
 */
#define PORT_BE 0x1BB      /* 443 */
#define PORT_LE 0x5111
#define ADDR_BE 0x7f000001  /* 127.0.0.1 */
#define ADDR_LE 0x0100007f
#define HOSTNAME "localhost" /* for cert verification if enabled */

#define IPV4(a,b,c,d) ((a<<0)|(b<<8)|(c<<16)|(d<<24))

#define IPV42(d,c,b,a) ((a<<0)|(b<<8)|(c<<16)|(d<<24))

#define GET_REQUEST "GET / HTTP/1.0\r\n\r\n"

const char *pers = "mini_client";

#if defined(MBEDTLS_KEY_EXCHANGE__SOME__PSK_ENABLED)
const unsigned char psk[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
};
const char psk_id[] = "Client_identity";
#endif

#if defined(MBEDTLS_X509_CRT_PARSE_C)
/* This is tests/data_files/test-ca2.crt, a CA using EC secp384r1 */
const unsigned char ca_cert[] = {
    0x30, 0x82, 0x02, 0x52, 0x30, 0x82, 0x01, 0xd7, 0xa0, 0x03, 0x02, 0x01,
    0x02, 0x02, 0x09, 0x00, 0xc1, 0x43, 0xe2, 0x7e, 0x62, 0x43, 0xcc, 0xe8,
    0x30, 0x0a, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02,
    0x30, 0x3e, 0x31, 0x0b, 0x30, 0x09, 0x06, 0x03, 0x55, 0x04, 0x06, 0x13,
    0x02, 0x4e, 0x4c, 0x31, 0x11, 0x30, 0x0f, 0x06, 0x03, 0x55, 0x04, 0x0a,
    0x13, 0x08, 0x50, 0x6f, 0x6c, 0x61, 0x72, 0x53, 0x53, 0x4c, 0x31, 0x1c,
    0x30, 0x1a, 0x06, 0x03, 0x55, 0x04, 0x03, 0x13, 0x13, 0x50, 0x6f, 0x6c,
    0x61, 0x72, 0x73, 0x73, 0x6c, 0x20, 0x54, 0x65, 0x73, 0x74, 0x20, 0x45,
    0x43, 0x20, 0x43, 0x41, 0x30, 0x1e, 0x17, 0x0d, 0x31, 0x33, 0x30, 0x39,
    0x32, 0x34, 0x31, 0x35, 0x34, 0x39, 0x34, 0x38, 0x5a, 0x17, 0x0d, 0x32,
    0x33, 0x30, 0x39, 0x32, 0x32, 0x31, 0x35, 0x34, 0x39, 0x34, 0x38, 0x5a,
    0x30, 0x3e, 0x31, 0x0b, 0x30, 0x09, 0x06, 0x03, 0x55, 0x04, 0x06, 0x13,
    0x02, 0x4e, 0x4c, 0x31, 0x11, 0x30, 0x0f, 0x06, 0x03, 0x55, 0x04, 0x0a,
    0x13, 0x08, 0x50, 0x6f, 0x6c, 0x61, 0x72, 0x53, 0x53, 0x4c, 0x31, 0x1c,
    0x30, 0x1a, 0x06, 0x03, 0x55, 0x04, 0x03, 0x13, 0x13, 0x50, 0x6f, 0x6c,
    0x61, 0x72, 0x73, 0x73, 0x6c, 0x20, 0x54, 0x65, 0x73, 0x74, 0x20, 0x45,
    0x43, 0x20, 0x43, 0x41, 0x30, 0x76, 0x30, 0x10, 0x06, 0x07, 0x2a, 0x86,
    0x48, 0xce, 0x3d, 0x02, 0x01, 0x06, 0x05, 0x2b, 0x81, 0x04, 0x00, 0x22,
    0x03, 0x62, 0x00, 0x04, 0xc3, 0xda, 0x2b, 0x34, 0x41, 0x37, 0x58, 0x2f,
    0x87, 0x56, 0xfe, 0xfc, 0x89, 0xba, 0x29, 0x43, 0x4b, 0x4e, 0xe0, 0x6e,
    0xc3, 0x0e, 0x57, 0x53, 0x33, 0x39, 0x58, 0xd4, 0x52, 0xb4, 0x91, 0x95,
    0x39, 0x0b, 0x23, 0xdf, 0x5f, 0x17, 0x24, 0x62, 0x48, 0xfc, 0x1a, 0x95,
    0x29, 0xce, 0x2c, 0x2d, 0x87, 0xc2, 0x88, 0x52, 0x80, 0xaf, 0xd6, 0x6a,
    0xab, 0x21, 0xdd, 0xb8, 0xd3, 0x1c, 0x6e, 0x58, 0xb8, 0xca, 0xe8, 0xb2,
    0x69, 0x8e, 0xf3, 0x41, 0xad, 0x29, 0xc3, 0xb4, 0x5f, 0x75, 0xa7, 0x47,
    0x6f, 0xd5, 0x19, 0x29, 0x55, 0x69, 0x9a, 0x53, 0x3b, 0x20, 0xb4, 0x66,
    0x16, 0x60, 0x33, 0x1e, 0xa3, 0x81, 0xa0, 0x30, 0x81, 0x9d, 0x30, 0x1d,
    0x06, 0x03, 0x55, 0x1d, 0x0e, 0x04, 0x16, 0x04, 0x14, 0x9d, 0x6d, 0x20,
    0x24, 0x49, 0x01, 0x3f, 0x2b, 0xcb, 0x78, 0xb5, 0x19, 0xbc, 0x7e, 0x24,
    0xc9, 0xdb, 0xfb, 0x36, 0x7c, 0x30, 0x6e, 0x06, 0x03, 0x55, 0x1d, 0x23,
    0x04, 0x67, 0x30, 0x65, 0x80, 0x14, 0x9d, 0x6d, 0x20, 0x24, 0x49, 0x01,
    0x3f, 0x2b, 0xcb, 0x78, 0xb5, 0x19, 0xbc, 0x7e, 0x24, 0xc9, 0xdb, 0xfb,
    0x36, 0x7c, 0xa1, 0x42, 0xa4, 0x40, 0x30, 0x3e, 0x31, 0x0b, 0x30, 0x09,
    0x06, 0x03, 0x55, 0x04, 0x06, 0x13, 0x02, 0x4e, 0x4c, 0x31, 0x11, 0x30,
    0x0f, 0x06, 0x03, 0x55, 0x04, 0x0a, 0x13, 0x08, 0x50, 0x6f, 0x6c, 0x61,
    0x72, 0x53, 0x53, 0x4c, 0x31, 0x1c, 0x30, 0x1a, 0x06, 0x03, 0x55, 0x04,
    0x03, 0x13, 0x13, 0x50, 0x6f, 0x6c, 0x61, 0x72, 0x73, 0x73, 0x6c, 0x20,
    0x54, 0x65, 0x73, 0x74, 0x20, 0x45, 0x43, 0x20, 0x43, 0x41, 0x82, 0x09,
    0x00, 0xc1, 0x43, 0xe2, 0x7e, 0x62, 0x43, 0xcc, 0xe8, 0x30, 0x0c, 0x06,
    0x03, 0x55, 0x1d, 0x13, 0x04, 0x05, 0x30, 0x03, 0x01, 0x01, 0xff, 0x30,
    0x0a, 0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02, 0x03,
    0x69, 0x00, 0x30, 0x66, 0x02, 0x31, 0x00, 0xc3, 0xb4, 0x62, 0x73, 0x56,
    0x28, 0x95, 0x00, 0x7d, 0x78, 0x12, 0x26, 0xd2, 0x71, 0x7b, 0x19, 0xf8,
    0x8a, 0x98, 0x3e, 0x92, 0xfe, 0x33, 0x9e, 0xe4, 0x79, 0xd2, 0xfe, 0x7a,
    0xb7, 0x87, 0x74, 0x3c, 0x2b, 0xb8, 0xd7, 0x69, 0x94, 0x0b, 0xa3, 0x67,
    0x77, 0xb8, 0xb3, 0xbe, 0xd1, 0x36, 0x32, 0x02, 0x31, 0x00, 0xfd, 0x67,
    0x9c, 0x94, 0x23, 0x67, 0xc0, 0x56, 0xba, 0x4b, 0x33, 0x15, 0x00, 0xc6,
    0xe3, 0xcc, 0x31, 0x08, 0x2c, 0x9c, 0x8b, 0xda, 0xa9, 0x75, 0x23, 0x2f,
    0xb8, 0x28, 0xe7, 0xf2, 0x9c, 0x14, 0x3a, 0x40, 0x01, 0x5c, 0xaf, 0x0c,
    0xb2, 0xcf, 0x74, 0x7f, 0x30, 0x9f, 0x08, 0x43, 0xad, 0x20,
};
#endif /* MBEDTLS_X509_CRT_PARSE_C */

enum exit_codes
{
    exit_ok = 0,
    ctr_drbg_seed_failed,
    ssl_config_defaults_failed,
    ssl_setup_failed,
    hostname_failed,
    socket_failed,
    connect_failed,
    x509_crt_parse_failed,
    ssl_handshake_failed,
    ssl_write_failed,
};


size_t package_idx;

uint16_t  test_random_size(void *ctr_drbg){
	unsigned char buf[2];
	mbedtls_ctr_drbg_random(ctr_drbg,buf,2);
	return buf[0]<< 8 | buf[0];
}

void  test_random_buf(void *ctr_drbg,u_char *p,size_t len){
	while(len >0){
			if(len > 1024){
			mbedtls_ctr_drbg_random(ctr_drbg,p,1024);
			p+=1024;
			len -=1024;
			}else{
				mbedtls_ctr_drbg_random(ctr_drbg,p,len);
				break;
			}

		}
}

unsigned char send_buffer[0XFFFF];


unsigned char recv_buffer[0XFFFF];




size_t send_buf_idx, send_buffer_len,recv_buffer_len;

int test_send(mbedtls_ssl_context* ssl){
	ssize_t ret;
	size_t len,i;

	if(recv_buffer_len>0){
		i = 0;
		while(i < recv_buffer_len){
			len = recv_buffer_len - i;
			if(len > 8192){
				len =8192;
			}
			ret = mbedtls_ssl_write(ssl,&recv_buffer[i],len);
			if(ret <0){
				printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!send data(peer) error");
				return -1;
			}
			i+=ret;
		}

		//printf("=======>send recv_buffer[%lu]\n",recv_buffer_len);


		recv_buffer_len = 0;
	}

	if(package_idx < 20000){
		send_buffer_len = package_idx+2;
		send_buffer[0] = (unsigned char)(send_buffer_len>>8);
		send_buffer[1] = (unsigned char)(send_buffer_len);

		for(i = 0;i<package_idx;++i ){
			send_buffer[2+i] =(unsigned char) i;
		}
	}else{
		send_buffer_len = test_random_size(ssl->conf->p_rng);
		if(send_buffer_len > 65530){
			send_buffer_len = 65530;
		}else if(send_buffer_len< 3){
			send_buffer_len = 3;
		}

		send_buffer[0] = (unsigned char)(send_buffer_len>>8);
		send_buffer[1] = (unsigned char)(send_buffer_len);
		test_random_buf(ssl->conf->p_rng,&send_buffer[2],send_buffer_len -2);
	}
	i = 0;
	while(i < send_buffer_len){
		len = send_buffer_len - i;
		if(len > 8192){
			len =8192;
		}
		ret = mbedtls_ssl_write(ssl,&send_buffer[i],len);



		if(ret <0){
			printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!send data(self) error");
			return -1;
		}
		i+=ret;
	}
	//printf("=======>package_idx:%lu, send send_buffer[%lu]\n",package_idx,send_buffer_len);
	send_buf_idx = 0;
	return 0;
}



int test_recv(mbedtls_ssl_context* ssl){
	ssize_t ret;
	size_t len,i;
	unsigned char tmp[1024*16];
	i = 0;
	for(;;){
		len = send_buffer_len - i;
		if(len >1024*16 ){
			len =1024*16;
		}
		ret = mbedtls_ssl_read(ssl,tmp,len);
		if(ret >=0){
			if(memcmp(&send_buffer[i],tmp,ret)!=0){
				printf("!!!!!invalid recv data(self) memcpy(...........)\n");
				return -1;
			}
			i+=ret;
			if(i == send_buffer_len){
				break;
			}
		}else{
			printf("!!!!!!!!!peer closed!!!!!!!!!\n");
					return -1;
		}
	}
	i =0;
	for(;;){
			ret = mbedtls_ssl_read(ssl,tmp,1024*16);
			if(ret >0){
				memcpy(&recv_buffer[i],tmp,ret);
				if(((i ==0) && (ret >1)) || (i ==1 )) {
					recv_buffer_len = (recv_buffer[0]<<8)|(recv_buffer[1]);
					if(package_idx < 20000){
						if(recv_buffer_len != (2 + package_idx)){
							printf("!!!!invald recv data(peer) recv_buffer_len=%ld,package_idx=%ld\n",recv_buffer_len,package_idx);
							return -1;
						}

					}
				}
				i+=ret;
				if(recv_buffer_len == i){

					return 0;
				}else if(recv_buffer_len < i){
					printf("!!!!!!!!!recv data(peer) error:headr len=%ld,recv len%ld\n",recv_buffer_len,i);
					return -1;
				}
			}else  if(ret<0){
				printf("!!!!!!!!peer closed!!!!!!!!!!!\n");
						return -1;
			}
		}
}


char *test_supported_ciphersuites[]={
//        		        "TLS-ECDHE-ECDSA-WITH-AES-128-CBC-SHA",
//        				"TLS-ECDHE-ECDSA-WITH-AES-256-CBC-SHA",
//        				"TLS-ECDHE-ECDSA-WITH-AES-128-CBC-SHA256",
//
//
//						"TLS-ECDHE-ECDSA-WITH-AES-128-GCM-SHA256",
//						"TLS-ECDHE-ECDSA-WITH-AES-256-CBC-SHA384",
//						"TLS-ECDHE-ECDSA-WITH-AES-256-GCM-SHA384",
//						"TLS-ECDHE-ECDSA-WITH-AES-256-CCM",
//        				"TLS-ECDHE-ECDSA-WITH-AES-128-CCM",
//        				"TLS-ECDHE-ECDSA-WITH-CAMELLIA-128-CBC-SHA256",
//        				"TLS-ECDHE-ECDSA-WITH-CAMELLIA-256-CBC-SHA384",
//						"TLS-ECDHE-ECDSA-WITH-CAMELLIA-128-GCM-SHA256",
//        				"TLS-ECDHE-ECDSA-WITH-CAMELLIA-256-GCM-SHA384",
//        				"TLS-ECDHE-ECDSA-WITH-3DES-EDE-CBC-SHA",
//        				"TLS-ECDHE-RSA-WITH-AES-128-CBC-SHA",
//        				"TLS-ECDHE-RSA-WITH-AES-256-CBC-SHA",
//        				"TLS-ECDHE-RSA-WITH-AES-128-CBC-SHA256",
//        				"TLS-ECDHE-RSA-WITH-AES-128-GCM-SHA256",
//        				"TLS-ECDHE-RSA-WITH-AES-256-CBC-SHA384",
//        				"TLS-ECDHE-RSA-WITH-AES-256-GCM-SHA384",
//        				"TLS-ECDHE-RSA-WITH-CAMELLIA-128-CBC-SHA256",
//        				"TLS-ECDHE-RSA-WITH-CAMELLIA-256-CBC-SHA384",
//        				"TLS-ECDHE-RSA-WITH-CAMELLIA-128-GCM-SHA256",
//						"TLS-ECDHE-RSA-WITH-CAMELLIA-256-GCM-SHA384",
//        				"TLS-ECDHE-RSA-WITH-3DES-EDE-CBC-SHA",
//						"TLS-ECDHE-RSA-WITH-ARIA-256-GCM-SHA384",
//						"TLS-ECDHE-RSA-WITH-ARIA-256-CBC-SHA384",
//						"TLS-ECDHE-RSA-WITH-ARIA-128-GCM-SHA256",
//						"TLS-ECDHE-RSA-WITH-ARIA-128-CBC-SHA256",
//						"TLS-ECDHE-ECDSA-WITH-ARIA-256-GCM-SHA384",
//						"TLS-ECDHE-ECDSA-WITH-ARIA-256-CBC-SHA384",
//						"TLS-ECDHE-ECDSA-WITH-ARIA-128-GCM-SHA256",
//						"TLS-ECDHE-ECDSA-WITH-ARIA-128-CBC-SHA256",





//        				"TLS-RSA-WITH-AES-256-GCM-SHA384",
//        				"TLS-RSA-WITH-AES-128-GCM-SHA256",
//						"TLS-RSA-WITH-CAMELLIA-128-GCM-SHA256",
//						"TLS-RSA-WITH-CAMELLIA-256-GCM-SHA384",
//						"TLS-RSA-WITH-ARIA-256-GCM-SHA384",
//						"TLS-RSA-WITH-ARIA-128-GCM-SHA256",
//
//
//						"TLS-RSA-WITH-AES-256-CCM",
//						"TLS-RSA-WITH-AES-128-CCM",


//        				"TLS-RSA-WITH-AES-128-CBC-SHA256",
//        				"TLS-RSA-WITH-AES-256-CBC-SHA256",
						"TLS-RSA-WITH-AES-128-CBC-SHA",
						"TLS-RSA-WITH-AES-256-CBC-SHA",

//						"TLS-RSA-WITH-CAMELLIA-128-CBC-SHA256",
//						"TLS-RSA-WITH-CAMELLIA-256-CBC-SHA256",
//						"TLS-RSA-WITH-CAMELLIA-128-CBC-SHA",
//						"TLS-RSA-WITH-CAMELLIA-256-CBC-SHA",
//						"TLS-RSA-WITH-3DES-EDE-CBC-SHA",
//						"TLS-RSA-WITH-ARIA-256-CBC-SHA384",
//						"TLS-RSA-WITH-ARIA-128-CBC-SHA256",



						NULL};

int mbedtls_saga_test = 0;




int mbedtls_ccm_test_enc(const u_char *key,const unsigned int key_len,const unsigned char *iv,const unsigned char *add, size_t len,const u_char *input,u_char *output,u_char *tag){
	 mbedtls_ccm_context ctx;
    int ret;
    mbedtls_ccm_init( &ctx );
   if( mbedtls_ccm_setkey( &ctx, MBEDTLS_CIPHER_ID_AES, key, 8 * key_len ) != 0 )
    {
          printf( "  CCM: setup failed with ENC\n" );
          mbedtls_ccm_free(&ctx);
	        return( 1 );
	    }
	    ret = mbedtls_ccm_encrypt_and_tag( &ctx, len,iv, 12, add,13, input, output,  tag, 16 );
        if( ret != 0  )
	        {
	       printf( "failed with ENC\n" );
	       mbedtls_ccm_free(&ctx);
	            return( 1 );
	        }

        mbedtls_ccm_free(&ctx);


	    return( 0 );
}
int mbedtls_ccm_test_dec(const u_char *key,size_t key_len,const u_char *iv,const u_char *add, size_t len,const u_char *input,u_char *output,u_char *tag){
		mbedtls_ccm_context ctx;
	    int ret;
	    mbedtls_ccm_init( &ctx );
	    if( mbedtls_ccm_setkey( &ctx, MBEDTLS_CIPHER_ID_AES, key, 8 * key_len ) != 0 )
	    {
	    	   mbedtls_ccm_free(&ctx);
           printf( "  CCM: setup failed with DEC\n" );
	        return( 1 );
	    }
	   ret = mbedtls_ccm_auth_decrypt( &ctx,len,iv,12,add,13,input,output,tag,16);
       if( ret != 0  )
	   {
    	   mbedtls_ccm_free(&ctx);
	       printf( "failed with DEC\n" );
	       return( 1 );
	   }
       mbedtls_ccm_free(&ctx);
      return( 0 );
}


//

int test_ccm_by_struct(struct ccm_test_data_t *data){
	uint8_t ret;
	u_char tmpb[16 * 1024];
	u_char tmpt[16];

	memcpy(tmpb,data->input,data->len);
	mbedtls_ccm_test_enc(data->key,data->key_bytes,data->iv,data->add,data->len,tmpb,tmpb,tmpt);
	ret = 0;
	if(memcmp(data->tag,tmpt,16) != 0){
		ret += 1;
	}
	if(memcmp(data->output,tmpb,data->len) != 0){
		ret += 2;
	}
	if(ret == 3){
		printf("ccm ENC error  [BOTH]\n");
		return 1;
	}else if(ret == 1){
		printf("ccm ENC error  [TAG]\n");
		return 1;
	}else if(ret == 2){
		printf("ccm ENC error  [CNT]\n");
		return 1;
	}

	ret = 0;
	memcpy(tmpt,data->tag,16);
	if(0 != mbedtls_ccm_test_dec(data->key,data->key_bytes,data->iv,data->add,data->len,tmpb,tmpb,tmpt)){
		ret += 1;
	}

	if(memcmp(data->input,tmpb,data->len) != 0){
		ret += 2;
	}
	if(ret == 3){
		printf("ccm DEC error  [BOTH]\n");
		return 1;
	}else if(ret == 1){
		printf("ccm DEC error  [TAG]\n");
		return 1;
	}else if(ret == 2){
		printf("ccm DEC error  [CNT]\n");
		return 1;
	}
	return 0;

}

void mbedtls_ccm_self_test3( ){


	u_char key[]={0XB8,0X49,0X5E,0X85,0X50,0X5F,0X7E,0X52,0XEB,0X30,0XFF,0X63,0X4D,0X72,0X11,0X39,};
		u_char iv[]={0XE4,0X06,0XA9,0X87,0XB7,0XD3,0XF3,0X25,0XF8,0XD7,0XEF,0XE7,};
		u_char add[]={0X49,0X16,0X89,0XF6,0XFC,0XBD,0X5E,0XBD,0X6A,0XDC,0X83,0XBD,0XF9,};
		u_char tag[]={0XE7,0X02,0X27,0XA1,0X5E,0XD4,0X99,0XC0,0X0C,0X0E,0X7C,0X98,0X3D,0X72,0XF3,0X00,};
		u_char input[]={0X2A,0X6F,0X1F,0X02,0X76,0XA1,0XF2,0XE4,0X37,0XA5,0X15,0X80,0X45,0X11,0X16,0X20,0X4F,0XC2,0X3C,0XE4,0XCE,0XC7,0X19,0X40,0XEE,0XB2,0X30,0X2C,0X05,0XEF,0X9A,0X75,};
		u_char output[]={0XDE,0X25,0X01,0X8E,0XE1,0X47,0XAE,0X8A,0X95,0X8A,0XFF,0X4E,0X86,0XFE,0XAE,0XCF,0XCA,0X4C,0X9E,0X27,0XEE,0X20,0X77,0X6D,0X84,0XAA,0X8B,0X37,0X57,0XD1,0XED,0XA2,};

		struct  ccm_test_data_t   ccm_test_data ={0,key,16,iv,add,tag,16,output,input};



		test_ccm_by_struct(&ccm_test_data);

	}


	void mbedtls_random_test_data(int (*f_rng)(void *, unsigned char *, size_t),void *p_rng,char *key,char *iv,char *add,char *input,size_t len){
		size_t rlen,idx;
	    f_rng(p_rng,key,16);
	    f_rng(p_rng,add,13);
	    f_rng(p_rng,iv,12);
	    idx = 0;
	    while(idx < len){
	    	rlen = len - idx;
	    	if(rlen<=1024){
	    		f_rng(p_rng,&input[idx],rlen);
	    		break;
	    	}else{
	    		f_rng(p_rng,&input[idx],1024);
	    		idx+=1024;
	    	}
	    }
	}


	void printf_buf(char *name,char *p,size_t len,size_t idx){
		size_t i;
		printf("u_char %s_%u[]={",name,idx);

		for(i = 0; i < len ;++i){
			printf("0X%02X,",(u_char)p[i]);
		}
		printf("};\n");
	}

	int mbedtls_ccm_self_test2(int (*f_rng)(void *, unsigned char *, size_t),void *p_rng)
	{
	    u_char key[16];
		u_char iv[12];
	    u_char input[16*1024];
	    u_char add[13];
	    u_char output_enc[16*1024];
	    u_char output_dec[16*1024];
	    u_char tag[16];



	    size_t test_num[]={1,4,6,8,9,15,16,17,31,32,1021,1024,1029,3333,8192,0};

	   size_t idx = 0;

	   for(idx=0; test_num[idx] >0;++idx){
		   mbedtls_random_test_data(f_rng,p_rng,key,iv,add,input,test_num[idx]);

		   if(0!=mbedtls_ccm_test_enc(key,16,iv,add,test_num[idx],input,output_enc,tag)){
		     	saga_out("ERROR  ENC\n");
		     	return 1;
		   }
		   if(0!=mbedtls_ccm_test_dec(key,16,iv,add,test_num[idx],output_enc,output_dec,tag)){
		     	saga_out("ERROR DEC\n");
		     	return 1;
		   }
		   if(memcmp(output_dec,input,test_num[idx])!=0){
			   printf("MEMCMP ERROR\n");
			   return 1;
		   }

		   printf_buf("key",key,16,idx);
		   printf_buf("iv",iv,12,idx);
		   printf_buf("add",add,13,idx);
		   printf_buf("tag",tag,16,idx);
		   printf_buf("input",input,test_num[idx],idx);
		   printf_buf("output",output_enc,test_num[idx],idx);

		   printf("\n\nstruct  ccm_test_data_t   ccm_test_data%lu ={0,JHD_TLS_CIPHER_AES_128_CCM,key_%lu,%d,iv_%lu,add_%lu,tag_%lu,%d,input_%lu,output_%lu};\n\n\n\n\n",
			   idx,idx,16,idx,idx,idx,test_num[idx],idx,idx);

	   }

	   return 0;
	}

int test3(){
	int i;

	//struct  ccm_test_data_t   ccm_test_data ={0,JHD_TLS_CIPHER_AES_128_CCM,key,16,iv,add,tag,16,input,output};

	i = 0;

	while(ctds[i] != NULL){
        printf("============>TEST[%d]\n",i);
		if(0 != test_ccm_by_struct(ctds[i])){
			printf(" ERROR ======>  %d\n",i);
			break;
		}else{
			printf(" OK ======>  %d\n",i);
		}
		++i;
	}

	return 1;
}



static int tls1_prf111( const unsigned char *secret, size_t slen,
                     const char *label,
                     const unsigned char *random, size_t rlen,
                     unsigned char *dstbuf, size_t dlen )
{
    size_t nb, hs;
    size_t i, j, k;
    const unsigned char *S1, *S2;
    unsigned char tmp[128];
    unsigned char h_i[20];
    const mbedtls_md_info_t *md_info;
    mbedtls_md_context_t md_ctx;
    int ret;

    mbedtls_md_init( &md_ctx );

    if( sizeof( tmp ) < 20 + strlen( label ) + rlen )
        return( MBEDTLS_ERR_SSL_BAD_INPUT_DATA );

    hs = ( slen + 1 ) / 2;
    S1 = secret;
    S2 = secret + slen - hs;

    nb = strlen( label );
    memcpy( tmp + 20, label, nb );
    memcpy( tmp + 20 + nb, random, rlen );
    nb += rlen;

    mbedtls_log_buffer("tmp",tmp+20,nb);



    /*
     * First compute P_md5(secret,label+random)[0..dlen]
     */
    if( ( md_info = mbedtls_md_info_from_type( MBEDTLS_MD_MD5 ) ) == NULL )
        return( MBEDTLS_ERR_SSL_INTERNAL_ERROR );

    if( ( ret = mbedtls_md_setup( &md_ctx, md_info, 1 ) ) != 0 )
        return( ret );

    mbedtls_md_hmac_starts( &md_ctx, S1, hs );
    mbedtls_md_hmac_update( &md_ctx, tmp + 20, nb );
    mbedtls_md_hmac_finish( &md_ctx, 4 + tmp );

    mbedtls_log_buffer("md5,tmp",tmp+4,16);

    for( i = 0; i < dlen; i += 16 )
    {
        mbedtls_md_hmac_reset ( &md_ctx );
        mbedtls_md_hmac_update( &md_ctx, 4 + tmp, 16 + nb );
        mbedtls_md_hmac_finish( &md_ctx, h_i );

        mbedtls_md_hmac_reset ( &md_ctx );
        mbedtls_md_hmac_update( &md_ctx, 4 + tmp, 16 );
        mbedtls_md_hmac_finish( &md_ctx, 4 + tmp );

        k = ( i + 16 > dlen ) ? dlen % 16 : 16;

        for( j = 0; j < k; j++ )
            dstbuf[i + j]  = h_i[j];
    }

    mbedtls_log_buffer("md5,tmp",tmp+4,16);
    mbedtls_log_buffer("md5,dstbuf",dstbuf,dlen);

    mbedtls_md_free( &md_ctx );

    /*
     * XOR out with P_sha1(secret,label+random)[0..dlen]
     */
    if( ( md_info = mbedtls_md_info_from_type( MBEDTLS_MD_SHA1 ) ) == NULL )
        return( MBEDTLS_ERR_SSL_INTERNAL_ERROR );

    if( ( ret = mbedtls_md_setup( &md_ctx, md_info, 1 ) ) != 0 )
        return( ret );

    mbedtls_md_hmac_starts( &md_ctx, S2, hs );
    mbedtls_md_hmac_update( &md_ctx, tmp + 20, nb );
    mbedtls_md_hmac_finish( &md_ctx, tmp );
    mbedtls_log_buffer("sha1,tmp",tmp,20);
    for( i = 0; i < dlen; i += 20 )
    {
        mbedtls_md_hmac_reset ( &md_ctx );
        mbedtls_md_hmac_update( &md_ctx, tmp, 20 + nb );
        mbedtls_md_hmac_finish( &md_ctx, h_i );

        mbedtls_log_buffer("sha1,for__1==>",h_i,20);

        mbedtls_md_hmac_reset ( &md_ctx );
        mbedtls_md_hmac_update( &md_ctx, tmp, 20 );
        mbedtls_md_hmac_finish( &md_ctx, tmp );

        mbedtls_log_buffer("sha1,for__2==>",tmp,20);

        k = ( i + 20 > dlen ) ? dlen % 20 : 20;

        for( j = 0; j < k; j++ )
            dstbuf[i + j] = (unsigned char)( dstbuf[i + j] ^ h_i[j] );
    }

    mbedtls_log_buffer("sha1,tmp",tmp,20);
    mbedtls_log_buffer("sh1,dstbuf",dstbuf,dlen);

    mbedtls_md_free( &md_ctx );

    mbedtls_platform_zeroize( tmp, sizeof( tmp ) );
    mbedtls_platform_zeroize( h_i, sizeof( h_i ) );

    return( 0 );
}



static int run_test_flag = 0;


void test(int (*f_rng)(void *, unsigned char *, size_t),  void *p_rng ){

	mbedtls_saga_test = 1;
	unsigned char secret[]={0x03,0x01,0xA6,0x3E,0xE4,0x0D,0xCA,0x0F,0x87,0xB9,0x8F,0x17,0x17,0xA6,0x74,0x3C,
	 0xB7,0x8E,0x09,0x32,0xFB,0x23,0x93,0x4E,0x1E,0x4A,0x71,0x58,0x4C,0x3E,0x26,0x21,
	 0x33,0xF6,0x0D,0x74,0x3E,0x59,0xE0,0x4B,0x06,0xA3,0xB7,0x94,0xAE,0x30,0xC2,0x07,};

	unsigned char *lable ="extended master secret";

	unsigned char randomBytes[]={0x5B,0xC9,0x3B,0x8A,0xCC,0xDA,0x4C,0x4E,0xF2,0xBE,0x4E,0x74,0x62,0x3D,0x41,0x99,
			 0x90,0x6E,0x0A,0x38,0xF1,0x89,0x2F,0x4C,0x1A,0x77,0xE1,0xDC,0x70,0xB9,0x25,0x21,
			 0x5B,0xC9,0x3B,0x8A,0x63,0xD5,0xBA,0x74,0x43,0xF8,0xEE,0xED,0x61,0x6E,0x3E,0x1D,
			 0xB4,0x5A,0x9A,0x9A,0x30,0x3B,0x77,0xC2,0x8F,0x41,0x17,0xF1,0x5A,0x13,0x4C,0x5A,};

	unsigned char dstbuf[48];

	mbedtls_tls1_prf(secret,48,lable,randomBytes,64,dstbuf,48);
	mbedtls_log_buffer("MASTER",dstbuf,48);

}

struct test_param{
		unsigned char miner;
		unsigned char  etm;
		unsigned char th;
		unsigned char mfc_code;
};








struct test_param  testparams[]={
		{1,1,0,0},
		{1,1,0,1},
		{1,1,0,2},
		{1,1,0,3},
		{1,1,0,4},
		{1,1,1,0},
		{1,1,1,1},
		{1,1,1,2},
		{1,1,1,3},
		{1,1,1,4},
		{1,0,0,0},
		{1,0,0,1},
		{1,0,0,2},
		{1,0,0,3},
		{1,0,0,4},
		{1,0,1,0},
		{1,0,1,1},
		{1,0,1,2},
		{1,0,1,3},
		{1,0,1,4},
		{2,0,0,0},
		{2,0,0,1},
		{2,0,0,2},
		{2,0,0,3},
		{2,0,0,4},
		{2,0,1,0},
		{2,0,1,1},
		{2,0,1,2},
		{2,0,1,3},
		{2,0,1,4},
		{2,1,0,0},
		{2,1,0,1},
		{2,1,0,2},
		{2,1,0,3},
		{2,1,0,4},
		{2,1,1,0},
		{2,1,1,1},
		{2,1,1,2},
		{2,1,1,3},
		{2,1,1,4},
		{3,0,0,0},
		{3,0,0,1},
		{3,0,0,2},
		{3,0,0,3},
		{3,0,0,4},
		{3,0,1,0},
		{3,0,1,1},
		{3,0,1,2},
		{3,0,1,3},
		{3,0,1,4},
		{3,1,0,0},
		{3,1,0,1},
		{3,1,0,2},
		{3,1,0,3},
		{3,1,0,4},
		{3,1,1,0},
		{3,1,1,1},
		{3,1,1,2},
		{3,1,1,3},
		{3,1,1,4},
};


int main( int argc,char* argv[] ){
	struct timespec    tbegin,tend;
    int ret = exit_ok,ciphersuite_idx;
    size_t  loop_cnt ;
    size_t rate;
    int drate;
    char * lab="-\\|/";
    unsigned char bar[102];


    int test_idx;



    mbedtls_net_context server_fd;
    struct sockaddr_in addr;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;


    size_t max_loop_cnt;
    if(argc >1){
    	max_loop_cnt = atoi(argv[1]);
    	if(max_loop_cnt<20){
    		max_loop_cnt = 20;
    	}
    }else{
    	max_loop_cnt = 20;
    }



    ciphersuite_idx = 0;

    test_idx = 0;
    loop_begin:
//	mbedtls_saga_test = 1;
    selected_ciphersuite_name = test_supported_ciphersuites[ciphersuite_idx];
    if(NULL ==selected_ciphersuite_name ){
    	if(test_idx> 59){

    	printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>OK<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");
    	return 0;
    	}
    	ciphersuite_idx = 0;
    	++test_idx;
    	goto loop_begin;
    }

    printf(">>>>>>>>>>>>>>>>>>>begin test with ciphersuite:%s<<<<<<<<<<<<<<<<<<\n",selected_ciphersuite_name);
    printf("testparam{miner:%d,etm:%d,th:%d,mfc_code:%d}\n",testparams[test_idx].miner,testparams[test_idx].etm,testparams[test_idx].th,testparams[test_idx].mfc_code);
    mbedtls_ctr_drbg_init( &ctr_drbg );
    mbedtls_net_init( &server_fd );
    mbedtls_ssl_init( &ssl );
    mbedtls_ssl_config_init( &conf );
    mbedtls_entropy_init( &entropy );
    if( mbedtls_ctr_drbg_seed( &ctr_drbg, mbedtls_entropy_func, &entropy,
                       (const unsigned char *) pers, strlen( pers ) ) != 0 )
    {
        ret = ctr_drbg_seed_failed;
        goto exit;
    }

    if( mbedtls_ssl_config_defaults( &conf,MBEDTLS_SSL_IS_CLIENT,MBEDTLS_SSL_TRANSPORT_STREAM,MBEDTLS_SSL_PRESET_DEFAULT ) != 0 )
    {
        ret = ssl_config_defaults_failed;
        goto exit;
    }


    conf.max_minor_ver = testparams[test_idx].miner;
    conf.min_minor_ver = testparams[test_idx].miner;


    conf.trunc_hmac =   testparams[test_idx].th;
    conf.encrypt_then_mac =  testparams[test_idx].etm;
    conf.mfl_code = testparams[test_idx].mfc_code;


    mbedtls_ssl_conf_rng( &conf, mbedtls_ctr_drbg_random, &ctr_drbg );


    if(run_test_flag){
    	test( mbedtls_ctr_drbg_random, &ctr_drbg);
    	return 0;
    }

//#if defined(MBEDTLS_KEY_EXCHANGE__SOME__PSK_ENABLED)
//    mbedtls_ssl_conf_psk( &conf, psk, sizeof( psk ),
//                (const unsigned char *) psk_id, sizeof( psk_id ) - 1 );
//#endif

//#if defined(MBEDTLS_X509_CRT_PARSE_C)
//    if( mbedtls_x509_crt_parse_der( &ca, ca_cert, sizeof( ca_cert ) ) != 0 )
//    {
//        ret = x509_crt_parse_failed;
//        goto exit;
//    }
//
//    mbedtls_ssl_conf_ca_chain( &conf, &ca, NULL );
    mbedtls_ssl_conf_authmode( &conf, MBEDTLS_SSL_VERIFY_NONE );
//#endif

    if( mbedtls_ssl_setup( &ssl, &conf ) != 0 )
    {
        ret = ssl_setup_failed;
        goto exit;
    }

//#if defined(MBEDTLS_X509_CRT_PARSE_C)
    if( mbedtls_ssl_set_hostname( &ssl, HOSTNAME ) != 0 )
    {
        ret = hostname_failed;
        goto exit;
    }
//#endif

    /*
     * 1. Start the connection
     */
    memset( &addr, 0, sizeof( addr ) );
    addr.sin_family = AF_INET;

    ret = 1; /* for endianness detection */
    addr.sin_port = htons(443);
    addr.sin_addr.s_addr = IPV4(127,0,0,1);
    ret = 0;

    if( ( server_fd.fd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
    {
        ret = socket_failed;
        goto exit;
    }

    if( connect( server_fd.fd,
                (const struct sockaddr *) &addr, sizeof( addr ) ) < 0 )
    {
        ret = connect_failed;
        goto exit;
    }

    mbedtls_ssl_set_bio( &ssl, &server_fd, mbedtls_net_send, mbedtls_net_recv, NULL );

    if( mbedtls_ssl_handshake( &ssl ) != 0 )
    {
        ret = ssl_handshake_failed;
        goto exit;
    }

    /*
     * 2. Write the GET request and close the connection
     */
//    if( mbedtls_ssl_write( &ssl, (const unsigned char *) GET_REQUEST,
//                         sizeof( GET_REQUEST ) - 1 ) <= 0 )
//    {
//        ret = ssl_write_failed;
//        goto exit;
//    }
    package_idx = 1;
    recv_buffer_len  =0;
    send_buf_idx=0;
    send_buffer_len=0;
    loop_cnt = 0;
    printf("===================> read application data:\n");
    clock_gettime(CLOCK_MONOTONIC,&tbegin);
    memset(bar,0,102);
    bar[0]='#';
    for(;; ){

    	if(test_send(&ssl)!=0){
    		printf("==========================================>recv test data failed<=============================\n");
    	  break;
    	}
    	if(test_recv(&ssl)!=0){
    		 printf("\n==========================================>recv test data failed<=============================");
    	  break;
    	}
    	if(package_idx < 200000){
    		package_idx <<= 1;
    		//printf("package_idx :%lu\n",package_idx);
    	}
    	loop_cnt ++;

    	drate = loop_cnt * 100 / max_loop_cnt;
    	if(max_loop_cnt>99){
    		if(bar[drate] ==0){
    			bar[drate] ='#';
    		}
    	}else{
    		while(bar[rate] ==0 &&  rate >0 ){
    			bar[rate--]='#';
    		}
    	}
    	clock_gettime(CLOCK_MONOTONIC,&tend);
    	rate = tend.tv_sec  *1000;
        rate += (tend.tv_nsec / 1000000);

    	rate -= tbegin.tv_sec  *1000;
    	rate -= (tbegin.tv_nsec / 1000000);

    	printf("[%-101s][%d%%][%3.3fMbit/S][%C]\r",bar,drate,lab[loop_cnt % 4],(ssl.num_read *1000) *((double)1.0) / rate / 1024 / 1024*8);
    	fflush(stdout);
        if(loop_cnt >= max_loop_cnt){
	//    	printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$      %lu                    $$$$$$$$$$$\n",loop_cnt);



	//    	printf("begin==>(%lu,%lu)  end==>(%lu,%lu)\n",tbegin.tv_sec,tbegin.tv_nsec,tend.tv_sec,tend.tv_nsec);

			rate = tend.tv_sec  *1000;
			rate += (tend.tv_nsec / 1000000);

			rate -= tbegin.tv_sec  *1000;
			rate -= (tbegin.tv_nsec / 1000000);
			printf("\n%s   loop_num:%lu   time:%lu    bytes:%lu     rate: %lu  %fMbit/S\n",selected_ciphersuite_name,loop_cnt,rate,ssl.num_read,ssl.num_read / rate, (ssl.num_read *1000) *((double)1.0) / rate / 1024 / 1024*8);
			ssl.num_read = 0;

			clock_gettime(CLOCK_MONOTONIC,&tbegin);
			ret = exit_ok;
			break;

        }
    }
    printf("\n=========>ssl_read return:%d,",ret);
    mbedtls_ssl_close_notify( &ssl );


exit:
    mbedtls_net_free( &server_fd );

    mbedtls_ssl_free( &ssl );
    mbedtls_ssl_config_free( &conf );
    mbedtls_ctr_drbg_free( &ctr_drbg );
    mbedtls_entropy_free( &entropy );

    if(ret == exit_ok){
    	ciphersuite_idx++;
    	goto loop_begin;
    }
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!error with ciphersuite:%s\n",selected_ciphersuite_name);
    printf("testparam{miner:%d,etm:%d,th:%d,mfc_code:%d}\n",testparams[test_idx].miner,testparams[test_idx].etm,testparams[test_idx].th,testparams[test_idx].mfc_code);

    return( ret );
}
#endif
