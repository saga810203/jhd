#ifndef TEST_INC_H_
#define TEST_INC_H_
#if !defined(MBEDTLS_CONFIG_FILE)
#include "./mbedtls/config.h"
#else
#include MBEDTLS_CONFIG_FILE
#endif

#include "./mbedtls/debug.h"
/*
 * We're creating and connecting the socket "manually" rather than using the
 * NET module, in order to avoid the overhead of getaddrinfo() which tends to
 * dominate memory usage in small configurations. For the sake of simplicity,
 * only a Unix version is implemented.
 *
 * Warning: we are breaking some of the abtractions from the NET layer here.
 * This is not a good example for general use. This programs has the specific
 * goal of minimizing use of the libc functions on full-blown OSes.
 */
#if defined(unix) || defined(__unix__) || defined(__unix) || defined(__APPLE__)
#define UNIX
#endif



#include "./mbedtls/platform.h"


#include <string.h>

#include "./mbedtls/net_sockets.h"
#include "./mbedtls/ssl.h"
#include "./mbedtls/entropy.h"
#include "./mbedtls/ctr_drbg.h"
#include "./mbedtls/ccm.h"

#define JHD_TLS_CIPHER_AES_128_CCM 0
//
struct  ccm_test_data_t{
		char enc;
        int ignore;
		unsigned char *key;
		size_t key_bytes;
		unsigned char *iv;
		unsigned char *add;
		unsigned char *tag;
		size_t len;
		unsigned char *input;
		unsigned char *output;
};

extern  struct ccm_test_data_t  *ctds[];




#endif /* TEST_INC_H_ */
