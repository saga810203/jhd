#ifndef JHD_TLS_CTR_DRBG_H
#define JHD_TLS_CTR_DRBG_H

#include <tls/jhd_tls_aes.h>
#include <tls/jhd_tls_entropy.h>

#define JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED        -0x0034  /**< The entropy source failed. */
#define JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG              -0x0036  /**< The requested random buffer length is too big. */
#define JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG                -0x0038  /**< The input (entropy + additional data) is too large. */
#define JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR                -0x003A  /**< Read or write error in file. */


/**
 * \brief          The CTR_DRBG context structure.
 */
typedef struct {
	unsigned char counter[16]; /*!< The counter (V). */
	int reseed_counter; /*!< The reseed counter. */
	int prediction_resistance; /*!< This determines whether prediction
	 resistance is enabled, that is
	 whether to systematically reseed before
	 each random generation. */
	size_t entropy_len; /*!< The amount of entropy grabbed on each
	 seed or reseed operation. */
	int reseed_interval; /*!< The reseed interval. */

	jhd_tls_aes_context aes_ctx; /*!< The AES context. */

	/*
	 * Callbacks (Entropy)
	 */
//	int (*f_entropy)(void *, unsigned char *, size_t);
	/*!< The entropy callback function. */

//	void *p_entropy; /*!< The context for the entropy function. */

	jhd_tls_entropy_context entropy;

} jhd_tls_ctr_drbg_context;

int jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom,size_t len);

/**
 * \brief   This function uses CTR_DRBG to generate random data.
 *
 * \note    The function automatically reseeds if the reseed counter is exceeded.
 *
 * \param p_rng         The CTR_DRBG context. This must be a pointer to a
 *                      #jhd_tls_ctr_drbg_context structure.
 * \param output        The buffer to fill.
 * \param output_len    The length of the buffer.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED or
 *                      #JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG on failure.
 */
int jhd_tls_ctr_drbg_random(void *p_rng, unsigned char *output, size_t output_len);

#endif /* ctr_drbg.h */
