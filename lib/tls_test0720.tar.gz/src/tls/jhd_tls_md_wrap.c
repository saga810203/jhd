
#include <tls/jhd_tls_config.h>


#if defined(JHD_TLS_MD_C)

#include <tls/jhd_tls_md_internal.h>

#include <tls/jhd_tls_md5.h>

#if defined(JHD_TLS_RIPEMD160_C)
#include <tls/jhd_tls_ripemd160.h>
#endif

#if defined(JHD_TLS_SHA1_C)
#include <tls/jhd_tls_sha1.h>
#endif

#if defined(JHD_TLS_SHA256_C)
#include <tls/jhd_tls_sha256.h>
#endif

#if defined(JHD_TLS_SHA512_C)
#include <tls/jhd_tls_sha512.h>
#endif


#include <tls/jhd_tls_platform.h>



static int md5_starts_wrap( void *ctx )
{
    return( jhd_tls_md5_starts_ret( (jhd_tls_md5_context *) ctx ) );
}

static int md5_update_wrap( void *ctx, const unsigned char *input,
                             size_t ilen )
{
    return( jhd_tls_md5_update_ret( (jhd_tls_md5_context *) ctx, input, ilen ) );
}

static int md5_finish_wrap( void *ctx, unsigned char *output )
{
    return( jhd_tls_md5_finish_ret( (jhd_tls_md5_context *) ctx, output ) );
}

static void *md5_ctx_alloc( void )
{
    void *ctx = jhd_tls_malloc(sizeof( jhd_tls_md5_context ) );

    if( ctx != NULL )
        jhd_tls_md5_init( (jhd_tls_md5_context *) ctx );

    return( ctx );
}

static void md5_ctx_free( void *ctx )
{
    jhd_tls_md5_free( (jhd_tls_md5_context *) ctx );
    jhd_tls_free( ctx );
}

static void md5_clone_wrap( void *dst, const void *src )
{
    jhd_tls_md5_clone( (jhd_tls_md5_context *) dst,
                       (const jhd_tls_md5_context *) src );
}

static int md5_process_wrap( void *ctx, const unsigned char *data )
{
    return( jhd_tls_internal_md5_process( (jhd_tls_md5_context *) ctx, data ) );
}

const jhd_tls_md_info_t jhd_tls_md5_info = {
    JHD_TLS_MD_MD5,
    "MD5",
    16,
    64,
    md5_starts_wrap,
    md5_update_wrap,
    md5_finish_wrap,
    jhd_tls_md5_ret,
    md5_ctx_alloc,
    md5_ctx_free,
    md5_clone_wrap,
    md5_process_wrap,
};

#if defined(JHD_TLS_RIPEMD160_C)

static int ripemd160_starts_wrap( void *ctx )
{
    return( jhd_tls_ripemd160_starts_ret( (jhd_tls_ripemd160_context *) ctx ) );
}

static int ripemd160_update_wrap( void *ctx, const unsigned char *input,
                                   size_t ilen )
{
    return( jhd_tls_ripemd160_update_ret( (jhd_tls_ripemd160_context *) ctx,
                                          input, ilen ) );
}

static int ripemd160_finish_wrap( void *ctx, unsigned char *output )
{
    return( jhd_tls_ripemd160_finish_ret( (jhd_tls_ripemd160_context *) ctx,
                                          output ) );
}

static void *ripemd160_ctx_alloc( void )
{
    void *ctx = jhd_tls_calloc( 1, sizeof( jhd_tls_ripemd160_context ) );

    if( ctx != NULL )
        jhd_tls_ripemd160_init( (jhd_tls_ripemd160_context *) ctx );

    return( ctx );
}

static void ripemd160_ctx_free( void *ctx )
{
    jhd_tls_ripemd160_free( (jhd_tls_ripemd160_context *) ctx );
    jhd_tls_free( ctx );
}

static void ripemd160_clone_wrap( void *dst, const void *src )
{
    jhd_tls_ripemd160_clone( (jhd_tls_ripemd160_context *) dst,
                       (const jhd_tls_ripemd160_context *) src );
}

static int ripemd160_process_wrap( void *ctx, const unsigned char *data )
{
    return( jhd_tls_internal_ripemd160_process(
                                (jhd_tls_ripemd160_context *) ctx, data ) );
}

const jhd_tls_md_info_t jhd_tls_ripemd160_info = {
    JHD_TLS_MD_RIPEMD160,
    "RIPEMD160",
    20,
    64,
    ripemd160_starts_wrap,
    ripemd160_update_wrap,
    ripemd160_finish_wrap,
    jhd_tls_ripemd160_ret,
    ripemd160_ctx_alloc,
    ripemd160_ctx_free,
    ripemd160_clone_wrap,
    ripemd160_process_wrap,
};

#endif /* JHD_TLS_RIPEMD160_C */

#if defined(JHD_TLS_SHA1_C)

static int sha1_starts_wrap( void *ctx )
{
    return( jhd_tls_sha1_starts_ret( (jhd_tls_sha1_context *) ctx ) );
}

static int sha1_update_wrap( void *ctx, const unsigned char *input,
                              size_t ilen )
{
    return( jhd_tls_sha1_update_ret( (jhd_tls_sha1_context *) ctx,
                                     input, ilen ) );
}

static int sha1_finish_wrap( void *ctx, unsigned char *output )
{
    return( jhd_tls_sha1_finish_ret( (jhd_tls_sha1_context *) ctx, output ) );
}

static void *sha1_ctx_alloc( void )
{
    void *ctx = jhd_tls_calloc( 1, sizeof( jhd_tls_sha1_context ) );

    if( ctx != NULL )
        jhd_tls_sha1_init( (jhd_tls_sha1_context *) ctx );

    return( ctx );
}

static void sha1_clone_wrap( void *dst, const void *src )
{
    jhd_tls_sha1_clone( (jhd_tls_sha1_context *) dst,
                  (const jhd_tls_sha1_context *) src );
}

static void sha1_ctx_free( void *ctx )
{
    jhd_tls_sha1_free( (jhd_tls_sha1_context *) ctx );
    jhd_tls_free( ctx );
}

static int sha1_process_wrap( void *ctx, const unsigned char *data )
{
    return( jhd_tls_internal_sha1_process( (jhd_tls_sha1_context *) ctx,
                                           data ) );
}

const jhd_tls_md_info_t jhd_tls_sha1_info = {
    JHD_TLS_MD_SHA1,
    "SHA1",
    20,
    64,
    sha1_starts_wrap,
    sha1_update_wrap,
    sha1_finish_wrap,
    jhd_tls_sha1_ret,
    sha1_ctx_alloc,
    sha1_ctx_free,
    sha1_clone_wrap,
    sha1_process_wrap,
};

#endif /* JHD_TLS_SHA1_C */

/*
 * Wrappers for generic message digests
 */
#if defined(JHD_TLS_SHA256_C)

static int sha224_starts_wrap( void *ctx )
{
    return( jhd_tls_sha256_starts_ret( (jhd_tls_sha256_context *) ctx, 1 ) );
}

static int sha224_update_wrap( void *ctx, const unsigned char *input,
                                size_t ilen )
{
    return( jhd_tls_sha256_update_ret( (jhd_tls_sha256_context *) ctx,
                                       input, ilen ) );
}

static int sha224_finish_wrap( void *ctx, unsigned char *output )
{
    return( jhd_tls_sha256_finish_ret( (jhd_tls_sha256_context *) ctx,
                                       output ) );
}

static int sha224_wrap( const unsigned char *input, size_t ilen,
                        unsigned char *output )
{
    return( jhd_tls_sha256_ret( input, ilen, output, 1 ) );
}

static void *sha224_ctx_alloc( void )
{
    void *ctx = jhd_tls_calloc( 1, sizeof( jhd_tls_sha256_context ) );

    if( ctx != NULL )
        jhd_tls_sha256_init( (jhd_tls_sha256_context *) ctx );

    return( ctx );
}

static void sha224_ctx_free( void *ctx )
{
    jhd_tls_sha256_free( (jhd_tls_sha256_context *) ctx );
    jhd_tls_free( ctx );
}

static void sha224_clone_wrap( void *dst, const void *src )
{
    jhd_tls_sha256_clone( (jhd_tls_sha256_context *) dst,
                    (const jhd_tls_sha256_context *) src );
}

static int sha224_process_wrap( void *ctx, const unsigned char *data )
{
    return( jhd_tls_internal_sha256_process( (jhd_tls_sha256_context *) ctx,
                                             data ) );
}

const jhd_tls_md_info_t jhd_tls_sha224_info = {
    JHD_TLS_MD_SHA224,
    "SHA224",
    28,
    64,
    sha224_starts_wrap,
    sha224_update_wrap,
    sha224_finish_wrap,
    sha224_wrap,
    sha224_ctx_alloc,
    sha224_ctx_free,
    sha224_clone_wrap,
    sha224_process_wrap,
};

static int sha256_starts_wrap( void *ctx )
{
    return( jhd_tls_sha256_starts_ret( (jhd_tls_sha256_context *) ctx, 0 ) );
}

static int sha256_wrap( const unsigned char *input, size_t ilen,
                        unsigned char *output )
{
    return( jhd_tls_sha256_ret( input, ilen, output, 0 ) );
}

const jhd_tls_md_info_t jhd_tls_sha256_info = {
    JHD_TLS_MD_SHA256,
    "SHA256",
    32,
    64,
    sha256_starts_wrap,
    sha224_update_wrap,
    sha224_finish_wrap,
    sha256_wrap,
    sha224_ctx_alloc,
    sha224_ctx_free,
    sha224_clone_wrap,
    sha224_process_wrap,
};

#endif /* JHD_TLS_SHA256_C */

#if defined(JHD_TLS_SHA512_C)

static int sha384_starts_wrap( void *ctx )
{
    return( jhd_tls_sha512_starts_ret( (jhd_tls_sha512_context *) ctx, 1 ) );
}

static int sha384_update_wrap( void *ctx, const unsigned char *input,
                               size_t ilen )
{
    return( jhd_tls_sha512_update_ret( (jhd_tls_sha512_context *) ctx,
                                       input, ilen ) );
}

static int sha384_finish_wrap( void *ctx, unsigned char *output )
{
    return( jhd_tls_sha512_finish_ret( (jhd_tls_sha512_context *) ctx,
                                       output ) );
}

static int sha384_wrap( const unsigned char *input, size_t ilen,
                        unsigned char *output )
{
    return( jhd_tls_sha512_ret( input, ilen, output, 1 ) );
}

static void *sha384_ctx_alloc( void )
{
    void *ctx = jhd_tls_calloc( 1, sizeof( jhd_tls_sha512_context ) );

    if( ctx != NULL )
        jhd_tls_sha512_init( (jhd_tls_sha512_context *) ctx );

    return( ctx );
}

static void sha384_ctx_free( void *ctx )
{
    jhd_tls_sha512_free( (jhd_tls_sha512_context *) ctx );
    jhd_tls_free( ctx );
}

static void sha384_clone_wrap( void *dst, const void *src )
{
    jhd_tls_sha512_clone( (jhd_tls_sha512_context *) dst,
                    (const jhd_tls_sha512_context *) src );
}

static int sha384_process_wrap( void *ctx, const unsigned char *data )
{
    return( jhd_tls_internal_sha512_process( (jhd_tls_sha512_context *) ctx,
                                             data ) );
}

const jhd_tls_md_info_t jhd_tls_sha384_info = {
    JHD_TLS_MD_SHA384,
    "SHA384",
    48,
    128,
    sha384_starts_wrap,
    sha384_update_wrap,
    sha384_finish_wrap,
    sha384_wrap,
    sha384_ctx_alloc,
    sha384_ctx_free,
    sha384_clone_wrap,
    sha384_process_wrap,
};

static int sha512_starts_wrap( void *ctx )
{
    return( jhd_tls_sha512_starts_ret( (jhd_tls_sha512_context *) ctx, 0 ) );
}

static int sha512_wrap( const unsigned char *input, size_t ilen,
                        unsigned char *output )
{
    return( jhd_tls_sha512_ret( input, ilen, output, 0 ) );
}

const jhd_tls_md_info_t jhd_tls_sha512_info = {
    JHD_TLS_MD_SHA512,
    "SHA512",
    64,
    128,
    sha512_starts_wrap,
    sha384_update_wrap,
    sha384_finish_wrap,
    sha512_wrap,
    sha384_ctx_alloc,
    sha384_ctx_free,
    sha384_clone_wrap,
    sha384_process_wrap,
};

#endif /* JHD_TLS_SHA512_C */

#endif /* JHD_TLS_MD_C */
