
#include <tls/jhd_tls_config.h>


#if defined(JHD_TLS_CTR_DRBG_C)

#include <tls/jhd_tls_ctr_drbg.h>

#include <string.h>

#if defined(JHD_TLS_FS_IO)
#include <stdio.h>
#endif

#if defined(JHD_TLS_SELF_TEST)
#include <tls/jhd_tls_platform.h>
#endif /* JHD_TLS_SELF_TEST */
































#define JHD_TLS_CTR_DRBG_BLOCKSIZE          16 /**< The block size used by the cipher. */
#define JHD_TLS_CTR_DRBG_KEYSIZE            32 /**< The key size used by the cipher. */
#define JHD_TLS_CTR_DRBG_KEYBITS            ( JHD_TLS_CTR_DRBG_KEYSIZE * 8 ) /**< The key size for the DRBG operation, in bits. */
#define JHD_TLS_CTR_DRBG_SEEDLEN            ( JHD_TLS_CTR_DRBG_KEYSIZE + JHD_TLS_CTR_DRBG_BLOCKSIZE ) /**< The seed length, calculated as (counter + AES key). */

/**
 * \name SECTION: Module settings
 *
 * The configuration options you can set for this module are in this section.
 * Either change them in config.h or define them using the compiler command
 * line.
 * \{
 */


#define JHD_TLS_CTR_DRBG_ENTROPY_LEN        48


#if !defined(JHD_TLS_CTR_DRBG_RESEED_INTERVAL)
#define JHD_TLS_CTR_DRBG_RESEED_INTERVAL    10000
/**< The interval before reseed is performed by default. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_INPUT)
#define JHD_TLS_CTR_DRBG_MAX_INPUT          256
/**< The maximum number of additional input Bytes. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_REQUEST)
#define JHD_TLS_CTR_DRBG_MAX_REQUEST        1024
/**< The maximum number of requested Bytes per call. */
#endif

#if !defined(JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
#define JHD_TLS_CTR_DRBG_MAX_SEED_INPUT     384
/**< The maximum size of seed or reseed buffer. */
#endif

/* \} name SECTION: Module settings */

#define JHD_TLS_CTR_DRBG_PR_OFF             0
/**< Prediction resistance is disabled. */
#define JHD_TLS_CTR_DRBG_PR_ON              1
/**< Prediction resistance is enabled. */



#if defined(JHD_TLS_INLINE)
#define jhd_tls_ctr_drbg_init(ctx) memset(ctx, 0, sizeof(jhd_tls_ctr_drbg_context))


#define jhd_tls_ctr_drbg_seed(ctx,custom,len) jhd_tls_ctr_drbg_seed_entropy_len(ctx,  custom, len,JHD_TLS_CTR_DRBG_ENTROPY_LEN)
#else

/**
 * \brief               This function initializes the CTR_DRBG context,
 *                      and prepares it for jhd_tls_ctr_drbg_seed()
 *                      or jhd_tls_ctr_drbg_free().
 *
 * \param ctx           The CTR_DRBG context to initialize.
 */
void jhd_tls_ctr_drbg_init(jhd_tls_ctr_drbg_context *ctx);



/**
 * \brief               This function seeds and sets up the CTR_DRBG
 *                      entropy source for future reseeds.
 *
 * \note Personalization data can be provided in addition to the more generic
 *       entropy source, to make this instantiation as unique as possible.
 *
 * \param ctx           The CTR_DRBG context to seed.
 * \param custom        Personalization data, that is device-specific
 identifiers. Can be NULL.
 * \param len           The length of the personalization data.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED on failure.
 */
//int jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom,size_t len);

#endif

/**
 * \brief               This function clears CTR_CRBG context data.
 *
 * \param ctx           The CTR_DRBG context to clear.
 */
void jhd_tls_ctr_drbg_free(jhd_tls_ctr_drbg_context *ctx);

/**
 * \brief               This function turns prediction resistance on or off.
 *                      The default value is off.
 *
 * \note                If enabled, entropy is gathered at the beginning of
 *                      every call to jhd_tls_ctr_drbg_random_with_add().
 *                      Only use this if your entropy source has sufficient
 *                      throughput.
 *
 * \param ctx           The CTR_DRBG context.
 * \param resistance    #JHD_TLS_CTR_DRBG_PR_ON or #JHD_TLS_CTR_DRBG_PR_OFF.
 */
void jhd_tls_ctr_drbg_set_prediction_resistance(jhd_tls_ctr_drbg_context *ctx, int resistance);

/**
 * \brief               This function sets the amount of entropy grabbed on each
 *                      seed or reseed. The default value is
 *                      #JHD_TLS_CTR_DRBG_ENTROPY_LEN.
 *
 * \param ctx           The CTR_DRBG context.
 * \param len           The amount of entropy to grab.
 */
void jhd_tls_ctr_drbg_set_entropy_len(jhd_tls_ctr_drbg_context *ctx, size_t len);

/**
 * \brief               This function sets the reseed interval.
 *                      The default value is #JHD_TLS_CTR_DRBG_RESEED_INTERVAL.
 *
 * \param ctx           The CTR_DRBG context.
 * \param interval      The reseed interval.
 */
void jhd_tls_ctr_drbg_set_reseed_interval(jhd_tls_ctr_drbg_context *ctx, int interval);

/**
 * \brief               This function reseeds the CTR_DRBG context, that is
 *                      extracts data from the entropy source.
 *
 * \param ctx           The CTR_DRBG context.
 * \param additional    Additional data to add to the state. Can be NULL.
 * \param len           The length of the additional data.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED on failure.
 */
int jhd_tls_ctr_drbg_reseed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t len);

/**
 * \brief              This function updates the state of the CTR_DRBG context.
 *
 * \note               If \p add_len is greater than
 *                     #JHD_TLS_CTR_DRBG_MAX_SEED_INPUT, only the first
 *                     #JHD_TLS_CTR_DRBG_MAX_SEED_INPUT Bytes are used.
 *                     The remaining Bytes are silently discarded.
 *
 * \param ctx          The CTR_DRBG context.
 * \param additional   The data to update the state with.
 * \param add_len      Length of \p additional data.
 *
 */
void jhd_tls_ctr_drbg_update(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t add_len);

/**
 * \brief   This function updates a CTR_DRBG instance with additional
 *          data and uses it to generate random data.
 *
 * \note    The function automatically reseeds if the reseed counter is exceeded.
 *
 * \param p_rng         The CTR_DRBG context. This must be a pointer to a
 *                      #jhd_tls_ctr_drbg_context structure.
 * \param output        The buffer to fill.
 * \param output_len    The length of the buffer.
 * \param additional    Additional data to update. Can be NULL.
 * \param add_len       The length of the additional data.
 *
 * \return    \c 0 on success.
 * \return    #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED or
 *            #JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG on failure.
 */
int jhd_tls_ctr_drbg_random_with_add(void *p_rng, unsigned char *output, size_t output_len, const unsigned char *additional, size_t add_len);



#if defined(JHD_TLS_FS_IO)
/**
 * \brief               This function writes a seed file.
 *
 * \param ctx           The CTR_DRBG context.
 * \param path          The name of the file.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR on file error.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED on
 *                      failure.
 */
int jhd_tls_ctr_drbg_write_seed_file(jhd_tls_ctr_drbg_context *ctx, const char *path);

/**
 * \brief               This function reads and updates a seed file. The seed
 *                      is added to this instance.
 *
 * \param ctx           The CTR_DRBG context.
 * \param path          The name of the file.
 *
 * \return              \c 0 on success.
 * \return              #JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR on file error.
 * \return              #JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED or
 *                      #JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG on failure.
 */
int jhd_tls_ctr_drbg_update_seed_file(jhd_tls_ctr_drbg_context *ctx, const char *path);
#endif /* JHD_TLS_FS_IO */



/* Internal functions (do not call directly) */
int jhd_tls_ctr_drbg_seed_entropy_len(jhd_tls_ctr_drbg_context *,const unsigned char *, size_t, size_t);





























#if !defined(JHD_TLS_INLINE)
void jhd_tls_ctr_drbg_init(jhd_tls_ctr_drbg_context *ctx) {
	memset(ctx, 0, sizeof(jhd_tls_ctr_drbg_context));
}
int jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom, size_t len) {
	return (jhd_tls_ctr_drbg_seed_entropy_len(ctx, custom, len, JHD_TLS_CTR_DRBG_ENTROPY_LEN));
}
#endif

/*
 * Non-public function wrapped by jhd_tls_ctr_drbg_seed(). Necessary to allow
 * NIST tests to succeed (which require known length fixed entropy)
 */
int jhd_tls_ctr_drbg_seed_entropy_len(jhd_tls_ctr_drbg_context *ctx, const unsigned char *custom, size_t len, size_t entropy_len) {
	int ret;
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];

	jhd_tls_platform_zeroize(key,JHD_TLS_CTR_DRBG_KEYSIZE);

	jhd_tls_platform_zeroize(&ctx->aes_ctx,sizeof(jhd_tls_aes_context));


//	ctx->f_entropy = jhd_tls_entropy_func;

	ctx->entropy_len = entropy_len;
	ctx->reseed_interval = JHD_TLS_CTR_DRBG_RESEED_INTERVAL;

	/*
	 * Initialize with an empty key
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&ctx->aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		return (ret);
	}

	if ((ret = jhd_tls_ctr_drbg_reseed(ctx, custom, len)) != 0) {
		return (ret);
	}
	return (0);
}

void jhd_tls_ctr_drbg_free(jhd_tls_ctr_drbg_context *ctx) {
	if (ctx == NULL)
		return;
	jhd_tls_aes_free(&ctx->aes_ctx);
	jhd_tls_platform_zeroize(ctx, sizeof(jhd_tls_ctr_drbg_context));
}

void jhd_tls_ctr_drbg_set_prediction_resistance(jhd_tls_ctr_drbg_context *ctx, int resistance) {
	ctx->prediction_resistance = resistance;
}

void jhd_tls_ctr_drbg_set_entropy_len(jhd_tls_ctr_drbg_context *ctx, size_t len) {
	ctx->entropy_len = len;
}

void jhd_tls_ctr_drbg_set_reseed_interval(jhd_tls_ctr_drbg_context *ctx, int interval) {
	ctx->reseed_interval = interval;
}

static int block_cipher_df(unsigned char *output, const unsigned char *data, size_t data_len) {
	unsigned char buf[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16];
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];
	unsigned char chain[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	unsigned char *p, *iv;
	jhd_tls_aes_context aes_ctx;
	int ret = 0;

	int i, j;
	size_t buf_len, use_len;

	if (data_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	jhd_tls_platform_zeroize(buf,  JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16);
	jhd_tls_platform_zeroize(&aes_ctx,sizeof(jhd_tls_aes_context));

	/*
	 * Construct IV (16 bytes) and S in buffer
	 * IV = Counter (in 32-bits) padded to 16 with zeroes
	 * S = Length input string (in 32-bits) || Length of output (in 32-bits) ||
	 *     data || 0x80
	 *     (Total is padded to a multiple of 16-bytes with zeroes)
	 */
	p = buf + JHD_TLS_CTR_DRBG_BLOCKSIZE;
	*p++ = (data_len >> 24) & 0xff;
	*p++ = (data_len >> 16) & 0xff;
	*p++ = (data_len >> 8) & 0xff;
	*p++ = (data_len) & 0xff;
	p += 3;
	*p++ = JHD_TLS_CTR_DRBG_SEEDLEN;
	memcpy(p, data, data_len);
	p[data_len] = 0x80;

	buf_len = JHD_TLS_CTR_DRBG_BLOCKSIZE + 8 + data_len + 1;

	for (i = 0; i < JHD_TLS_CTR_DRBG_KEYSIZE; i++)
		key[i] = i;

	if ((ret = jhd_tls_aes_setkey_enc(&aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		goto exit;
	}

	/*
	 * Reduce data to JHD_TLS_CTR_DRBG_SEEDLEN bytes of data
	 */
	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		p = buf;
		memset(chain, 0, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		use_len = buf_len;

		while (use_len > 0) {
			for (i = 0; i < JHD_TLS_CTR_DRBG_BLOCKSIZE; i++)
				chain[i] ^= p[i];
			p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
			use_len -= (use_len >= JHD_TLS_CTR_DRBG_BLOCKSIZE) ?
			JHD_TLS_CTR_DRBG_BLOCKSIZE :
			                                                     use_len;

			if ((ret = jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, chain, chain)) != 0) {
				goto exit;
			}
		}

		memcpy(tmp + j, chain, JHD_TLS_CTR_DRBG_BLOCKSIZE);

		/*
		 * Update IV
		 */
		buf[3]++;
	}

	/*
	 * Do final encryption with reduced data
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		goto exit;
	}
	iv = tmp + JHD_TLS_CTR_DRBG_KEYSIZE;
	p = output;

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		if ((ret = jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, iv, iv)) != 0) {
			goto exit;
		}
		memcpy(p, iv, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}
	exit: jhd_tls_aes_free(&aes_ctx);
	/*
	 * tidy up the stack
	 */
	jhd_tls_platform_zeroize(buf, sizeof(buf));
	jhd_tls_platform_zeroize(tmp, sizeof(tmp));
	jhd_tls_platform_zeroize(key, sizeof(key));
	jhd_tls_platform_zeroize(chain, sizeof(chain));
	if (0 != ret) {
		/*
		 * wipe partial seed from memory
		 */
		jhd_tls_platform_zeroize(output, JHD_TLS_CTR_DRBG_SEEDLEN);
	}

	return (ret);
}

static int ctr_drbg_update_internal(jhd_tls_ctr_drbg_context *ctx, const unsigned char data[JHD_TLS_CTR_DRBG_SEEDLEN]) {
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = tmp;
	int i, j;
	int ret = 0;

	memset(tmp, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		if ((ret = jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, p)) != 0) {
			return (ret);
		}

		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}

	for (i = 0; i < JHD_TLS_CTR_DRBG_SEEDLEN; i++)
		tmp[i] ^= data[i];

	/*
	 * Update key and counter
	 */
	if ((ret = jhd_tls_aes_setkey_enc(&ctx->aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS)) != 0) {
		return (ret);
	}
	memcpy(ctx->counter, tmp + JHD_TLS_CTR_DRBG_KEYSIZE, JHD_TLS_CTR_DRBG_BLOCKSIZE);

	return (0);
}

void jhd_tls_ctr_drbg_update(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t add_len) {
	unsigned char add_input[JHD_TLS_CTR_DRBG_SEEDLEN];

	if (add_len > 0) {
		/* MAX_INPUT would be more logical here, but we have to match
		 * block_cipher_df()'s limits since we can't propagate errors */
		if (add_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
			add_len = JHD_TLS_CTR_DRBG_MAX_SEED_INPUT;

		block_cipher_df(add_input, additional, add_len);
		ctr_drbg_update_internal(ctx, add_input);
	}
}

int jhd_tls_ctr_drbg_reseed(jhd_tls_ctr_drbg_context *ctx, const unsigned char *additional, size_t len) {
	unsigned char seed[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT];
	size_t seedlen = 0;
	int ret;

	if (ctx->entropy_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT || len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT - ctx->entropy_len)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	memset(seed, 0, JHD_TLS_CTR_DRBG_MAX_SEED_INPUT);

	/*
	 * Gather entropy_len bytes of entropy to seed state
	 */
	if (0 != jhd_tls_entropy_func(&ctx->entropy, seed, ctx->entropy_len)) {
		return ( JHD_TLS_ERR_CTR_DRBG_ENTROPY_SOURCE_FAILED);
	}

	seedlen += ctx->entropy_len;

	/*
	 * Add additional data
	 */
	if (additional && len) {
		memcpy(seed + seedlen, additional, len);
		seedlen += len;
	}

	/*
	 * Reduce to 384 bits
	 */
	if ((ret = block_cipher_df(seed, seed, seedlen)) != 0) {
		return (ret);
	}

	/*
	 * Update state
	 */
	if ((ret = ctr_drbg_update_internal(ctx, seed)) != 0) {
		return (ret);
	}
	ctx->reseed_counter = 1;

	return (0);
}

int jhd_tls_ctr_drbg_random_with_add(void *p_rng, unsigned char *output, size_t output_len, const unsigned char *additional, size_t add_len) {
	int ret = 0;
	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;
	unsigned char add_input[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = output;
	unsigned char tmp[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	int i;
	size_t use_len;

	if (output_len > JHD_TLS_CTR_DRBG_MAX_REQUEST)
		return ( JHD_TLS_ERR_CTR_DRBG_REQUEST_TOO_BIG);

	if (add_len > JHD_TLS_CTR_DRBG_MAX_INPUT)
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);

	memset(add_input, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	if (ctx->reseed_counter > ctx->reseed_interval || ctx->prediction_resistance) {
		if ((ret = jhd_tls_ctr_drbg_reseed(ctx, additional, add_len)) != 0) {
			return (ret);
		}
		add_len = 0;
	}

	if (add_len > 0) {
		if ((ret = block_cipher_df(add_input, additional, add_len)) != 0) {
			return (ret);
		}
		if ((ret = ctr_drbg_update_internal(ctx, add_input)) != 0) {
			return (ret);
		}
	}

	while (output_len > 0) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		if ((ret = jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, tmp)) != 0) {
			return (ret);
		}

		use_len = (output_len > JHD_TLS_CTR_DRBG_BLOCKSIZE) ? JHD_TLS_CTR_DRBG_BLOCKSIZE : output_len;
		/*
		 * Copy random block to destination
		 */
		memcpy(p, tmp, use_len);
		p += use_len;
		output_len -= use_len;
	}

	if ((ret = ctr_drbg_update_internal(ctx, add_input)) != 0) {
		return (ret);
	}

	ctx->reseed_counter++;

	return (0);
}

int jhd_tls_ctr_drbg_random(void *p_rng, unsigned char *output, size_t output_len) {
	int ret;
	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;

	ret = jhd_tls_ctr_drbg_random_with_add(ctx, output, output_len, NULL, 0);

	return (ret);
}

#if defined(JHD_TLS_FS_IO)
int jhd_tls_ctr_drbg_write_seed_file(jhd_tls_ctr_drbg_context *ctx, const char *path) {
	int ret = JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR;
	FILE *f;
	unsigned char buf[JHD_TLS_CTR_DRBG_MAX_INPUT];

	if ((f = fopen(path, "wb")) == NULL)
		return ( JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR);

	if ((ret = jhd_tls_ctr_drbg_random(ctx, buf, JHD_TLS_CTR_DRBG_MAX_INPUT)) != 0)
		goto exit;

	if (fwrite(buf, 1, JHD_TLS_CTR_DRBG_MAX_INPUT, f) != JHD_TLS_CTR_DRBG_MAX_INPUT)
		ret = JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR;
	else
		ret = 0;

	exit:
	jhd_tls_platform_zeroize(buf, sizeof(buf));

	fclose(f);
	return (ret);
}

int jhd_tls_ctr_drbg_update_seed_file(jhd_tls_ctr_drbg_context *ctx, const char *path) {
	int ret = 0;
	FILE *f;
	size_t n;
	unsigned char buf[JHD_TLS_CTR_DRBG_MAX_INPUT];

	if ((f = fopen(path, "rb")) == NULL)
		return ( JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR);

	fseek(f, 0, SEEK_END);
	n = (size_t) ftell(f);
	fseek(f, 0, SEEK_SET);

	if (n > JHD_TLS_CTR_DRBG_MAX_INPUT) {
		fclose(f);
		return ( JHD_TLS_ERR_CTR_DRBG_INPUT_TOO_BIG);
	}

	if (fread(buf, 1, n, f) != n)
		ret = JHD_TLS_ERR_CTR_DRBG_FILE_IO_ERROR;
	else
		jhd_tls_ctr_drbg_update(ctx, buf, n);

	fclose(f);

	jhd_tls_platform_zeroize(buf, sizeof(buf));

	if (ret != 0)
		return (ret);

	return (jhd_tls_ctr_drbg_write_seed_file(ctx, path));
}
#endif /* JHD_TLS_FS_IO */


#endif /* JHD_TLS_CTR_DRBG_C */
