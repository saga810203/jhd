#include <jhd_time.h>
#include <jhd_config.h>
#include <jhd_log.h>
#include <tls/jhd_tls_config.h>
#include <jhd_log.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <execinfo.h>

#define JHD_CACHE_LOG_TIME_LEN 		19
#define JHD_CACHE_HTTP_DATE_LEN 	29
static u_char log_time_value[JHD_CACHE_LOG_TIME_LEN+1];
static u_char http_time_value[JHD_CACHE_HTTP_DATE_LEN+1];
  unsigned char* 		jhd_cache_log_time = &log_time_value[0];
  unsigned char* 		jhd_cache_http_date = &http_time_value[0];
  uint64_t      	jhd_current_msec;
  time_t			jhd_cache_time;
  pid_t jhd_pid;

  static const char *jhd_log_level_enum[] = { "STDERR", " EMERG", " ALERT", "  CRIT", "   ERR", "  WARN", "NOTICE", "  INFO", " DEBUG", };


  static char  *week[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  static char  *months[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                             "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };


  static char *_log_disabled_func[]={"jhd_process_events_and_timers","jhd_update_time",NULL};

  static char *_log_disabled_files[] ={"jhd_tls_ssl_tls.c","jhd_tls_ssl_srv.c", NULL};

  void _log_out(const char* file_name, const char *func_name, const int line, const uint16_t level,const char* fmt, ...) {
  	va_list args;
  	char errstr[JHD_MAX_ERROR_STR];
  	char **p;
  	size_t len;

//  	if(level>4){
//		p = _log_disabled_func;
//		while((*p) != NULL){
//			if(strcmp(*p,func_name)==0){
//				return;
//			}
//			++p;
//		}
//		p = _log_disabled_files ;
//		while((*p) != NULL){
//			if(strstr(file_name,*p)!= NULL){
//				return;
//			}
//			++p;
//		}
//
//	//		if( (strcmp("test_http_write",func_name)!=0)/*&& (strcmp("jhd_tls_ssl_write",func_name)!=0)*/){
//	//			return;
//	//		}
//
////			return;
//
//  	}


  	printf("%s %s file:%s function:%s line:%6d\n", jhd_cache_log_time, jhd_log_level_enum[level], file_name, func_name, line);

  	len = JHD_MAX_ERROR_STR;
   	va_start(args, fmt);
  	len = vsnprintf(((char*)errstr), (size_t)(JHD_MAX_ERROR_STR), fmt, args);
  	va_end(args);

  	if (len >= JHD_MAX_ERROR_STR) {
  		len = JHD_MAX_ERROR_STR - 1;
  		errstr[JHD_MAX_ERROR_STR - 1] = '\0';
  	}
  	printf(errstr);
  	printf("\n");
	fflush( stdout);
  }


#define  JHD_TEMP_ONCE_DEINFE_IN_FUNCTION  200
void _log_assert(const char* file_name, const char *func_name, const int line) {
	int i,j, npstr;
	void* buffer[JHD_TEMP_ONCE_DEINFE_IN_FUNCTION];
	char** strings;
	printf("!!!!!!!!!!!!!!!====> exit at: file:%s,function:%s,line:%d; reason:%s\r\n", file_name, func_name, line, "^^^^^^^^^^^^^^^^^!!BUGGER!!^^^^^^^^^^^^^^^^^");
	npstr = backtrace(buffer, JHD_TEMP_ONCE_DEINFE_IN_FUNCTION);
	strings = backtrace_symbols(buffer, npstr);
	if (strings == NULL) {
		printf("backtrace return 0\n");
	} else {
		printf("===================backtrace===============================\n");
		for (i = 0; i < npstr; i++) {
			for(j=0; j < i;++j){
				printf("\t");
			}
			printf("==> %s\n", strings[i]);
		}
	}
	printf("\n");
	exit(1);
}
#undef  JHD_TEMP_ONCE_DEINFE_IN_FUNCTION

#ifdef JHD_LOG_ASSERT_ENABLE
#define  log_assert(ASSERT_VAL) if(!(ASSERT_VAL)) _log_assert((const char*)__FILE__,(const char*)__FUNCTION__ ,(const int)__LINE__)
void log_assert_msg(const char *fmt,...){
  	va_list args;
  	size_t len;
  	char errstr[JHD_MAX_ERROR_STR];
  	len = JHD_MAX_ERROR_STR;
   	va_start(args, fmt);
  	len = vsnprintf(((char*)errstr), (size_t)(JHD_MAX_ERROR_STR), fmt, args);
  	va_end(args);
  	if (len >= JHD_MAX_ERROR_STR) {
  		len = JHD_MAX_ERROR_STR - 1;
  		errstr[JHD_MAX_ERROR_STR - 1] = '\0';
  	}
  	fprintf(stderr,errstr);
  	fprintf(stderr,"\n");
	fflush( stdout);
}
void log_assert_buf(const unsigned char *buffer,size_t buf_len,const char *fmt,...){
  	va_list args;
  	size_t len;
  	char errstr[JHD_MAX_ERROR_STR];
  	len = JHD_MAX_ERROR_STR;
   	va_start(args, fmt);
  	len = vsnprintf(((char*)errstr), (size_t)(JHD_MAX_ERROR_STR), fmt, args);
  	va_end(args);
  	if (len >= JHD_MAX_ERROR_STR) {
  		len = JHD_MAX_ERROR_STR - 1;
  		errstr[JHD_MAX_ERROR_STR - 1] = '\0';
  	}
  	fprintf(stderr,errstr);
  	fprintf(stderr,"===>[%lu]{\n",buf_len);
	for(len=0; len < buf_len;){
		fprintf(stderr,"0x%02X,",buffer[len]);
		++len;
		if(len %16 ==0){
			fprintf(stderr,"\n");
		}
	}
	fprintf(stderr,"}\n");
	fflush(stderr);
}
#endif



void
jhd_gmtime(time_t t, struct tm *tp)
{
    int   yday;
    int  sec, min, hour, mday, mon, year, wday, days, leap;

    /* the calculation is valid for positive time_t only */

    if (t < 0) {
        t = 0;
    }

    days = t / 86400;
    sec = t % 86400;

    /*
     * no more than 4 year digits supported,
     * truncate to December 31, 9999, 23:59:59
     */

    if (days > 2932896) {
        days = 2932896;
        sec = 86399;
    }

    /* January 1, 1970 was Thursday */

    wday = (4 + days) % 7;

    hour = sec / 3600;
    sec %= 3600;
    min = sec / 60;
    sec %= 60;

    /*
     * the algorithm based on Gauss' formula,
     * see src/core/ngx_parse_time.c
     */

    /* days since March 1, 1 BC */
    days = days - (31 + 28) + 719527;

    /*
     * The "days" should be adjusted to 1 only, however, some March 1st's go
     * to previous year, so we adjust them to 2.  This causes also shift of the
     * last February days to next year, but we catch the case when "yday"
     * becomes negative.
     */

    year = (days + 2) * 400 / (365 * 400 + 100 - 4 + 1);

    yday = days - (365 * year + year / 4 - year / 100 + year / 400);

    if (yday < 0) {
        leap = (year % 4 == 0) && (year % 100 || (year % 400 == 0));
        yday = 365 + leap + yday;
        year--;
    }

    /*
     * The empirical formula that maps "yday" to month.
     * There are at least 10 variants, some of them are:
     *     mon = (yday + 31) * 15 / 459
     *     mon = (yday + 31) * 17 / 520
     *     mon = (yday + 31) * 20 / 612
     */

    mon = (yday + 31) * 10 / 306;

    /* the Gauss' formula that evaluates days before the month */

    mday = yday - (367 * mon / 12 - 30) + 1;

    if (yday >= 306) {

        year++;
        mon -= 10;

        /*
         * there is no "yday" in Win32 SYSTEMTIME
         *
         * yday -= 306;
         */

    } else {

        mon += 2;

        /*
         * there is no "yday" in Win32 SYSTEMTIME
         *
         * yday += 31 + 28 + leap;
         */
    }

    tp->tm_sec=  sec;
    tp->tm_min =  min;
    tp->tm_hour = hour;
    tp->tm_mday =mday;
    tp->tm_mon = mon;
    tp->tm_year = year;
    tp->tm_wday = wday;
}

void jhd_update_time() {
	struct tm tm, gmt;
	struct timeval tv;
	struct timespec ts;

	gettimeofday(&tv, NULL);

	clock_gettime(CLOCK_MONOTONIC_COARSE, &ts);

	jhd_current_msec = ts.tv_sec * 1000 + (ts.tv_nsec / 1000000);

	if (jhd_cache_time == tv.tv_sec) {
		return;
	}
	jhd_cache_time = tv.tv_sec;
	jhd_gmtime(jhd_cache_time, &gmt);
	sprintf((char*)jhd_cache_http_date, "%s, %02d %s %4d %02d:%02d:%02d GMT", week[gmt.tm_wday], gmt.tm_mday, months[gmt.tm_mon - 1], gmt.tm_year, gmt.tm_hour, gmt.tm_min,gmt.tm_sec);

	//TODO:  impl    cache_time + timezone_value :   +  8*60*60     beijing
	localtime_r(&tv.tv_sec, &tm);

	tm.tm_mon++;
	tm.tm_year += 1900;

	sprintf((char*)jhd_cache_log_time, "%4d/%02d/%02d %02d:%02d:%02d", tm.tm_year, tm.tm_mon, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

	log_debug("log time:%s",jhd_cache_log_time);


}





#ifdef JHD_LOG_LEVEL_INFO
  char jhd_log_static_buf[JHD_LOG_STATIC_BUFFER_MAX_SIZE];
  static const char* _JHD_HEX_STR[]={"0x00","0x01","0x02","0x03","0x04","0x05","0x06","0x07","0x08","0x09","0x0A","0x0B","0x0C","0x0D","0x0E","0x0F",
  				"0x10","0x11","0x12","0x13","0x14","0x15","0x16","0x17","0x18","0x19","0x1A","0x1B","0x1C","0x1D","0x1E","0x1F",
  				"0x20","0x21","0x22","0x23","0x24","0x25","0x26","0x27","0x28","0x29","0x2A","0x2B","0x2C","0x2D","0x2E","0x2F",
  				"0x30","0x31","0x32","0x33","0x34","0x35","0x36","0x37","0x38","0x39","0x3A","0x3B","0x3C","0x3D","0x3E","0x3F",
  				"0x40","0x41","0x42","0x43","0x44","0x45","0x46","0x47","0x48","0x49","0x4A","0x4B","0x4C","0x4D","0x4E","0x4F",
  				"0x50","0x51","0x52","0x53","0x54","0x55","0x56","0x57","0x58","0x59","0x5A","0x5B","0x5C","0x5D","0x5E","0x5F",
  				"0x60","0x61","0x62","0x63","0x64","0x65","0x66","0x67","0x68","0x69","0x6A","0x6B","0x6C","0x6D","0x6E","0x6F",
  				"0x70","0x71","0x72","0x73","0x74","0x75","0x76","0x77","0x78","0x79","0x7A","0x7B","0x7C","0x7D","0x7E","0x7F",
  				"0x80","0x81","0x82","0x83","0x84","0x85","0x86","0x87","0x88","0x89","0x8A","0x8B","0x8C","0x8D","0x8E","0x8F",
  				"0x90","0x91","0x92","0x93","0x94","0x95","0x96","0x97","0x98","0x99","0x9A","0x9B","0x9C","0x9D","0x9E","0x9F",
  				"0xA0","0xA1","0xA2","0xA3","0xA4","0xA5","0xA6","0xA7","0xA8","0xA9","0xAA","0xAB","0xAC","0xAD","0xAE","0xAF",
  				"0xB0","0xB1","0xB2","0xB3","0xB4","0xB5","0xB6","0xB7","0xB8","0xB9","0xBA","0xBB","0xBC","0xBD","0xBE","0xBF",
  				"0xC0","0xC1","0xC2","0xC3","0xC4","0xC5","0xC6","0xC7","0xC8","0xC9","0xCA","0xCB","0xCC","0xCD","0xCE","0xCF",
  				"0xD0","0xD1","0xD2","0xD3","0xD4","0xD5","0xD6","0xD7","0xD8","0xD9","0xDA","0xDB","0xDC","0xDD","0xDE","0xDF",
  				"0xE0","0xE1","0xE2","0xE3","0xE4","0xE5","0xE6","0xE7","0xE8","0xE9","0xEA","0xEB","0xEC","0xED","0xEE","0xEF",
  				"0xF0","0xF1","0xF2","0xF3","0xF4","0xF5","0xF6","0xF7","0xF8","0xF9","0xFA","0xFB","0xFC","0xFD","0xFE","0xFF",
  };

  void jhd_log_gen_buf(char* title,void *buf,size_t len)
  {
  	size_t i ,slen;
  	unsigned char *p=buf;
  	const char *s;
  	slen = 0;
  	slen += snprintf(((char*)(&jhd_log_static_buf[slen])),(size_t)(JHD_LOG_STATIC_BUFFER_MAX_SIZE-slen),"%s:[%ld]{",title,len);
  	for(i=0;i < len ;++i){
  		s = _JHD_HEX_STR[p[i]];
  		slen += snprintf(((char*)(&jhd_log_static_buf[slen])),(size_t)(JHD_LOG_STATIC_BUFFER_MAX_SIZE-slen),"%s,",s);
  		if(((i+1) % 16)==0){
  			slen += snprintf(((char*)(&jhd_log_static_buf[slen])),(size_t)(JHD_LOG_STATIC_BUFFER_MAX_SIZE-slen),"\n");
  		}
  	}
  	slen += snprintf(((char*)(&jhd_log_static_buf[slen])),(size_t)(JHD_LOG_STATIC_BUFFER_MAX_SIZE-slen),"}\n");
  }
#endif


#ifdef JHD_LOG_TEST_ENABLE


void log_test_buf(void *title,unsigned char *buf, size_t len){
	int i ;
	printf("%s==>[%lu]  ",(char *)title,len);
	for(i =0;i < len ;++i){
		printf("0X%02X,",buf[i]);
	}
	printf("}\n");

}

#endif
