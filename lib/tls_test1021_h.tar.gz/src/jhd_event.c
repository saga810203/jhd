/*
 * jhd_event.c
 *
 *  Created on: May 30, 2018
 *      Author: root
 */
#include <jhd_config.h>
#include <jhd_log.h>
#include <jhd_time.h>
#include <jhd_event.h>
#include <jhd_connection.h>
#include <tls/jhd_tls_config.h>
#include <sys/epoll.h>



jhd_queue_t jhd_posted_accept_events;
jhd_queue_t jhd_posted_events;
int epoll_fd;
struct epoll_event *event_list;
int event_count;

void jhd_event_noop(jhd_event_t *ev) {
	log_notice("%s", "exec function");
}

void jhd_process_events_and_timers() {
	uint32_t revents;
	int i;
	jhd_connection_t *c;
	int events;
	jhd_queue_t *q;
	jhd_event_t *ev;
	jhd_update_time();

	events = epoll_wait(epoll_fd, event_list, event_count, 1000);
	log_debug("epoll_wait(...)=%d",events);
	if (events > 0) {
		for (i = 0; i < events; ++i) {
			c = (jhd_connection_t*) event_list[i].data.ptr;
			revents = event_list[i].events;
			if (revents & (EPOLLERR | EPOLLHUP)) {
				revents |= EPOLLIN | EPOLLOUT;
			}
			if ((revents & EPOLLIN)) {
				if (c->ssl == NULL) {
					jhd_queue_insert_tail(&jhd_posted_accept_events, &c->read.queue);
				} else {
					jhd_queue_insert_tail(&jhd_posted_events, &c->read.queue);
				}
			}

			if (revents & EPOLLOUT) {
				if (c->read.queue.next == NULL) {
					jhd_queue_insert_tail(&jhd_posted_events, &c->write.queue);
				}
			}
		}
	}

	while (!jhd_queue_empty(&jhd_posted_accept_events)) {
		q = jhd_queue_head(&jhd_posted_accept_events);
		ev = jhd_queue_data(q, jhd_event_t, queue);
		jhd_delete_posted_event(ev);
		ev->handler(ev);
	}

	while (!jhd_queue_empty(&jhd_posted_events)) {
#ifdef JHD_LOG_LEVEL_DEBUG
		getchar();
#endif
		q = jhd_queue_head(&jhd_posted_events);
		ev = jhd_queue_data(q, jhd_event_t, queue);
		jhd_delete_posted_event(ev);
		ev->handler(ev);
	}

}

jhd_tls_bool jhd_event_add_connection(void *c) {

	struct epoll_event ee;

	ee.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;
	ee.data.ptr = c;

	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, ((jhd_connection_t*) c)->fd, &ee) == -1) {
		//TODO:LOG
		return jhd_tls_false;
	}
	return jhd_tls_true;

}
jhd_tls_bool jhd_event_del_connection(void *c) {
	struct epoll_event ee;
	ee.events = 0;
	ee.data.ptr = NULL;

	if (epoll_ctl(epoll_fd, EPOLL_CTL_DEL, ((jhd_connection_t*) c)->fd, &ee) == -1) {
		//TODO:LOG
		return jhd_tls_false;
	}
	return jhd_tls_true;
}

int jhd_event_init() {
	event_list = NULL;
	event_count = 100;

	jhd_queue_init(&jhd_posted_events);
	jhd_queue_init(&jhd_posted_accept_events);

	epoll_fd = epoll_create(100);
	if (epoll_fd == -1) {
		log_err("execut epoll_create(%d) error", (int )100);
		return 1;
	}

	event_list = (struct epoll_event*)malloc((sizeof(struct epoll_event) * 200));
	if (event_list == NULL) {
		log_err("malloc event_list failed with:%d ", sizeof(struct epoll_event) * 200);
		return 1;
	}
	return 0;

}

