#ifndef __USE_GNU
#define __USE_GNU
#endif
#include <jhd_config.h>
#include <jhd_log.h>
#include <jhd_time.h>
#include <jhd_event.h>
#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_platform.h>
#include <jhd_connection.h>
//#include <sys/ioctl.h>
//
//#include <stdlib.h>
//#include <stdio.h>
//#include <string.h>
//
#include <tls/jhd_tls_entropy.h>
#include <tls/jhd_tls_ctr_drbg.h>
#include <tls/jhd_tls_certs.h>
#include <tls/jhd_tls_x509.h>
#include <tls/jhd_tls_ssl_internal.h>
#include <tls/jhd_tls_error.h>
#include <jhd_ssl_connection.h>
#include <jhd_queue.h>
#include <jhd_event.h>
//#include <test_inc.h1>
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <errno.h>
//#include <sys/epoll.h>
//
//#include <unistd.h>

#ifndef __USE_GNU
#define __USE_GNU
#endif

#define HTTP_RESPONSE \
    "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n" \
    "<h2>mbed TLS Test Server</h2>\r\n" \
    "<p>Successful connection using: %s</p>\r\n"

#define DEBUG_LEVEL 0


typedef struct{
		unsigned char send_buffer[0XFFFF];
		unsigned char recv_buffer[0XFFFF];
		size_t recv_buf_idx;
		size_t send_buf_idx;
		size_t send_buffer_len;
		size_t recv_buffer_len;
		size_t package_idx;
} test_data_t;




typedef union {
	struct sockaddr sockaddr;
	struct sockaddr_in sockaddr_in;

	struct sockaddr_in6 sockaddr_in6;
} jhd_sockaddr_t;

jhd_tls_ssl_config conf;
//
//int main2(void);
//

static  int run_test_flag = 0;


















unsigned char test_cert[] ="-----BEGIN CERTIFICATE-----\r\n"
"MIIGDDCCBPSgAwIBAgIQBm5HdrA6vfwUhXklzB27CzANBgkqhkiG9w0BAQsFADBe\r\n"
"MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3\r\n"
"d3cuZGlnaWNlcnQuY29tMR0wGwYDVQQDExRHZW9UcnVzdCBSU0EgQ0EgMjAxODAe\r\n"
"Fw0xODA5MjYwMDAwMDBaFw0xOTA5MjYxMjAwMDBaMHAxCzAJBgNVBAYTAkNOMRIw\r\n"
"EAYDVQQHDAnljJfkuqzluIIxJzAlBgNVBAoMHuWMl+S6rOenkeiiluenkeaKgOac\r\n"
"iemZkOWFrOWPuDELMAkGA1UECxMCSVQxFzAVBgNVBAMTDnd3dy5la2V4aXUuY29t\r\n"
"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs8luYjDJsXLUUIa8HQxI\r\n"
"pVqcAd+rlM84pZY5m0c01VjlrrB6r/4GaepnafSnNguwbvDDZx6R+kdBrn0I3/EK\r\n"
"p4YM7hBMDVDnPB2Gqa1VG07CkE5lS3NeonB9SWTkZs1AK52oIHMZteGM+gigO5Ri\r\n"
"lPfDio6K/g+AYD9o21rgJGvSx7J9E9bD85WhvICjS7CAwtiPBgQtI5vKWKY7Nufh\r\n"
"Dsl+q1+wV3nLPOHk5KQlRM7XpMRcHTYWQZjHd6TyXwPMepWnm7Oz/Imh2ogqQVX4\r\n"
"0XUV7OqeVxnOfI9lAVT1pZNtvpm6SAPR0wBG8J++MmkCySgmsfPC4S/xRdjpALZ5\r\n"
"WwIDAQABo4ICsjCCAq4wHwYDVR0jBBgwFoAUkFj/sJx1qFFUd7Ht8qNDFjiebMUw\r\n"
"HQYDVR0OBBYEFL5CGu8It+3hjGqAjWMP3rXI9lQhMCUGA1UdEQQeMByCDnd3dy5l\r\n"
"a2V4aXUuY29tggpla2V4aXUuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAU\r\n"
"BggrBgEFBQcDAQYIKwYBBQUHAwIwPgYDVR0fBDcwNTAzoDGgL4YtaHR0cDovL2Nk\r\n"
"cC5nZW90cnVzdC5jb20vR2VvVHJ1c3RSU0FDQTIwMTguY3JsMEwGA1UdIARFMEMw\r\n"
"NwYJYIZIAYb9bAEBMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0\r\n"
"LmNvbS9DUFMwCAYGZ4EMAQICMHUGCCsGAQUFBwEBBGkwZzAmBggrBgEFBQcwAYYa\r\n"
"aHR0cDovL3N0YXR1cy5nZW90cnVzdC5jb20wPQYIKwYBBQUHMAKGMWh0dHA6Ly9j\r\n"
"YWNlcnRzLmdlb3RydXN0LmNvbS9HZW9UcnVzdFJTQUNBMjAxOC5jcnQwCQYDVR0T\r\n"
"BAIwADCCAQQGCisGAQQB1nkCBAIEgfUEgfIA8AB1AKS5CZC0GFgUh7sTosxncAo8\r\n"
"NZgE+RvfuON3zQ7IDdwQAAABZhTUQekAAAQDAEYwRAIgRK2qS3oFGLtgySERgcHC\r\n"
"DkSKqyhgVcpEqrSb0p4cvgQCICC9zHECvlhAUvBKzJV4n9+r2nxJXaTWBGD3iFiI\r\n"
"UnBNAHcAh3W/51l8+IxDmV+9827/Vo1HVjb/SrVgwbTq/16ggw8AAAFmFNRCogAA\r\n"
"BAMASDBGAiEAoTr3AAQYCnJ1Hw4quIK5qMSUih5WeARHmncMLyPq1pcCIQD6sqBT\r\n"
"kLLRIXflbqTbk1NqoPTYQEJCgdMi4Ym5TF9NNzANBgkqhkiG9w0BAQsFAAOCAQEA\r\n"
"GB/LGf7wXvqUokLx+ECVJeZS0l/ag8n/OuyPkKm3ZRsnFsoCmrcZqWtgrtt5mDQ1\r\n"
"KrpLTQVpX+WrBsqz3pyZZ8l+X8LTBKMG2mGRojInQMYmOG+hxlYJK/e94szy2ZO4\r\n"
"ITfHnZ4LyBkFSaI1ML+VVmyQMNcwspBJE5Y23PKGw7SVriUSt5T0fQWaiPX5plYu\r\n"
"4aokoMsHJfvRVAh9NE0HxrsJX6DKeYtAT/lz7UaWqrrLqvZTr+yjErWIPaEl7KoP\r\n"
"mmtUQVcr+kV+bNNQCWa7uOg8wpu++UihXFObcQhXCB8KwMWnm8n1JXcMh6XsrvBN\r\n"
"xHh1SZObQOmlN3M+vEHlPw==\r\n"
"-----END CERTIFICATE-----\r\n"
"-----BEGIN CERTIFICATE-----\r\n"
"MIIEizCCA3OgAwIBAgIQBUb+GCP34ZQdo5/OFMRhczANBgkqhkiG9w0BAQsFADBh\r\n"
"MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3\r\n"
"d3cuZGlnaWNlcnQuY29tMSAwHgYDVQQDExdEaWdpQ2VydCBHbG9iYWwgUm9vdCBD\r\n"
"QTAeFw0xNzExMDYxMjIzNDVaFw0yNzExMDYxMjIzNDVaMF4xCzAJBgNVBAYTAlVT\r\n"
"MRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5j\r\n"
"b20xHTAbBgNVBAMTFEdlb1RydXN0IFJTQSBDQSAyMDE4MIIBIjANBgkqhkiG9w0B\r\n"
"AQEFAAOCAQ8AMIIBCgKCAQEAv4rRY03hGOqHXegWPI9/tr6HFzekDPgxP59FVEAh\r\n"
"150Hm8oDI0q9m+2FAmM/n4W57Cjv8oYi2/hNVEHFtEJ/zzMXAQ6CkFLTxzSkwaEB\r\n"
"2jKgQK0fWeQz/KDDlqxobNPomXOMJhB3y7c/OTLo0lko7geG4gk7hfiqafapa59Y\r\n"
"rXLIW4dmrgjgdPstU0Nigz2PhUwRl9we/FAwuIMIMl5cXMThdSBK66XWdS3cLX18\r\n"
"4ND+fHWhTkAChJrZDVouoKzzNYoq6tZaWmyOLKv23v14RyZ5eqoi6qnmcRID0/i6\r\n"
"U9J5nL1krPYbY7tNjzgC+PBXXcWqJVoMXcUw/iBTGWzpwwIDAQABo4IBQDCCATww\r\n"
"HQYDVR0OBBYEFJBY/7CcdahRVHex7fKjQxY4nmzFMB8GA1UdIwQYMBaAFAPeUDVW\r\n"
"0Uy7ZvCj4hsbw5eyPdFVMA4GA1UdDwEB/wQEAwIBhjAdBgNVHSUEFjAUBggrBgEF\r\n"
"BQcDAQYIKwYBBQUHAwIwEgYDVR0TAQH/BAgwBgEB/wIBADA0BggrBgEFBQcBAQQo\r\n"
"MCYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBCBgNVHR8E\r\n"
"OzA5MDegNaAzhjFodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRHbG9i\r\n"
"YWxSb290Q0EuY3JsMD0GA1UdIAQ2MDQwMgYEVR0gADAqMCgGCCsGAQUFBwIBFhxo\r\n"
"dHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA0GCSqGSIb3DQEBCwUAA4IBAQAw\r\n"
"8YdVPYQI/C5earp80s3VLOO+AtpdiXft9OlWwJLwKlUtRfccKj8QW/Pp4b7h6QAl\r\n"
"ufejwQMb455OjpIbCZVS+awY/R8pAYsXCnM09GcSVe4ivMswyoCZP/vPEn/LPRhH\r\n"
"hdgUPk8MlD979RGoUWz7qGAwqJChi28uRds3thx+vRZZIbEyZ62No0tJPzsSGSz8\r\n"
"nQ//jP8BIwrzBAUH5WcBAbmvgWfrKcuv+PyGPqRcc4T55TlzrBnzAzZ3oClo9fTv\r\n"
"O9PuiHMKrC6V6mgi0s2sa/gbXlPCD9Z24XUMxJElwIVTDuKB0Q4YMMlnpN/QChJ4\r\n"
"B0AFsQ+DU0NCO+f78Xf7\r\n"
"-----END CERTIFICATE-----\r\n";


unsigned char test_cert2[] ="-----BEGIN CERTIFICATE-----\r\n"
"MIIFhDCCBGygAwIBAgIQYo/3DGT1fsnoaCspg1GTMTANBgkqhkiG9w0BAQsFADCB\r\n"
"lDELMAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8w\r\n"
"HQYDVQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMR0wGwYDVQQLExREb21haW4g\r\n"
"VmFsaWRhdGVkIFNTTDEmMCQGA1UEAxMdU3ltYW50ZWMgQmFzaWMgRFYgU1NMIENB\r\n"
"IC0gRzEwHhcNMTcxMTE1MDAwMDAwWhcNMTgxMDEzMjM1OTU5WjAZMRcwFQYDVQQD\r\n"
"DA53d3cuZWtleGl1LmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB\r\n"
"ANKZWOE1UhB05yw4yhQX9Ov36HeTw7pKlY/oDzMLYUDuFWTQEiN5dDGj64YkBvRU\r\n"
"0GI9bl+ysMtKKC3Z3ZbCMsM96YcnpodO4P5EUmdMFPsCn3fqpGZHSyJ+7c4kX7up\r\n"
"3Ug7fww2GAY7r2mCM/6FYTefyYeJgMeytKYO84qe2n6M6QIiaJ4AWs2GPgv8q7L2\r\n"
"UfP1LG5jnWkzH+gFG2PTSBSZHm1DBgkxS1yBY7COrvmZJOU0b6rAlRyvlQG5iptx\r\n"
"Mj1aoNgNunN+Zqx2hoeZPBGTDAm427qOn3tLfJlXqTEXtcRLhDrYeMTK756d8k3x\r\n"
"5BKSdLDxTAqJPSGDaD/JUz8CAwEAAaOCAkowggJGMCUGA1UdEQQeMByCDnd3dy5l\r\n"
"a2V4aXUuY29tggpla2V4aXUuY29tMAkGA1UdEwQCMAAwYQYDVR0gBFowWDBWBgZn\r\n"
"gQwBAgEwTDAjBggrBgEFBQcCARYXaHR0cHM6Ly9kLnN5bWNiLmNvbS9jcHMwJQYI\r\n"
"KwYBBQUHAgIwGQwXaHR0cHM6Ly9kLnN5bWNiLmNvbS9ycGEwHwYDVR0jBBgwFoAU\r\n"
"XGGesHZBqWqqQwvhx24wKW6xzTYwDgYDVR0PAQH/BAQDAgWgMB0GA1UdJQQWMBQG\r\n"
"CCsGAQUFBwMBBggrBgEFBQcDAjBXBggrBgEFBQcBAQRLMEkwHwYIKwYBBQUHMAGG\r\n"
"E2h0dHA6Ly9oYy5zeW1jZC5jb20wJgYIKwYBBQUHMAKGGmh0dHA6Ly9oYy5zeW1j\r\n"
"Yi5jb20vaGMuY3J0MIIBBAYKKwYBBAHWeQIEAgSB9QSB8gDwAHYA3esdK3oNT6Yg\r\n"
"i4GtgWhwfi6OnQHVXIiNPRHEzbbsvswAAAFfvrFfqQAABAMARzBFAiEAskKCj9/q\r\n"
"XQmkGDq0TV8hHi1BjSGUEvqKlR20ptuXtj8CIDHy+l0dj3RzkFnJGWED4uyFr5oP\r\n"
"wmibune51BFos6KcAHYApLkJkLQYWBSHuxOizGdwCjw1mAT5G9+443fNDsgN3BAA\r\n"
"AAFfvrFf5QAABAMARzBFAiEA61NKgXmdCCUmbZYtDQLJ97ZUpLBKkVoRF1dt87ye\r\n"
"BNsCIC/sGQY747IeYFMFMcXxVDh+jHXAUgKZK+d0R37blc5/MA0GCSqGSIb3DQEB\r\n"
"CwUAA4IBAQAlDE1S6hpE+kb6tNRxX+mWK+Cr8tl7PSEEBaYgGdNbSn4ryyznUij2\r\n"
"sOScbUR1PxCJtamyp2Er4Kprkrv8kBFoF/HstWwohJJEKI6E3T6UyD0PzB79dSaB\r\n"
"gqtyzJw+R50kxPG23UOed0QNEU2xOsWzotMF1WgaT2FA/eF1c7m1duvLfRPAvQX9\r\n"
"GbDWFUzQtPftrvoCDq8ygxnjUbBEiWSOghquH5UbHJ7Tk7YvDJzRHNGQ07UNau4W\r\n"
"tMlymzZRYyEEavtHP2D3DnlNhy6JurRBYVNar/YhI+aGe7KmdEEtFrtB9c9jYteg\r\n"
"2DJKyPca144CLP/hCmcOwhuaqBL01bLR\r\n"
"-----END CERTIFICATE-----\r\n"
"-----BEGIN CERTIFICATE-----\r\n"
"MIIFYjCCBEqgAwIBAgIQTEzYoPxP6q4VVKh/CQ7ahzANBgkqhkiG9w0BAQsFADCB\r\n"
"yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL\r\n"
"ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp\r\n"
"U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW\r\n"
"ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0\r\n"
"aG9yaXR5IC0gRzUwHhcNMTYwNjA3MDAwMDAwWhcNMjYwNjA2MjM1OTU5WjCBlDEL\r\n"
"MAkGA1UEBhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMR8wHQYD\r\n"
"VQQLExZTeW1hbnRlYyBUcnVzdCBOZXR3b3JrMR0wGwYDVQQLExREb21haW4gVmFs\r\n"
"aWRhdGVkIFNTTDEmMCQGA1UEAxMdU3ltYW50ZWMgQmFzaWMgRFYgU1NMIENBIC0g\r\n"
"RzEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCkN8hYylrZCZihZgN2\r\n"
"5FsiT+qfOv8rKi3MbRIsZ2TUqsS5e1eDLPXI8IP4XXUZLWt9hlqmDpqiZa5mLSBj\r\n"
"KDX3iWq/FaOc8l1AsbeOhr9ZESCoEorqm6S9wAL+HX7hLY/7p03SSNSAO+/gr2o7\r\n"
"ciWu3jhd+H4dzGNNDN0nCuRIOX7rTGYI5mOb8QWJRC6H/3MlUYpBt9VV+l2FVNhB\r\n"
"LJuofF3TNJojVHximZnTEkybg/r9AZc2TkDHJX1BA6rNjXG8l5iSCL9ICJCBUPB5\r\n"
"z/s3hQBQkOALXN88QTIrlj53XpWpqxYdQJrOFbtWi18WW3ZAnGAscd8vZ5UIg3KL\r\n"
"AmoBAgMBAAGjggF2MIIBcjASBgNVHRMBAf8ECDAGAQH/AgEAMC8GA1UdHwQoMCYw\r\n"
"JKAioCCGHmh0dHA6Ly9zLnN5bWNiLmNvbS9wY2EzLWc1LmNybDAOBgNVHQ8BAf8E\r\n"
"BAMCAQYwLgYIKwYBBQUHAQEEIjAgMB4GCCsGAQUFBzABhhJodHRwOi8vcy5zeW1j\r\n"
"ZC5jb20wYQYDVR0gBFowWDBWBgZngQwBAgEwTDAjBggrBgEFBQcCARYXaHR0cHM6\r\n"
"Ly9kLnN5bWNiLmNvbS9jcHMwJQYIKwYBBQUHAgIwGRoXaHR0cHM6Ly9kLnN5bWNi\r\n"
"LmNvbS9ycGEwHQYDVR0lBBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMCkGA1UdEQQi\r\n"
"MCCkHjAcMRowGAYDVQQDExFTeW1hbnRlY1BLSS0yLTU1NTAdBgNVHQ4EFgQUXGGe\r\n"
"sHZBqWqqQwvhx24wKW6xzTYwHwYDVR0jBBgwFoAUf9Nlp8Ld7LvwMAnzQzn6Aq8z\r\n"
"MTMwDQYJKoZIhvcNAQELBQADggEBAGHqRXEvjeE/CpuVSPHyPKJYFsqWxP/a4quX\r\n"
"cRCRsy+ki4EP8qT7NfPnkEogxZvlMctHsWgdtTbp9ShXbqCnqXPCw575BZH2rEKN\r\n"
"xI30CWr6U47n4h2hSnaJxJeeA+xKsA1Vk4v8eLu7xwRlBwhZEsYNFAVpD3YEToek\r\n"
"H877QzZrZ6EdG/3Vg6sdtHDQ4i/U87syTmyM2l8vXOGIZDd1Wr6dqee2FtCfhvAc\r\n"
"WMbvh/J6sBOHMq0Vn5G8Tp6iUwsRlY1z7LaQKAlnlOiiZVhhe+1gvzJBHC0t+Hr2\r\n"
"2YHwaoKDLhSB0F/gGkziNQ+py1hFne4MEOuvzOxJpjn0+wRIbBk=\r\n"
"-----END CERTIFICATE-----\r\n";

int test(){
	unsigned char secret[]={0x03,0x01,0xA6,0x3E,0xE4,0x0D,0xCA,0x0F,0x87,0xB9,0x8F,0x17,0x17,0xA6,0x74,0x3C,
	 0xB7,0x8E,0x09,0x32,0xFB,0x23,0x93,0x4E,0x1E,0x4A,0x71,0x58,0x4C,0x3E,0x26,0x21,
	 0x33,0xF6,0x0D,0x74,0x3E,0x59,0xE0,0x4B,0x06,0xA3,0xB7,0x94,0xAE,0x30,0xC2,0x07,};

	unsigned char *lable ="extended master secret";

	unsigned char randomBytes[]={0x5B,0xC9,0x3B,0x8A,0xCC,0xDA,0x4C,0x4E,0xF2,0xBE,0x4E,0x74,0x62,0x3D,0x41,0x99,
			 0x90,0x6E,0x0A,0x38,0xF1,0x89,0x2F,0x4C,0x1A,0x77,0xE1,0xDC,0x70,0xB9,0x25,0x21,
			 0x5B,0xC9,0x3B,0x8A,0x63,0xD5,0xBA,0x74,0x43,0xF8,0xEE,0xED,0x61,0x6E,0x3E,0x1D,
			 0xB4,0x5A,0x9A,0x9A,0x30,0x3B,0x77,0xC2,0x8F,0x41,0x17,0xF1,0x5A,0x13,0x4C,0x5A,};

	unsigned char dstbuf[48];

	jhd_tls_tls1_prf(secret,48,lable,randomBytes,64,dstbuf,48);
	log_buf_debug("MASTER",dstbuf,48);



/*	unsigned char buf[32];
	size_t i,j,num;
	num = 10000;
	struct timespec    tbegin,tend;
	   clock_gettime(CLOCK_MONOTONIC,&tbegin);
	for(i=0; i <num;++i){
		for(j=0;j<num;++j){
			jhd_tls_random(buf,32);
		}
	}
	clock_gettime(CLOCK_MONOTONIC,&tend);

	i = tend.tv_sec  *1000;
			i += (tend.tv_nsec / 1000000);

			i -= tbegin.tv_sec  *1000;
			i -= (tbegin.tv_nsec / 1000000);

			printf("time:%luM  SECONE:%lu   MILL:%lu\n",num * num /10000, i / 1000,i);*/

//	unsigned char name[1024];
//	unsigned char info[1024*1024];
//	jhd_tls_x509_crt srvcert,*cCert;
//	jhd_tls_x509_name *cname;
//
//	jhd_tls_asn1_sequence *sn;
//	jhd_tls_x509_crt_init(&srvcert);
//	if(0 ==jhd_tls_x509_crt_parse(&srvcert,test_cert,sizeof(test_cert))){
//
//		cCert = &srvcert;
//		do{
//		   printf("===================begin cert==============\n");
//
//		   cname = &srvcert.issuer;
//
//		   			do{
//		   			memset(name,0,1024);
//		   			memcpy(name,cname->val.p,cname->val.len);
//
//		   			printf("issuer name:%s\n",name);
//		   			cname = cname->next;
//
//		   			}while(cname!=NULL);
//
//
//			cname = &srvcert.subject;
//
//			do{
//			memset(name,0,1024);
//			memcpy(name,cname->val.p,cname->val.len);
//
//			printf("subject name:%s\n",name);
//			cname = cname->next;
//
//			}while(cname!=NULL);
//
//
//
//			sn = &cCert->subject_alt_names;
//			do{
//				memset(name,0,1024);
//						   			memcpy(name,sn->buf.p,sn->buf.len);
//
//						   			printf("subject_alt name:%s\n",name);
//						   			sn = sn->next;
//			}while(sn != NULL);
//
//
//			memset(info,0,1024*1024);
//			jhd_tls_x509_crt_info(info,1024*1024,"\n==>",cCert);
//			printf(info);
//
//
//
//
//
//
//
//
//
//
//		       cCert = cCert->next;
//		}while(cCert != NULL);
//
//
//	}
//
//	jhd_tls_x509_crt_init(&srvcert);
//		if(0 ==jhd_tls_x509_crt_parse(&srvcert,test_cert2,sizeof(test_cert2))){
//
//			cCert = &srvcert;
//			do{
//			   printf("===================begin cert==============\n");
//
//			   cname = &srvcert.issuer;
//
//			   			do{
//			   			memset(name,0,1024);
//			   			memcpy(name,cname->val.p,cname->val.len);
//
//			   			printf("issuer name:%s\n",name);
//			   			cname = cname->next;
//
//			   			}while(cname!=NULL);
//
//
//				cname = &srvcert.subject;
//
//				do{
//				memset(name,0,1024);
//				memcpy(name,cname->val.p,cname->val.len);
//
//				printf("subject name:%s\n",name);
//				cname = cname->next;
//
//				}while(cname!=NULL);
//
//
//
//				memset(info,0,1024*1024);
//				jhd_tls_x509_crt_info(info,1024*1024,"\n==>",cCert);
//				printf(info);
//
//
//
//
//
//
//
//
//			       cCert = cCert->next;
//			}while(cCert != NULL);
//
//
//		}
//
//	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1");

//	unsigned char key[32];
//
//	unsigned char o_i[256],o_iv[16];
//	unsigned char input[256];
//	unsigned char output[256];
//	unsigned char output_asm[256],output_c[256];
//	unsigned char iv[16];
//
//	jhd_tls_aes_context enc,asm_enc,c_enc;
//	size_t len;
//
//	unsigned char rc;
//
//	int i,j,key_len;
//
//	for(i = 0 ; i < 1000; ++i){
//
//		jhd_tls_random(&rc,1);
//
//		if(rc < 85){
//			key_len = 128;
//		}else if(rc < 170){
//			key_len = 192;
//		}else{
//			key_len = 256;
//		}
//
//		printf("%d::::%d\n",i,key_len);
//
//		memset(&enc,0,sizeof(jhd_tls_aes_context));
//		memset(&asm_enc,0,sizeof(jhd_tls_aes_context));
//		memset(&c_enc,0,sizeof(jhd_tls_aes_context));
//
//		jhd_tls_aes_setkey_dec_auto(&enc,key,key_len);
//		jhd_tls_aes_setkey_dec_with_aesni(&asm_enc,key,key_len);
//		jhd_tls_aes_setkey_dec_without_aesni(&c_enc,key,key_len);
//
//		for(j=0;j < 10000;++j){
//			jhd_tls_random(o_iv,16);
//
//
//			len = ((j % 16)+1) * 16;
//
//			memcpy_16(iv,o_iv);
//
//			jhd_tls_random(o_i,256);
//			memcpy(input,o_i,256);
//			memcpy_16(iv,o_iv);
//			jhd_tls_aes_crypt_cbc(&enc,JHD_TLS_DECRYPT,len,iv,input,output);
//			memcpy(input,o_i,256);
//			memcpy_16(iv,o_iv);
//			jhd_tls_aes_cbc_decrypt_with_aesni(&asm_enc,len,iv,input,output_asm);
//			memcpy(input,o_i,256);
//			memcpy_16(iv,o_iv);
//			jhd_tls_aes_cbc_decrypt_without_aesni(&c_enc,len,iv,input,output_c);
//
//			if(j % 100 == 0){
//
////				log_test_buf("    INPUT=>",o_i,len);
////				log_test_buf("   OUTPUT=>",output,len);
////				log_test_buf("ASMOUTPUT=>",output_asm,len);
////				log_test_buf("C  OUTPUT=>",output_c,len);
//			}
//
//			if((memcmp(output,output_asm,len)!=0) ||  (memcmp(output,output_c,len)!=0)){
//
//				log_test_buf("    INPUT=>",input,len);
//				log_test_buf("   OUTPUT=>",output,len);
//				log_test_buf("ASMOUTPUT=>",output_asm,len);
//				log_test_buf("C  OUTPUT=>",output_c,len);
//				printf("=====================ERROR==============\n");
//				return 1;
//			}
//
//		}
//
//	}
return 0;

}

















void test_http_read_cmp(jhd_event_t *event);
ssize_t jhd_connection_error_recv(jhd_connection_t *c, u_char *buf, size_t size){
	log_err("%s","exec function");
	return JHD_ERROR;

}
ssize_t jhd_connection_error_send(jhd_connection_t *c, u_char *buf, size_t size){
	log_err("%s","exec function");
	return JHD_ERROR;
}


void jhd_connection_close(jhd_connection_t *c) {
	int op;
	struct epoll_event ee;
	jhd_queue_t *queue;
	log_notice("%s","==> jhd_connection_close");
	if(c->data){
		log_debug("jhd_tls_free_with_size(c->data,8192);");
		jhd_tls_free_with_size(c->data,sizeof(test_data_t));
		c->data = NULL;
	}

	if(c->ssl){
		jhd_tls_ssl_free(c->ssl);
		log_debug("jhd_tls_free_with_size(c->ssl,sizeof(jhd_tls_ssl_context));");
		jhd_tls_free_with_size(c->ssl,sizeof(jhd_tls_ssl_context));
		c->ssl = NULL;
	}
	queue = &c->read.queue;
	if(queue->next){
		jhd_queue_only_remove(queue);
	}
	queue = &c->write.queue;
	if(queue->next){
		jhd_queue_only_remove(queue);
	}

	if (c->fd != (-1)) {
		op = EPOLL_CTL_DEL;
		ee.events = 0;
		ee.data.ptr = NULL;
		epoll_ctl(epoll_fd, op, c->fd, &ee);
		close(c->fd);
		c->fd = -1;
	}
	log_debug("jhd_tls_free_with_size(c,sizeof(jhd_connection_t));");
	jhd_tls_free_with_size(c,sizeof(jhd_connection_t));
	log_notice("<== jhd_connection_close");
}











int open_listen(jhd_connection_t *lis) {
	int reuseaddr, reuseport;
	int err;
	reuseaddr = 1;
	reuseport = 1;


	struct sockaddr_in saddr;

	memset(&saddr,0,sizeof(struct sockaddr_in));

	saddr.sin_family = AF_INET;
	saddr.sin_addr.s_addr = htonl( INADDR_ANY);
	saddr.sin_port = htons(443);


	lis->fd = socket(saddr.sin_family, SOCK_STREAM, 0);
	if (lis->fd != -1) {
		if (setsockopt(lis->fd, SOL_SOCKET, SO_REUSEADDR, (const void *) &reuseaddr, sizeof(int)) == -1) {
			log_err("setsockopt(SO_REUSEADDR) failed with %s", "0.0.0.0");
			goto clean;
		}
		if (setsockopt(lis->fd, SOL_SOCKET, SO_REUSEPORT, (const void *) &reuseport, sizeof(int)) == -1) {
			log_err("setsockopt(SO_REUSEPORT) failed with %s", "0.0.0.0");
			goto clean;
		}
		reuseport = 1;

		if (ioctl(lis->fd, FIONBIO, &reuseport) == -1) {
			log_stderr("ioctl(FIONBIO) failed with %s", "0.0.0.0");
			goto clean;
		}

		if (bind(lis->fd, (const struct sockaddr*)&saddr, (socklen_t)(sizeof(struct sockaddr_in))) == -1) {
			err = errno;

			if (err == EADDRINUSE) {
				log_stderr("exec socket bind() failed  to exit  with %s", "0.0.0.0");
				goto clean;
			} else {
				log_err("exec socket bind() failed  to retry  with %s", "0.0.0.0");
				goto clean;
			}
		}

		if (listen(lis->fd, 511) == -1) {
			err = errno;
			if (err == EADDRINUSE) {
				log_stderr("exec socket listen(%d) failed  to exit  with %s", 511, "0.0.0.0");
				goto clean;
			}
			log_err("exec socket listen(%d) failed  to retry  with %s", 511, "0.0.0.0");
			goto clean;

		}
		return JHD_OK;

	}
	log_err("executor socket(%d,%d,%d) error", saddr.sin_family, SOCK_STREAM, 0);
	clean:
	if (lis->fd != -1) {
		close(lis->fd);
		lis->fd = -1;
	}
	return JHD_ERROR;
}


uint16_t  test_random_size(){
	unsigned char buf[2];
	jhd_tls_random(buf,2);
	return buf[0]<< 8 | buf[0];
}

void test_random_buf(u_char *p,size_t len){
	while(len >0){
		if(len > 1024){
		jhd_tls_random(p,1024);
		p+=1024;
		len -=1024;
		}else{
			jhd_tls_random(p,len);
			break;
		}

	}
}







void test_http_write_send_buffer(jhd_event_t *event){
	jhd_connection_t *c;
	ssize_t ret;
	size_t len;
	test_data_t *td;

	c= event->data;
	td = c->data;
	log_debug("==>test_http_write_send_buffer(send_buffer_len:%lu;send_buf_idx:%lu)",td->send_buffer_len,td->send_buf_idx);

	for(;;){
		len = td->send_buffer_len - td->send_buf_idx;
		log_debug("len(%ld) =  send_buffer_len(%lu) - send_buf_idx(%lu)",len,td->send_buffer_len,td->send_buf_idx);
		if(len > 8192){
			len = 8192;
		}
		ret = c->send(c,&td->send_buffer[td->send_buf_idx],len);
		log_debug("ret(%ld) = c->send(c,&send_buffer[send_buf_idx(%u)],len(%lu));",ret,td->send_buf_idx,len);
		if (ret > 0) {
			td->send_buf_idx +=ret;
			log_assert(td->send_buf_idx <= td->send_buffer_len);
			if(td->send_buf_idx ==td->send_buffer_len ){
				td->send_buf_idx = 0;
				c->read.handler = test_http_read_cmp;
				c->write.handler = jhd_connection_empty_write;
				jhd_post_event(&c->read,&jhd_posted_events);
				return;
			}
		}else if(ret !=JHD_AGAIN ) {
			log_err("!!!!send data(peer)");
			c->close(c);
			return;
		} else {
			log_debug("JHD_AGAIN waitting epoll write event");
			return;
		}
	}





//	while(c->in_buf_len>0){
//		ret = c->send(c,c->in_buf,c->in_buf_len);
//		if(ret>=0){
//			c->in_buf+=ret;
//			c->in_buf_len -= ret;
//		}else if(ret == JHD_AGAIN){
//			return;
//		}else{
//			break;
//		}
//
//	}
//	c->close(c);
}
void test_http_write_recv_buffer(jhd_event_t *event){
	jhd_connection_t *c;
	ssize_t ret,i;
	size_t len;
	test_data_t *td ;
	c = event->data;
	td = c->data;
	log_debug("==>test_http_write_recv_buffer(recv_buffer_len:%lu;recv_buf_idx:%lu)",td->recv_buffer_len,td->recv_buf_idx);
	for(;;){
		len = td->recv_buffer_len - td->recv_buf_idx;
		log_assert(len>0);
		log_debug("len(%lu) = recv_buffer_len(%lu) - recv_buf_idx(%lu)",len,td->recv_buffer_len,td->recv_buf_idx);
		if(len > 8192){
			len = 8192;
		}
		ret = c->send(c,&td->recv_buffer[td->recv_buf_idx],len);
		log_debug("ret(%ld) = c->send(c,&recv_buffer[recv_buf_idx(%lu)],len(%lu));",ret,td->recv_buf_idx,len);
		if(ret > 0){
			td->recv_buf_idx += ret;
			log_assert(td->recv_buf_idx<= td->recv_buffer_len);
			if(td->recv_buf_idx == td->recv_buffer_len){
				td->recv_buf_idx = td->recv_buffer_len = 0;
				td->send_buf_idx = 0;
				if(td->package_idx < 20000){
					td->send_buffer_len = td->package_idx + 2;
					td->send_buffer[0] = (unsigned char)(td->send_buffer_len >> 8);
					td->send_buffer[1] = (unsigned char)(td->send_buffer_len);
					for(i = 0;i < td->package_idx;++i){
						td->send_buffer[2 + i] = (unsigned char)i;
					}
					td->package_idx <<= 1;
				}else{
					td->send_buffer_len = test_random_size();
					if(td->send_buffer_len < 3){
						td->send_buffer_len = 3;
					}else if(td->send_buffer_len > 65530){
						td->send_buffer_len = 65530;
					}
					td->send_buffer[0] = (unsigned char)(td->send_buffer_len >> 8);
					td->send_buffer[1] = (unsigned char)(td->send_buffer_len);
					test_random_buf(&td->send_buffer[2],td->send_buffer_len - 2);
				}
				event->handler = test_http_write_send_buffer;
				jhd_post_event(event,&jhd_posted_events);
				return;
			}
		}else if(ret != JHD_AGAIN){
			log_err("!!!!!!!!send data(peer)");
			c->close(c);
			return;
		}else{
			log_debug("JHD_AGAIN waitting epoll write event");
			return;
		}


	}

}

char* res_header ="HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nContent-Length: %d\r\n\r\n%s";
char *res_data="uyjhmkl;fdsancvdiovncjeiopvjn";


void test_http_read_peer(jhd_event_t *event){
	jhd_connection_t *c;
	uint16_t len;
	ssize_t ret ;
	test_data_t *td;
	c = event->data;
	td= c->data;
	for(;;){
		ret = c->recv(c,&td->recv_buffer[td->recv_buffer_len],0XFFFF - td->recv_buffer_len);
		log_debug("ret(%ld) = c->recv(c,buf,len(%lu))",ret,0XFFFF - td->recv_buffer_len);
		if(ret>0){
			log_buf_info("ssl read==>",&td->recv_buffer[td->recv_buffer_len],ret);
			td->recv_buffer_len+=ret;
		}else if(ret != JHD_AGAIN){
			log_err("!!!!!!! c->recv(...)  error");
			c->close(c);
			return;
		}else{
			if(td->recv_buffer_len>1){
				len = (((unsigned char)td->recv_buffer[0])<<8)|((unsigned char)td->recv_buffer[1]);
				if(len == td->recv_buffer_len){
					c->read.handler= jhd_connection_empty_read;
					c->write.handler = test_http_write_recv_buffer;
					jhd_post_event(&c->write,&jhd_posted_events);
				}else if(len < td->recv_buffer_len){
					log_err("!!!!!!!!!!!!invald recv data(peer) len < recv_buffer_len");
					c->close(c);
				}
			}
			return;
		}
	}
}
void test_http_read_cmp(jhd_event_t *event){
	jhd_connection_t *c;
	uint16_t len;
	ssize_t ret ;
	u_char buf[8192];
	test_data_t *td;
	c = event->data;
	td = c->data;
	for(;;){
		len = td->send_buffer_len - td->send_buf_idx;
		log_assert(len>0);
		if(len > 8192){
			len = 8192;
		}
		ret = c->recv(c,buf,len);
		log_debug("ret(%ld) = c->recv(c,buf,len(%lu))",ret,len);
		if(ret>0){
			if(memcmp(buf,&td->send_buffer[td->send_buf_idx],ret)==0){
				td->send_buf_idx +=ret;
				if(td->send_buf_idx == td->send_buffer_len){
					log_notice("====================================recv data(self) success");
					event->handler = test_http_read_peer;
					td->recv_buffer_len = 0;
					td->recv_buf_idx = 0;
					jhd_post_event(event,&jhd_posted_events);
					return;
				}
			}else{
				log_err("!!!!!!!!!!!!invald recv data(self) memcmp(............)");
				c->close(c);
				return;
			}
		}else if(ret != JHD_AGAIN){
			log_err("!!!!!!! c->recv(...)  error");
			c->close(c);
			return;
		}else{
			return;
		}
	}
}


void jhd_http_init_connection(jhd_connection_t* c){
	jhd_tls_ssl_context *ssl;
	int ret;
	struct epoll_event ee;



	c->data = jhd_tls_alloc(sizeof(test_data_t));
	if(c->data == NULL){
		goto exit;
	}
	memset(c->data ,0,sizeof(test_data_t));

	((test_data_t*)c->data)->package_idx = 1;


	ssl = jhd_tls_malloc(sizeof(jhd_tls_ssl_context));
	if(ssl){
		c->ssl = ssl;
		jhd_tls_ssl_init(ssl);
		if ((ret = jhd_tls_ssl_setup(ssl, &conf)) != 0) {
			log_err(" failed\n  ! jhd_tls_ssl_setup returned %d\n\n", ret);
			goto exit;
		}
		c->recv = jhd_tls_ssl_recv;
		c->send = jhd_tls_ssl_send;

		c->read.data = c;
		c->read.handler = test_http_read_peer;

		c->write.data = c;
		c->write.handler = jhd_tls_ssl_noop_write;
		ee.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;
		ee.data.ptr = c;

		if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, c->fd, &ee) == -1) {
				goto exit;
	    }
		test_http_read_peer(&c->read);
		return;
	}
	log_err("%s","memeryout");
	return;
	exit:
	c->close(c);
}
void jhd_tls_accept(jhd_event_t *ev){
	jhd_connection_t *c, *sc;
	int fd;
	int err;
	int nb;
	jhd_sockaddr_t saddr;
	socklen_t  saddr_len;
	log_notice("%s", "enter function");

	c = NULL;
	sc = ev->data;
	c = jhd_tls_alloc(sizeof(jhd_connection_t));
	if(c==NULL){
		log_err("%s","memeryout");
		return;
	}
	memset(c,0,sizeof(jhd_connection_t));
	log_info("begin connection acccept[%s]", "0.0.0.0");
	for (;;) {
		saddr_len = sizeof(jhd_sockaddr_t);
		fd = accept(sc->fd,(struct sockaddr*)&saddr, &saddr_len);
		log_debug("exec accept(...)==%d", fd);
		if (fd == (-1)) {
			err = errno;
			if ((err == EAGAIN)) {
				jhd_tls_free(c);
				log_notice("leave function return with:%s", "accept(...) ==-1,errno = EAGAIN");
				return;
			}
			jhd_tls_free_with_size(c,sizeof(jhd_connection_t));
			log_err("connection acccept[%s] error with:%s", "0.0.0.0", "accept(...)");
			log_notice("leave function return with:%s", "accept(...)==-1,errno != EAGAIN ");
			return;
		}
		nb = 1;
		err = ioctl(fd, FIONBIO, &nb);
		log_debug("exec ioctl(,FIONBIO,)==%d", err);
		if (err == (-1)) {
			jhd_tls_free(c);
			close(fd);
			log_err("connection acccept[%s] error with:%s", "0.0.0.0", "ioctl(,FIONBIO,)== -1");
			log_notice("leave function return with:%s", "ioctl(,FIONBIO,)== -1");
			return;
		}
		c->fd = fd;
		c->close = jhd_connection_close;
		jhd_http_init_connection(c);
		c = jhd_tls_alloc(sizeof(jhd_connection_t));
		if(c==NULL){
			log_err("%s","memeryout");
			return;
		}
		memset(c,0,sizeof(jhd_connection_t));
	}
}

void jhd_tls_listen_write_event_handler(jhd_event_t *ev){
	(void)ev;
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!listen socket write event trigger");
}


void out_key_val(char *key,ssize_t val){
	printf("%s:%ld\n",key,val);
}
void out_buf(char *buf,char *buf2,size_t len){
	size_t i;
	unsigned char c;
	for(i = 0; i < len;++i){
		c = (unsigned char)buf[i];
		printf("%02X\n",c);
		fflush(stdout);
	}
	printf("\n");
	for(i = 0; i < len;++i){
		c = (unsigned char)buf2[i];
		printf("%2X",c);
		fflush(stdout);
	}
	printf("\n");

	for(i = 0; i < len;++i){
		if(buf[i] != buf2[i]){
		printf("====>not equals=============>%ld\n",i);
		}
	}
}

#define TEST_CHECK(X) if(0!=(X)) goto func_error



//int test3(){
//
//	jhd_tls_mpi A,B,N,T;
//	jhd_tls_mpi_uint mm=(jhd_tls_mpi_uint)-2141433787177571819L;
//
//	jhd_tls_mpi_init(&A);
//	jhd_tls_mpi_init(&B);
//	jhd_tls_mpi_init(&N);
//	jhd_tls_mpi_init(&T);
//
//    jhd_tls_mpi_read_string(&A,10,"120958777529812435066682181271950982839891543542706125858549033637814510949008261859276046293044821703857725295759822056433301956761176710383916578420973253987968080496968125853625607389966940027870658235983239540765244865074958498976841099274015493854701681451268016871085213193989927184122748810362641516335");
//    jhd_tls_mpi_read_string(&B,10,"108201847428156625452322322331874412325946905876133160511479328669289204690413861073310116743463015777761826025086457501320181839215507139914633044738746187540890311984002650558129216385939474077127483405123958710002078346580305932795296425055786418484106448593450468750779038476647729113468636539123256222034");
//    jhd_tls_mpi_read_string(&N,10,"156757692638130802430136797792284968060572687832619973953701297464074538694655738281590288038026751595603499494650931774202019658259194952135536606599190110038183020235170443420471708201926044865668765857604218431265483476810931429768755137914424955941950299925094688018764063334862923702550991293813200218819");
//    jhd_tls_mpi_grow(&T,N.n+1);
//    mpi_montmul(&A,&B,&N,mm,&T);
//    log_mpi("A:",&A);
//
//	return 1;
//
//}

int test2(){


    return 1;
}

//int main(void){
//	int ret;
//	jhd_tls_x509_crt srvcert;
//	jhd_tls_pk_context pkey;
//
//
//	jhd_tls_config_init();
//
//	jhd_tls_x509_crt_init(&srvcert);
//
//	jhd_tls_pk_init(&pkey);
//	//ret =  jhd_tls_x509_crt_parse(&srvcert, (const unsigned char *) jhd_tls_test_srv_crt, jhd_tls_test_srv_crt_len);
//
////	ret = jhd_tls_x509_crt_parse(&srvcert, (const unsigned char *) jhd_tls_test_srv_crt_ec, jhd_tls_test_srv_crt_ec_len);
//
////	ret = jhd_tls_pk_parse_key(&pkey, (const unsigned char *) jhd_tls_test_srv_key, jhd_tls_test_srv_key_len, NULL, 0);
//
//	ret = jhd_tls_pk_parse_key(&pkey, (const unsigned char *) jhd_tls_test_srv_key_ec, jhd_tls_test_srv_key_ec_len, NULL, 0);
//	log_notice("ret = %d",ret);
//	return ret;
//
//}

int main(void) {
	int ret;
	struct epoll_event ee;
	jhd_connection_t listen;
	jhd_tls_x509_crt srvcert;
	jhd_tls_pk_context pkey;
	jhd_tls_x509_crt ec_srvcert;
	jhd_tls_pk_context ec_pkey;

	jhd_update_time();
	jhd_tls_config_init();

	if(run_test_flag!=0){
		test();
		return 0;
	}



	jhd_tls_platform_zeroize(&listen, sizeof(jhd_connection_t));


	jhd_tls_ssl_config_init(&conf);
	jhd_tls_x509_crt_init(&srvcert);
	jhd_tls_pk_init(&pkey);

	jhd_tls_x509_crt_init(&ec_srvcert);
	jhd_tls_pk_init(&ec_pkey);

	epoll_fd = -1;
	listen.fd = -1;
	event_list = NULL;






	ret = jhd_tls_x509_crt_parse(&srvcert, (const unsigned char *) jhd_tls_test_srv_crt, jhd_tls_test_srv_crt_len);
	if (ret != 0) {
		log_err("%s","Loading the server(RSA) cert  fail");
		goto exit;
	}
	log_debug("%s","Loading the server cert(RSA)  success");

	ret = jhd_tls_pk_parse_key(&pkey, (const unsigned char *) jhd_tls_test_srv_key, jhd_tls_test_srv_key_len, NULL, 0);
	if (ret != 0) {
		log_err("%s","Loading the server key(RSA)  fail", ret);
		goto exit;
	}


	ret = jhd_tls_x509_crt_parse(&ec_srvcert, (const unsigned char *) jhd_tls_test_srv_crt_ec, jhd_tls_test_srv_crt_ec_len);
	if (ret != 0) {
		log_err("%s","Loading the server cert(ECDSA)  fail");
		goto exit;
	}
	log_debug("%s","Loading the server cert(ECDSA)  success");
	ret = jhd_tls_pk_parse_key(&ec_pkey, (const unsigned char *) jhd_tls_test_srv_key_ec, jhd_tls_test_srv_key_ec_len, NULL, 0);
	if (ret != 0) {
		log_err("%s","Loading the server key(ECDSA)  fail", ret);
		goto exit;
	}


	if ((ret = jhd_tls_ssl_config_defaults(&conf, JHD_TLS_SSL_IS_SERVER)) != 0) {
		log_err("jhd_tls_ssl_config_defaults returned %d", ret);
		goto exit;
	}

	if ((ret = jhd_tls_ssl_conf_own_cert(&conf, &srvcert, &pkey)) != 0) {
		log_err("jhd_tls_ssl_conf_own_cert(RSA) returned %d", ret);
		goto exit;
	}

	if ((ret = jhd_tls_ssl_conf_own_cert(&conf, &ec_srvcert, &ec_pkey)) != 0) {
		log_err("jhd_tls_ssl_conf_own_cert(ECDSA) returned %d", ret);
		goto exit;
	}

	if(jhd_event_init()!=0){
		log_err("jhd_event_init() == JHD_ERROR", ret);
		goto exit;
	}

	listen.read.data= &listen;
	listen.read.handler = jhd_tls_accept;
	listen.write.data= &listen;
	listen.write.handler = jhd_tls_listen_write_event_handler;


	if(open_listen(&listen)!=0){
		log_err("open_listen() == JHD_ERROR", ret);
		goto exit;
	}


	ee.events = EPOLLIN | EPOLLRDHUP;
	ee.data.ptr = &listen;
	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen.fd, &ee) == -1) {
		log_err("epoll_ctl( ADD LISTEN SOCKET) == JHD_ERROR", ret);
		goto exit;
	}
	while(1){
		jhd_process_events_and_timers();

	}



exit:
	if(event_list!=NULL){
		jhd_tls_free(event_list);
	}
	if(epoll_fd!= -1){
		close(epoll_fd);
	}
	jhd_tls_x509_crt_free(&srvcert);
	if(pkey.pk_ctx){
		jhd_tls_free_with_size(pkey.pk_ctx,pkey.pk_info->ctx_size);
	}

	jhd_tls_ssl_config_free(&conf);

//	main2();

	return (ret);
}

ssize_t jhd_connection_recv(jhd_connection_t *c, u_char *buf, size_t size){
return 0;
}



ssize_t jhd_connection_ssl_send(jhd_connection_t *c, u_char *buf, size_t size){
	return 0;
}
//
//int main2(void) {
//	int ret, len;
//	jhd_tls_net_context server_fd;
//
//	unsigned char buf[1024];
//	jhd_tls_ssl_context ssl;
//	jhd_tls_ssl_config conf;
//	jhd_tls_x509_crt cacert;
//
//	/*
//	 * 0. Initialize the RNG and the session data
//	 */
//	jhd_tls_net_init(&server_fd);
//	jhd_tls_ssl_init(&ssl);
//	jhd_tls_ssl_config_init(&conf);
//	jhd_tls_x509_crt_init(&cacert);
//
//	jhd_tls_printf("\n  . Seeding the random number generator...");
//	fflush( stdout);
//
//	jhd_tls_printf(" ok\n");
//
//	/*
//	 * 0. Initialize certificates
//	 */
//	jhd_tls_printf("  . Loading the CA root certificate ...");
//	fflush( stdout);
//
//	ret = jhd_tls_x509_crt_parse(&cacert, (const unsigned char *) jhd_tls_test_cas_pem, jhd_tls_test_cas_pem_len);
//	if (ret < 0) {
//		jhd_tls_printf(" failed\n  !  jhd_tls_x509_crt_parse returned -0x%x\n\n", -ret);
//		goto exit;
//	}
//
//	jhd_tls_printf(" ok (%d skipped)\n", ret);
//
//	/*
//	 * 1. Start the connection
//	 */
//	fflush( stdout);
//
//	if ((ret = jhd_tls_net_connect(&server_fd, "localhost", "4433", 1)) != 0) {
//		jhd_tls_printf(" failed\n  ! jhd_tls_net_connect returned %d\n\n", ret);
//		goto exit;
//	}
//
//	jhd_tls_printf(" ok\n");
//
//	/*
//	 * 2. Setup stuff
//	 */
//	jhd_tls_printf("  . Setting up the SSL/TLS structure...");
//	fflush( stdout);
//
//	if ((ret = jhd_tls_ssl_config_defaults(&conf, jhd_tls_false)) != 0) {
//		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_config_defaults returned %d\n\n", ret);
//		goto exit;
//	}
//
//	jhd_tls_printf(" ok\n");
//
//	if ((ret = jhd_tls_ssl_setup(&ssl, &conf)) != 0) {
//		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_setup returned %d\n\n", ret);
//		goto exit;
//	}
//
//	if ((ret = jhd_tls_ssl_set_hostname(&ssl, "localhost")) != 0) {
//		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_set_hostname returned %d\n\n", ret);
//		goto exit;
//	}
//
//	jhd_tls_ssl_set_bio(&ssl, &server_fd, jhd_tls_net_send, jhd_tls_net_recv, NULL);
//
//	/*
//	 * 4. Handshake
//	 */
//	jhd_tls_printf("  . Performing the SSL/TLS handshake...");
//	fflush( stdout);
//
//	while ((ret = jhd_tls_ssl_handshake(&ssl)) != 0) {
//		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
//			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_handshake returned -0x%x\n\n", -ret);
//			goto exit;
//		}
//	}
//
//	jhd_tls_printf(" ok\n");
//
//	/*
//	 * 5. Verify the server certificate
//	 */
//	jhd_tls_printf("  . Verifying peer X.509 certificate...");
//
//	/*
//	 * 3. Write the GET request
//	 */
//	jhd_tls_printf("  > Write to server:");
//	fflush( stdout);
//
//	len = sprintf((char *) buf, "GET / HTTP/1.1\r\n\r\n");
//
//	while ((ret = jhd_tls_ssl_write(&ssl, buf, len)) <= 0) {
//		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
//			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_write returned %d\n\n", ret);
//			goto exit;
//		}
//	}
//
//	len = ret;
//	jhd_tls_printf(" %d bytes written\n\n%s", len, (char *) buf);
//
//	/*
//	 * 7. Read the HTTP response
//	 */
//	jhd_tls_printf("  < Read from server:");
//	fflush( stdout);
//
//	do {
//		len = sizeof(buf) - 1;
//		memset(buf, 0, sizeof(buf));
//		ret = jhd_tls_ssl_read(&ssl, buf, len);
//
//		if (ret == JHD_TLS_ERR_SSL_WANT_READ || ret == JHD_TLS_ERR_SSL_WANT_WRITE)
//			continue;
//
//		if (ret == JHD_TLS_ERR_SSL_PEER_CLOSE_NOTIFY)
//			break;
//
//		if (ret < 0) {
//			jhd_tls_printf("failed\n  ! jhd_tls_ssl_read returned %d\n\n", ret);
//			break;
//		}
//
//		if (ret == 0) {
//			jhd_tls_printf("\n\nEOF\n\n");
//			break;
//		}
//
//		len = ret;
//		jhd_tls_printf(" %d bytes read\n\n%s", len, (char *) buf);
//	} while (1);
//
//	jhd_tls_ssl_close_notify(&ssl);
//
//	exit:
//
//	if(event_list){
//		jhd_tls_free(event_list);
//		event_list = NULL;
//	}
//	if(listen.fd !=-1){
//
//		close(listen.fd);
//		listen.fd = -1;
//	}
//
//	if(epoll_fd != -1){
//		close(epoll_fd);
//		epoll_fd = -1;
//
//	}
//
//
//	jhd_tls_x509_crt_free(&cacert);
//	jhd_tls_ssl_free(&ssl);
//	jhd_tls_ssl_config_free(&conf);
//
//	return (ret);
//}

