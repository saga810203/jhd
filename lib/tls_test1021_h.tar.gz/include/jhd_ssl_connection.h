/*
 * jhd_ssl_connection.h
 *
 *  Created on: Aug 27, 2018
 *      Author: root
 */

#ifndef INCLUDE_JHD_SSL_CONNECTION_H_
#define INCLUDE_JHD_SSL_CONNECTION_H_

#include <jhd_event.h>
#include <jhd_connection.h>

#define jhd_connection_empty_write jhd_tls_ssl_noop_write

ssize_t jhd_tls_ssl_recv(jhd_connection_t *c, u_char *buf, size_t size);
ssize_t jhd_tls_ssl_send(jhd_connection_t *c, u_char *buf, size_t size);

int  jhd_tls_ssl_handshark(jhd_connection_t *c);


void jhd_tls_ssl_noop_write(jhd_event_t * ev);


void jhd_connection_empty_read(jhd_event_t *ev);


#endif /* INCLUDE_JHD_SSL_CONNECTION_H_ */
