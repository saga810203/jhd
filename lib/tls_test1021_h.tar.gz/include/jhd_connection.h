/*
 * jhd_connection.h
 *
 *  Created on: May 25, 2018
 *      Author: root
 */

#ifndef JHD_CONNECTION_H_
#define JHD_CONNECTION_H_
#include <jhd_event.h>

typedef struct jhd_connection_s jhd_connection_t;


typedef ssize_t (*jhd_connection_recv_pt)(jhd_connection_t *c, u_char *buf, size_t size);

typedef ssize_t (*jhd_connection_send_pt)(jhd_connection_t *c, u_char *buf, size_t size);
typedef void (*jhd_connection_close_pt)(jhd_connection_t *c);





struct jhd_connection_s {
	void *data;
	int fd;
	jhd_connection_recv_pt recv;
	jhd_connection_send_pt send;
	jhd_connection_close_pt close;
	jhd_event_t read;
	jhd_event_t write;
    uint16_t  in_buf_len;
    u_char *in_buf;

	void *ssl;
};

ssize_t jhd_connection_recv(jhd_connection_t *c, u_char *buf, size_t size);

ssize_t jhd_connection_ssl_recv(jhd_connection_t *c, u_char *buf, size_t size);

ssize_t jhd_connection_send(jhd_connection_t *c, u_char *buf, size_t size);

ssize_t jhd_connection_ssl_send(jhd_connection_t *c, u_char *buf, size_t size);
ssize_t jhd_connection_error_recv(jhd_connection_t *c, u_char *buf, size_t size);
ssize_t jhd_connection_error_send(jhd_connection_t *c, u_char *buf, size_t size);
void jhd_connection_close(jhd_connection_t *c);


#endif /* JHD_CONNECTION_H_ */
