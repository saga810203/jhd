#include <tls/jhd_tls_config.h>
  unsigned char* 		jhd_cache_log_time;
   unsigned char* 		jhd_cache_http_date;
  uint64_t      	jhd_current_msec;
  time_t			jhd_cache_time;
  pid_t jhd_pid;

  static char *jhd_log_level_enum[] = { "STDERR", " EMERG", " ALERT", "  CRIT", "   ERR", "  WARN", "NOTICE", "  INFO", " DEBUG", };

  void _log_out(u_char* file_name, u_char *func_name, int line, uint16_t level, const u_char* fmt, ...) {
  	va_list args;
  	u_char *p;
  	u_char errstr[JHD_MAX_ERROR_STR];
  	size_t len, slen;
  	len = JHD_MAX_ERROR_STR;
  	slen = snprintf("%s %s file:%s function:%s line:%6d\n", jhd_cache_log_time, jhd_log_level_enum[level], file_name, func_name, line);
  	va_start(args, fmt);
  	len = snprintf(&errstr[slen], JHD_MAX_ERROR_STR - slen, fmt, args);
  	va_end(args);
  	len += slen;
  	if (len >= JHD_MAX_ERROR_STR) {
  		len = JHD_MAX_ERROR_STR - 1;
  		errstr[JHD_MAX_ERROR_STR - 1] = '\0';
  	}
  	printf(errstr);
  }
  void _jhd_assert(u_char* file_name,u_char *func_name,int line,int assert_value,const u_char* msg){
	  if(!assert_value){
		  printf("!!!!!!!!!!!!!!! ====> exit at: file:%s,function:%s,line:%d; reason:%s\r\n",file_name,func_name,line,msg);
		  exit(1);
	  }
  }
  ssize_t jhd_connection_recv(jhd_connection_t *c, u_char *buf, size_t size){

  }

  ssize_t jhd_connection_ssl_recv(jhd_connection_t *c, u_char *buf, size_t size){

  }

  ssize_t jhd_connection_send(jhd_connection_t *c, u_char *buf, size_t size){

  }

  ssize_t jhd_connection_ssl_send(jhd_connection_t *c, u_char *buf, size_t size){

  }
