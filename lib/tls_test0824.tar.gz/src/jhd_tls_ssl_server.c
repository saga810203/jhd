#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_platform.h>
#include <jhd_connection.h>
#include <sys/ioctl.h>

#include <stdlib.h>
#include <string.h>

#include <tls/jhd_tls_entropy.h>
#include <tls/jhd_tls_ctr_drbg.h>
#include <tls/jhd_tls_certs.h>
#include <tls/jhd_tls_x509.h>
#include <tls/jhd_tls_ssl_internal.h>
#include <tls/jhd_tls_net_sockets.h>
#include <tls/jhd_tls_error.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <sys/epoll.h>
#include <jhd_event.h>

#define HTTP_RESPONSE \
    "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n" \
    "<h2>mbed TLS Test Server</h2>\r\n" \
    "<p>Successful connection using: %s</p>\r\n"

#define DEBUG_LEVEL 0



typedef union {
	struct sockaddr sockaddr;
	struct sockaddr_in sockaddr_in;

	struct sockaddr_in6 sockaddr_in6;
	struct sockaddr_un sockaddr_un;
} jhd_sockaddr_t;

jhd_tls_ssl_config conf;

int main2(void);


void jhd_connection_close(jhd_connection_t *c) {
	int op;
	struct epoll_event ee;

	if (c->fd != (-1)) {
		op = EPOLL_CTL_DEL;
		ee.events = 0;
		ee.data.ptr = NULL;
		epoll_ctl(epoll_fd, op, c->fd, &ee);
		close(c->fd);
		c->fd = -1;
	}
	log_notice("%s", "exec function");
}











int open_listen(jhd_connection_t *listen) {
	int reuseaddr, reuseport;
	int err;
	reuseaddr = 1;
	reuseport = 1;

	struct sockaddr_in saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_addr = htonl(INADDR_ANY);
	saddr.sin_port = 443;
	listen->fd = socket(saddr->sin_family, SOCK_STREAM, 0);
	if (listen->fd != -1) {
		if (setsockopt(listen->fd, SOL_SOCKET, SO_REUSEADDR, (const void *) &reuseaddr, sizeof(int)) == -1) {
			log_err("setsockopt(SO_REUSEADDR) failed with %s", "0.0.0.0");
			goto clean;
		}
		if (setsockopt(listen->fd, SOL_SOCKET, SO_REUSEPORT, (const void *) &reuseport, sizeof(int)) == -1) {
			log_err("setsockopt(SO_REUSEPORT) failed with %s", "0.0.0.0");
			goto clean;
		}
		reuseport = 1;

		if (ioctl(listen->fd, FIONBIO, &reuseport) == -1) {
			log_stderr("ioctl(FIONBIO) failed with %s", "0.0.0.0");
			goto clean;
		}

		if (bind(listen->fd, saddr, sizeof(struct sockaddr_in)) == -1) {
			err = errno;

			if (err == EADDRINUSE) {
				log_stderr("exec socket bind() failed  to exit  with %s", "0.0.0.0");
				goto clean;
			} else {
				log_err("exec socket bind() failed  to retry  with %s", "0.0.0.0");
				goto clean;
			}
		}

		if (listen(listen->fd, 511) == -1) {
			err = errno;
			if (err == EADDRINUSE) {
				log_stderr("exec socket listen(%d) failed  to exit  with %s", 511, "0.0.0.0");
				goto clean;
			}
			log_err("exec socket listen(%d) failed  to retry  with %s", 511, "0.0.0.0");
			goto clean;

		}
		return JHD_TLS_OK;

	}
	log_err("executor socket(%d,%d,%d) error", saddr->sin_family, SOCK_STREAM, 0);
	clean: if (listen->fd != -1) {
		close(listen->fd);
		listen->fd = -1;
	}
	return JHD_TLS_ERROR;
}

void jhd_http_init_connection(jhd_connection_t* c){
	jhd_tls_ssl_context *ssl;
	int ret;


	ssl = jhd_tls_malloc(sizeof(jhd_tls_ssl_context));
	if(ssl){
		jhd_tls_ssl_init(&ssl);
		if ((ret = jhd_tls_ssl_setup(&ssl, &conf)) != 0) {
			log_err(" failed\n  ! jhd_tls_ssl_setup returned %d\n\n", ret);
			goto exit;
		}




	}
	log_err("%s","memeryout");
	exit:
	c->close(c);
}
void jhd_tls_accept(jhd_event_t *ev){
	static int use_accept4 = 1;
	jhd_connection_t *c, *sc;
	int fd;
	int err;
	size_t idx;
	int nb;
	jhd_sockaddr_t saddr;
	int saddr_len;


	log_notice("%s", "enter function");
	c = NULL;


	sc = ev->data;
	c = jhd_tls_malloc(sizeof(jhd_connection_t));
	if(c==NULL){
		log_err("%s","memeryout");
		return;
	}

	log_info("begin connection acccept[%s]", "0.0.0.0");

	for (;;) {
		saddr_len = sizeof(jhd_sockaddr_t);
		if (use_accept4) {
			fd = accept4(sc->fd, &saddr, &saddr_len, SOCK_NONBLOCK);
			log_debug("exec accept4(...)==%d", fd);
		} else {
			fd = accept(sc->fd, &saddr, &saddr_len);
			log_debug("exec accept(...)==%d", fd);
		}

		if (fd == (-1)) {
			err = errno;
			if ((err == EAGAIN)) {
				jhd_tls_free(c);
				log_notice("leave function return with:%s", "accept(...) ==-1,errno = EAGAIN");
				return;
			}
			if (use_accept4 && err == ENOSYS) {
				use_accept4 = 0;
				log_warn("exec accept4(...)==-1,errno == ENOSYS so:%s", "change use_accept4[static] = 0");
				continue;
			}
			jhd_tls_free(c);
			log_err("connection acccept[%s] error with:%s", "0.0.0.0", "accept(...)");
			log_notice("leave function return with:%s", "accept(...)==-1,errno != EAGAIN ");
			return;
		}
		nb = 1;
		err = ioctl(fd, FIONBIO, &nb);
		log_debug("exec ioctl(,FIONBIO,)==%d", err);

		if (err == (-1)) {
			jhd_tls_free(c);
			close(fd);
			log_err("connection acccept[%s] error with:%s", "0.0.0.0", "ioctl(,FIONBIO,)== -1");
			log_notice("leave function return with:%s", "ioctl(,FIONBIO,)== -1");
			return;
		}
		c->fd = fd;
		c->close = jhd_connection_close;
		jhd_http_init_connection(c);
	}
}

void jhd_tls_listen_write_event_handler(jhd_event_t *ev){
	(void)ev;
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!listen socket write event trigger")
}


int main(void) {
	int ret, len;
	struct epoll_event ee;
	jhd_connection_t listen;
	unsigned char buf[1024];


	jhd_tls_x509_crt srvcert;
	jhd_tls_pk_context pkey;

	jhd_tls_platform_zeroize(&listen, sizeof(jhd_connection_t));
//	jhd_tls_platform_zeroize(&client, sizeof(jhd_connection_t));

	jhd_tls_ssl_config_init(&conf);
	jhd_tls_x509_crt_init(&srvcert);
	jhd_tls_pk_init(&pkey);
	epoll_fd = -1;

	listen.fd = -1;
	event_list = NULL;

	/*
	 * 1. Load the certificates and private RSA key
	 */
	jhd_tls_printf("\n  . Loading the server cert. and key...");
	fflush( stdout);

	/*
	 * This demonstration program uses embedded test certificates.
	 * Instead, you may want to use jhd_tls_x509_crt_parse_file() to read the
	 * server and CA certificates, as well as jhd_tls_pk_parse_keyfile().
	 */
	ret = jhd_tls_x509_crt_parse(&srvcert, (const unsigned char *) jhd_tls_test_srv_crt, jhd_tls_test_srv_crt_len);
	if (ret != 0) {
		jhd_tls_printf(" failed\n  !  jhd_tls_x509_crt_parse returned %d\n\n", ret);
		goto exit;
	}

	ret = jhd_tls_x509_crt_parse(&srvcert, (const unsigned char *) jhd_tls_test_cas_pem, jhd_tls_test_cas_pem_len);
	if (ret != 0) {
		jhd_tls_printf(" failed\n  !  jhd_tls_x509_crt_parse returned %d\n\n", ret);
		goto exit;
	}

	ret = jhd_tls_pk_parse_key(&pkey, (const unsigned char *) jhd_tls_test_srv_key, jhd_tls_test_srv_key_len, NULL, 0);
	if (ret != 0) {
		jhd_tls_printf(" failed\n  !  jhd_tls_pk_parse_key returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_printf(" ok\n");

	if ((ret = jhd_tls_ssl_config_defaults(&conf, JHD_TLS_SSL_IS_SERVER)) != 0) {
		log_err(" failed\n  ! jhd_tls_ssl_config_defaults returned %d\n\n", ret);
		goto exit;
	}

	if ((ret = jhd_tls_ssl_conf_own_cert(&conf, &srvcert, &pkey)) != 0) {
		log_err(" failed\n  ! jhd_tls_ssl_conf_own_cert returned %d\n\n", ret);
		goto exit;
	}


	if(jhd_event_init()!=0){
		goto exit;
	}

	listen.read.data= &listen;
	listen.read.handler = jhd_tls_accept;
	listen.write.data= &listen;
	listen.write.handler = jhd_tls_listen_write_event_handler;


	if(open_listen()!=0){
		goto exit;
	}


	ee.events = EPOLLIN | EPOLLRDHUP;
	ee.data.ptr = &listen;
	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen.fd, &ee) == -1) {
		log_err("execute epoll_ctl error,reason:%s","add listen socket");
		goto exit;
	}
	while(1){
		jhd_process_events_and_timers();

	}















	jhd_tls_printf("  . Bind on https://localhost:4433/ ...");
	fflush( stdout);

	if ((ret = jhd_tls_net_bind(&listen_fd, NULL, "4433", JHD_TLS_NET_PROTO_TCP)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_net_bind returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_printf(" ok\n");

	/*
	 * 3. Seed the RNG
	 */
	jhd_tls_printf("  . Seeding the random number generator...");
	fflush( stdout);

	jhd_tls_printf(" ok\n");

	/*
	 * 4. Setup stuff
	 */
	jhd_tls_printf("  . Setting up the SSL data....");
	fflush( stdout);

	if ((ret = jhd_tls_ssl_config_defaults(&conf, JHD_TLS_SSL_IS_SERVER)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_config_defaults returned %d\n\n", ret);
		goto exit;
	}

//	jhd_tls_ssl_conf_ca_chain(&conf, srvcert.next, NULL);
	if ((ret = jhd_tls_ssl_conf_own_cert(&conf, &srvcert, &pkey)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_conf_own_cert returned %d\n\n", ret);
		goto exit;
	}

	if ((ret = jhd_tls_ssl_setup(&ssl, &conf)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_setup returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_printf(" ok\n");

	reset:

	if (ctx->fd == -1)
		return;

	shutdown(ctx->fd, 2);
	close(ctx->fd);

	ctx->fd = -1;

//	jhd_tls_ssl_session_reset(&ssl);

	/*
	 * 3. Wait until a client connects
	 */
	jhd_tls_printf("  . Waiting for a remote connection ...");
	fflush( stdout);

	if ((ret = jhd_tls_net_accept(&listen_fd, &client_fd,
	NULL, 0, NULL)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_net_accept returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_ssl_set_bio(&ssl, &client_fd, jhd_tls_net_send, jhd_tls_net_recv, NULL);

	jhd_tls_printf(" ok\n");

	/*
	 * 5. Handshake
	 */
	jhd_tls_printf("  . Performing the SSL/TLS handshake...");
	fflush( stdout);

	while ((ret = jhd_tls_ssl_handshake(&ssl)) != 0) {
		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_handshake returned %d\n\n", ret);
			goto reset;
		}
	}

	jhd_tls_printf(" ok\n");

	/*
	 * 6. Read the HTTP Request
	 */
	jhd_tls_printf("  < Read from client:");
	fflush( stdout);

	do {
		len = sizeof(buf) - 1;
		memset(buf, 0, sizeof(buf));
		ret = jhd_tls_ssl_read(&ssl, buf, len);

		if (ret == JHD_TLS_ERR_SSL_WANT_READ || ret == JHD_TLS_ERR_SSL_WANT_WRITE)
			continue;

		if (ret <= 0) {
			switch (ret) {
				case JHD_TLS_ERR_SSL_PEER_CLOSE_NOTIFY:
					jhd_tls_printf(" connection was closed gracefully\n");
					break;

				case JHD_TLS_ERR_NET_CONN_RESET:
					jhd_tls_printf(" connection was reset by peer\n");
					break;

				default:
					jhd_tls_printf(" jhd_tls_ssl_read returned -0x%x\n", -ret);
					break;
			}

			break;
		}

		len = ret;
		jhd_tls_printf(" %d bytes read\n\n%s", len, (char *) buf);

		if (ret > 0)
			break;
	} while (1);

	/*
	 * 7. Write the 200 Response
	 */
	jhd_tls_printf("  > Write to client:");
	fflush( stdout);

	len = sprintf((char *) buf, HTTP_RESPONSE, ssl.ciphersuite_info->name);

	while ((ret = jhd_tls_ssl_write(&ssl, buf, len)) <= 0) {
		if (ret == JHD_TLS_ERR_NET_CONN_RESET) {
			jhd_tls_printf(" failed\n  ! peer closed the connection\n\n");
			goto reset;
		}

		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_write returned %d\n\n", ret);
			goto exit;
		}
	}

	len = ret;
	jhd_tls_printf(" %d bytes written\n\n%s\n", len, (char *) buf);

	jhd_tls_printf("  . Closing the connection...");

	while ((ret = jhd_tls_ssl_close_notify(&ssl)) < 0) {
		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_close_notify returned %d\n\n", ret);
			goto reset;
		}
	}

	jhd_tls_printf(" ok\n");

	ret = 0;
	goto reset;

	exit:

#ifdef JHD_TLS_ERROR_C
	if (ret != 0) {
		char error_buf[100];
		jhd_tls_strerror(ret, error_buf, 100);
		jhd_tls_printf("Last error was: %d - %s\n\n", ret, error_buf);
	}
#endif

	jhd_tls_net_free(&client_fd);
	jhd_tls_net_free(&listen_fd);

	jhd_tls_x509_crt_free(&srvcert);
	jhd_tls_pk_free(&pkey);
	jhd_tls_ssl_free(&ssl);
	jhd_tls_ssl_config_free(&conf);

	main2();

	return (ret);
}

int main2(void) {
	int ret, len;
	jhd_tls_net_context server_fd;

	unsigned char buf[1024];
	jhd_tls_ssl_context ssl;
	jhd_tls_ssl_config conf;
	jhd_tls_x509_crt cacert;

	/*
	 * 0. Initialize the RNG and the session data
	 */
	jhd_tls_net_init(&server_fd);
	jhd_tls_ssl_init(&ssl);
	jhd_tls_ssl_config_init(&conf);
	jhd_tls_x509_crt_init(&cacert);

	jhd_tls_printf("\n  . Seeding the random number generator...");
	fflush( stdout);

	jhd_tls_printf(" ok\n");

	/*
	 * 0. Initialize certificates
	 */
	jhd_tls_printf("  . Loading the CA root certificate ...");
	fflush( stdout);

	ret = jhd_tls_x509_crt_parse(&cacert, (const unsigned char *) jhd_tls_test_cas_pem, jhd_tls_test_cas_pem_len);
	if (ret < 0) {
		jhd_tls_printf(" failed\n  !  jhd_tls_x509_crt_parse returned -0x%x\n\n", -ret);
		goto exit;
	}

	jhd_tls_printf(" ok (%d skipped)\n", ret);

	/*
	 * 1. Start the connection
	 */
	fflush( stdout);

	if ((ret = jhd_tls_net_connect(&server_fd, "localhost", "4433", 1)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_net_connect returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_printf(" ok\n");

	/*
	 * 2. Setup stuff
	 */
	jhd_tls_printf("  . Setting up the SSL/TLS structure...");
	fflush( stdout);

	if ((ret = jhd_tls_ssl_config_defaults(&conf, jhd_tls_false)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_config_defaults returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_printf(" ok\n");

	if ((ret = jhd_tls_ssl_setup(&ssl, &conf)) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_setup returned %d\n\n", ret);
		goto exit;
	}

	if ((ret = jhd_tls_ssl_set_hostname(&ssl, "localhost")) != 0) {
		jhd_tls_printf(" failed\n  ! jhd_tls_ssl_set_hostname returned %d\n\n", ret);
		goto exit;
	}

	jhd_tls_ssl_set_bio(&ssl, &server_fd, jhd_tls_net_send, jhd_tls_net_recv, NULL);

	/*
	 * 4. Handshake
	 */
	jhd_tls_printf("  . Performing the SSL/TLS handshake...");
	fflush( stdout);

	while ((ret = jhd_tls_ssl_handshake(&ssl)) != 0) {
		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_handshake returned -0x%x\n\n", -ret);
			goto exit;
		}
	}

	jhd_tls_printf(" ok\n");

	/*
	 * 5. Verify the server certificate
	 */
	jhd_tls_printf("  . Verifying peer X.509 certificate...");

	/*
	 * 3. Write the GET request
	 */
	jhd_tls_printf("  > Write to server:");
	fflush( stdout);

	len = sprintf((char *) buf, "GET / HTTP/1.1\r\n\r\n");

	while ((ret = jhd_tls_ssl_write(&ssl, buf, len)) <= 0) {
		if (ret != JHD_TLS_ERR_SSL_WANT_READ && ret != JHD_TLS_ERR_SSL_WANT_WRITE) {
			jhd_tls_printf(" failed\n  ! jhd_tls_ssl_write returned %d\n\n", ret);
			goto exit;
		}
	}

	len = ret;
	jhd_tls_printf(" %d bytes written\n\n%s", len, (char *) buf);

	/*
	 * 7. Read the HTTP response
	 */
	jhd_tls_printf("  < Read from server:");
	fflush( stdout);

	do {
		len = sizeof(buf) - 1;
		memset(buf, 0, sizeof(buf));
		ret = jhd_tls_ssl_read(&ssl, buf, len);

		if (ret == JHD_TLS_ERR_SSL_WANT_READ || ret == JHD_TLS_ERR_SSL_WANT_WRITE)
			continue;

		if (ret == JHD_TLS_ERR_SSL_PEER_CLOSE_NOTIFY)
			break;

		if (ret < 0) {
			jhd_tls_printf("failed\n  ! jhd_tls_ssl_read returned %d\n\n", ret);
			break;
		}

		if (ret == 0) {
			jhd_tls_printf("\n\nEOF\n\n");
			break;
		}

		len = ret;
		jhd_tls_printf(" %d bytes read\n\n%s", len, (char *) buf);
	} while (1);

	jhd_tls_ssl_close_notify(&ssl);

	exit:

	if(event_list){
		jhd_tls_free(event_list);
		event_list = NULL;
	}
	if(listen.fd !=-1){

		close(listen.fd);
		listen.fd = -1;
	}

	if(epoll_fd != -1){
		close(epoll_fd);
		epoll_fd = -1;

	}


	jhd_tls_x509_crt_free(&cacert);
	jhd_tls_ssl_free(&ssl);
	jhd_tls_ssl_config_free(&conf);

	return (ret);
}

