/*
 * jhd_event.c
 *
 *  Created on: May 30, 2018
 *      Author: root
 */

#include <jhd_event.h>
#include <jhd_connection.h>
#include <tls/jhd_tls_config.h>
#include <sys/epoll.h>



jhd_queue_t jhd_posted_accept_events;
jhd_queue_t jhd_posted_events;
int epoll_fd;
struct epoll_event *event_list;
int event_count;



void jhd_event_noop(jhd_event_t *ev){
	log_notice("%s","exec function");
}

void jhd_process_events_and_timers() {
	uint64_t timer, delta;
	uint32_t revents;
	int i;
	struct epoll_event ee;
	jhd_connection_t *c;
	int events;
	delta = jhd_current_msec;
	events = epoll_wait(epoll_fd, event_list, event_count, 1000);
	if (events > 0) {
		for (i = 0; i < events; ++i) {
			c = (jhd_connection_t*)event_list[i].data.ptr;
			revents = event_list[i].events;
			if (revents & (EPOLLERR | EPOLLHUP)) {
				revents |= EPOLLIN | EPOLLOUT;
			}
			if ((revents & EPOLLIN)) {
				if (c->read.queue.next == NULL) {
						jhd_queue_insert_tail(&jhd_posted_accept_events, &c->read.queue);
					} else {
						jhd_queue_insert_tail(&jhd_posted_events, &c->read.queue);
					}
				}
			}
			if (revents & EPOLLOUT) {
				if (c->read.queue.next == NULL) {
					jhd_queue_insert_tail(&jhd_posted_events, &c->write.queue);
				}
			}
		}
	}

	jhd_event_process_posted(&jhd_posted_accept_events);
	jhd_event_process_posted(&jhd_posted_events);



}

jhd_tls_bool jhd_event_add_connection(jhd_connection_t *c) {

	struct epoll_event ee;

	ee.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;
	ee.data.ptr = c;

	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, c->fd, &ee) == -1) {
		//TODO:LOG
		return jhd_tls_false;
	}
	return jhd_tls_true;

}
jhd_tls_bool jhd_event_del_connection(jhd_connection_t *c) {
	int op;
	struct epoll_event ee;
	ee.events = 0;
	ee.data.ptr = NULL;

	if (epoll_ctl(epoll_fd, EPOLL_CTL_DEL, c->fd, &ee) == -1) {
		//TODO:LOG
		return jhd_tls_false;
	}
	return jhd_tls_true;
}

int jhd_event_init() {
	event_list = NULL;
	event_count = 100;
	epoll_fd = epoll_create(100);
	if(epoll_fd == -1){
		log_err("execut epoll_create(%d) error",(int)100);
		return 1;
	}


	event_list = malloc(sizeof(struct epoll_event) * 200);
	if (event_list == NULL) {
		log_err("calloc event_list failed with ", (int)200);
		return 1;
	}

}

