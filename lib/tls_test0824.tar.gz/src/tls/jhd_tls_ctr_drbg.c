#include <tls/jhd_tls_config.h>

#if defined(JHD_TLS_CTR_DRBG_C)

#include <tls/jhd_tls_ctr_drbg.h>

#include <string.h>
#include <stdio.h>

jhd_tls_ctr_drbg_context s_g_jhd_tls_ctr_drbg;

/*
 * Non-public function wrapped by jhd_tls_ctr_drbg_seed(). Necessary to allow
 * NIST tests to succeed (which require known length fixed entropy)
 */
void jhd_tls_ctr_drbg_seed(jhd_tls_ctr_drbg_context *ctx) {
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];
	jhd_tls_platform_zeroize(key, JHD_TLS_CTR_DRBG_KEYSIZE);
	jhd_tls_platform_zeroize(&ctx->aes_ctx, sizeof(jhd_tls_aes_context));
	ctx->reseed_interval = JHD_TLS_CTR_DRBG_RESEED_INTERVAL;
	jhd_tls_aes_setkey_enc(&ctx->aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS);
	jhd_tls_ctr_drbg_reseed(ctx);
}
#if !defined(JHD_TLS_INLINE)
void jhd_tls_ctr_drbg_init(jhd_tls_ctr_drbg_context *ctx) {
	memset(ctx, 0, sizeof(jhd_tls_ctr_drbg_context));
}
#endif

static void block_cipher_df(unsigned char *output, const unsigned char *data, size_t data_len) {
	unsigned char buf[JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16];
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char key[JHD_TLS_CTR_DRBG_KEYSIZE];
	unsigned char chain[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	unsigned char *p, *iv;
	jhd_tls_aes_context aes_ctx;

	int i, j;
	size_t buf_len, use_len;

	if (data_len > JHD_TLS_CTR_DRBG_MAX_SEED_INPUT)
		data_len = JHD_TLS_CTR_DRBG_MAX_SEED_INPUT;

	jhd_tls_platform_zeroize(buf, JHD_TLS_CTR_DRBG_MAX_SEED_INPUT + JHD_TLS_CTR_DRBG_BLOCKSIZE + 16);
	jhd_tls_platform_zeroize(&aes_ctx, sizeof(jhd_tls_aes_context));

	/*
	 * Construct IV (16 bytes) and S in buffer
	 * IV = Counter (in 32-bits) padded to 16 with zeroes
	 * S = Length input string (in 32-bits) || Length of output (in 32-bits) ||
	 *     data || 0x80
	 *     (Total is padded to a multiple of 16-bytes with zeroes)
	 */
	p = buf + JHD_TLS_CTR_DRBG_BLOCKSIZE;
	*p++ = (data_len >> 24) & 0xff;
	*p++ = (data_len >> 16) & 0xff;
	*p++ = (data_len >> 8) & 0xff;
	*p++ = (data_len) & 0xff;
	p += 3;
	*p++ = JHD_TLS_CTR_DRBG_SEEDLEN;
	memcpy(p, data, data_len);
	p[data_len] = 0x80;

	buf_len = JHD_TLS_CTR_DRBG_BLOCKSIZE + 8 + data_len + 1;

	for (i = 0; i < JHD_TLS_CTR_DRBG_KEYSIZE; i++)
		key[i] = i;

	jhd_tls_aes_setkey_enc(&aes_ctx, key, JHD_TLS_CTR_DRBG_KEYBITS);

	/*
	 * Reduce data to JHD_TLS_CTR_DRBG_SEEDLEN bytes of data
	 */
	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		p = buf;
		memset(chain, 0, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		use_len = buf_len;

		while (use_len > 0) {
			for (i = 0; i < JHD_TLS_CTR_DRBG_BLOCKSIZE; i++)
				chain[i] ^= p[i];
			p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
			use_len -= (use_len >= JHD_TLS_CTR_DRBG_BLOCKSIZE) ?
			JHD_TLS_CTR_DRBG_BLOCKSIZE :
			                                                     use_len;

			jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, chain, chain);
		}

		memcpy(tmp + j, chain, JHD_TLS_CTR_DRBG_BLOCKSIZE);

		/*
		 * Update IV
		 */
		buf[3]++;
	}

	/*
	 * Do final encryption with reduced data
	 */
	jhd_tls_aes_setkey_enc(&aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS);
	iv = tmp + JHD_TLS_CTR_DRBG_KEYSIZE;
	p = output;

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		jhd_tls_aes_crypt_ecb(&aes_ctx, JHD_TLS_ENCRYPT, iv, iv);
		memcpy(p, iv, JHD_TLS_CTR_DRBG_BLOCKSIZE);
		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}

}

static void ctr_drbg_update_internal(jhd_tls_ctr_drbg_context *ctx, const unsigned char data[JHD_TLS_CTR_DRBG_SEEDLEN]) {
	unsigned char tmp[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = tmp;
	int i, j;

	memset(tmp, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	for (j = 0; j < JHD_TLS_CTR_DRBG_SEEDLEN; j += JHD_TLS_CTR_DRBG_BLOCKSIZE) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, p);

		p += JHD_TLS_CTR_DRBG_BLOCKSIZE;
	}

	for (i = 0; i < JHD_TLS_CTR_DRBG_SEEDLEN; i++)
		tmp[i] ^= data[i];

	/*
	 * Update key and counter
	 */
	jhd_tls_aes_setkey_enc(&ctx->aes_ctx, tmp, JHD_TLS_CTR_DRBG_KEYBITS);
	memcpy(ctx->counter, tmp + JHD_TLS_CTR_DRBG_KEYSIZE, JHD_TLS_CTR_DRBG_BLOCKSIZE);

}

void jhd_tls_ctr_drbg_reseed(jhd_tls_ctr_drbg_context *ctx) {
	unsigned char seed[48];
	uint64_t process_random_key;
	jhd_tls_entropy_context entropy;
	process_random_key = jhd_current_msec + ((uint64_t) jhd_pid);
	jhd_tls_entropy_init(&entropy);
	memset(seed, 0, 48);
	jhd_tls_entropy_init(&entropy);

	jhd_tls_entropy_func(&entropy, seed, 48);

	memcpy(seed, &process_random_key, sizeof(uint64_t));
	block_cipher_df(seed, seed, 48);
	ctr_drbg_update_internal(ctx, seed);
	ctx->reseed_counter = 1;

}

void jhd_tls_ctr_drbg_random_with_add(void *p_rng, unsigned char *output, size_t output_len) {
	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;
	unsigned char add_input[JHD_TLS_CTR_DRBG_SEEDLEN];
	unsigned char *p = output;
	unsigned char tmp[JHD_TLS_CTR_DRBG_BLOCKSIZE];
	int i;
	size_t use_len;

	if (output_len > JHD_TLS_CTR_DRBG_MAX_REQUEST)
		output_len = JHD_TLS_CTR_DRBG_MAX_REQUEST;
	memset(add_input, 0, JHD_TLS_CTR_DRBG_SEEDLEN);

	if (ctx->reseed_counter > ctx->reseed_interval || ctx->prediction_resistance) {
		jhd_tls_ctr_drbg_reseed(ctx);
	}

	while (output_len > 0) {
		/*
		 * Increase counter
		 */
		for (i = JHD_TLS_CTR_DRBG_BLOCKSIZE; i > 0; i--)
			if (++ctx->counter[i - 1] != 0)
				break;

		/*
		 * Crypt counter block
		 */
		jhd_tls_aes_crypt_ecb(&ctx->aes_ctx, JHD_TLS_ENCRYPT, ctx->counter, tmp);

		use_len = (output_len > JHD_TLS_CTR_DRBG_BLOCKSIZE) ? JHD_TLS_CTR_DRBG_BLOCKSIZE : output_len;
		/*
		 * Copy random block to destination
		 */
		memcpy(p, tmp, use_len);
		p += use_len;
		output_len -= use_len;
	}

	ctr_drbg_update_internal(ctx, add_input);

	ctx->reseed_counter++;

}

void jhd_tls_ctr_drbg_random(void *p_rng, unsigned char *output, size_t output_len) {

	jhd_tls_ctr_drbg_context *ctx = (jhd_tls_ctr_drbg_context *) p_rng;

	jhd_tls_ctr_drbg_random_with_add(ctx, output, output_len);

}

void jhd_tls_random_init() {
	jhd_tls_ctr_drbg_init(&s_g_jhd_tls_ctr_drbg);
	jhd_tls_ctr_drbg_seed(&s_g_jhd_tls_ctr_drbg);
}
void jhd_tls_random(unsigned char* p, size_t len) {
	jhd_tls_ctr_drbg_random((void*) &s_g_jhd_tls_ctr_drbg, p, len);
}
#if !defined(JHD_TLS_INLINE)
void jhd_tls_random32_with_time(unsigned char *p) {
	p[0] = (unsigned char) (jhd_cache_time >> 24);
	p[1] = (unsigned char) (jhd_cache_time >> 16);
	p[2] = (unsigned char) (jhd_cache_time >> 8);
	p[3] = (unsigned char) (jhd_cache_time);
	jhd_tls_ctr_drbg_random((void*) &s_g_jhd_tls_ctr_drbg, &(p[4]), 28);
}
#endif

#endif /* JHD_TLS_CTR_DRBG_C */
