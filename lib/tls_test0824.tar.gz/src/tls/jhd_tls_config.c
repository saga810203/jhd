#include <tls/jhd_tls_config.h>
#include <tls/jhd_tls_ssl_ciphersuites.h>
#include <tls/jhd_tls_ctr_drbg.h>
#include <tls/jhd_tls_aesni.h>
#include <tls/jhd_tls_cipher_internal.h>
#if defined(JHD_TLS_HAVE_ASM) && defined(__GNUC__) &&  \
    ( defined(__amd64__) || defined(__x86_64__) )   &&  \
    ! defined(JHD_TLS_HAVE_X86_64)
#define JHD_TLS_HAVE_X86_64
#endif

int jhd_tls_config_init(){
	int ret= 0;
	jhd_tls_ciphers_init();
#if defined(JHD_TLS_HAVE_X86_64)
	jhd_tls_aesni_has_support();
#endif
	jhd_tls_random_init();
	return ret;
}
