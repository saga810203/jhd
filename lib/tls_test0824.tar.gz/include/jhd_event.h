/*
 * jhd_event.h
 *
 *  Created on: 2018年5月19日
 *      Author: root
 */

#ifndef JHD_EVENT_H_
#define JHD_EVENT_H_

#include <jhd_queue.h>
#include <jhd_connection.h>
#include <tls/jhd_tls_config.h>


typedef struct jhd_event_s jhd_event_t;

typedef void (*jhd_event_handler_pt)(jhd_event_t *ev);


struct jhd_event_s {
	void *data;
	jhd_event_handler_pt handler;
	jhd_queue_t queue;
	unsigned write :1;
	unsigned error :1;
	/* to test on worker exit */
	unsigned channel :1;
	unsigned timedout :1;
};


/* =========================begin extern var======================== */

extern jhd_queue_t jhd_posted_accept_events;
extern jhd_queue_t jhd_posted_events;
extern struct epoll_event *event_list;
extern int event_count;


extern int epoll_fd;

/* =========================end extern var======================== */

int jhd_event_init();
void jhd_event_noop(jhd_event_t *ev);
void jhd_process_events_and_timers();

uint64_t jhd_event_find_timer(void);
void jhd_event_expire_timers(void);

void jhd_event_expire_all(void);

jhd_tls_bool  jhd_event_add_connection(jhd_connection_t  *c);
jhd_tls_bool  jhd_event_del_connection(jhd_connection_t *c);


#define jhd_post_event(ev, queue)  if (!(ev)->queue.next) { jhd_queue_insert_tail((queue), &(ev)->queue);}

#define jhd_delete_posted_event(ev)   jhd_queue_remove(&(ev)->queue)

#define jhd_event_from_queue(q)    jhd_queue_data(q,jhd_event_t,queue);

#define jhd_post_listener(lis,queue) ngx_queue_insert_tail(queue,&(lis)->queue);

#define jhd_delete_listener(lis)  jhd_queue_only_remove(lis)

#define jhd_listener_from_queue(q)   jhd_queue_data(q,jhd_listener_t,queue);

void inline jhd_event_process_posted(jhd_queue_t *posted) {
	jhd_queue_t *q;
	jhd_event_t *ev;

	while (!jhd_queue_empty(posted)) {
		q = jhd_queue_head(posted);
		ev = jhd_queue_data(q, jhd_event_t, queue);
		jhd_delete_posted_event(ev);
		ev->handler(ev);
	}
}

#endif /* JHD_EVENT_H_ */
