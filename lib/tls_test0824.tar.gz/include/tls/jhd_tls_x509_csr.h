#ifndef JHD_TLS_X509_CSR_H
#define JHD_TLS_X509_CSR_H

#include <tls/jhd_tls_config.h>

#include <tls/jhd_tls_x509.h>

/**
 * \addtogroup x509_module
 * \{ */

/**
 * \name Structures and functions for X.509 Certificate Signing Requests (CSR)
 * \{
 */

/**
 * Certificate Signing Request (CSR) structure.
 */
typedef struct jhd_tls_x509_csr {
	jhd_tls_x509_buf raw; /**< The raw CSR data (DER). */
	jhd_tls_x509_buf cri; /**< The raw CertificateRequestInfo body (DER). */

	int version; /**< CSR version (1=v1). */

	jhd_tls_x509_buf subject_raw; /**< The raw subject data (DER). */
	jhd_tls_x509_name subject; /**< The parsed subject data (named information object). */

	jhd_tls_pk_context pk; /**< Container for the public key context. */

	jhd_tls_x509_buf sig_oid;
	jhd_tls_x509_buf sig;
	const jhd_tls_md_info_t *sig_md; /**< Internal representation of the MD algorithm of the signature algorithm, e.g. JHD_TLS_MD_SHA256 */
	const jhd_tls_pk_info_t *sig_pk; /**< Internal representation of the Public Key algorithm of the signature algorithm, e.g. JHD_TLS_PK_RSA */
	void *sig_opts; /**< Signature options to be passed to jhd_tls_pk_verify_ext(), e.g. for RSASSA-PSS */
} jhd_tls_x509_csr;

/**
 * Container for writing a CSR
 */
typedef struct jhd_tls_x509write_csr {
	jhd_tls_pk_context *key;
	jhd_tls_asn1_named_data *subject;
	jhd_tls_md_info_t *md_info;
	jhd_tls_asn1_named_data *extensions;
} jhd_tls_x509write_csr;

#if defined(JHD_TLS_X509_CSR_PARSE_C)
/**
 * \brief          Load a Certificate Signing Request (CSR) in DER format
 *
 * \note           CSR attributes (if any) are currently silently ignored.
 *
 * \param csr      CSR context to fill
 * \param buf      buffer holding the CRL data
 * \param buflen   size of the buffer
 *
 * \return         0 if successful, or a specific X509 error code
 */
int jhd_tls_x509_csr_parse_der(jhd_tls_x509_csr *csr, const unsigned char *buf, size_t buflen);

/**
 * \brief          Load a Certificate Signing Request (CSR), DER or PEM format
 *
 * \note           See notes for \c jhd_tls_x509_csr_parse_der()
 *
 * \param csr      CSR context to fill
 * \param buf      buffer holding the CRL data
 * \param buflen   size of the buffer
 *                 (including the terminating null byte for PEM data)
 *
 * \return         0 if successful, or a specific X509 or PEM error code
 */
int jhd_tls_x509_csr_parse(jhd_tls_x509_csr *csr, const unsigned char *buf, size_t buflen);

#if defined(JHD_TLS_FS_IO)
/**
 * \brief          Load a Certificate Signing Request (CSR)
 *
 * \note           See notes for \c jhd_tls_x509_csr_parse()
 *
 * \param csr      CSR context to fill
 * \param path     filename to read the CSR from
 *
 * \return         0 if successful, or a specific X509 or PEM error code
 */
int jhd_tls_x509_csr_parse_file(jhd_tls_x509_csr *csr, const char *path);
#endif /* JHD_TLS_FS_IO */

/**
 * \brief          Returns an informational string about the
 *                 CSR.
 *
 * \param buf      Buffer to write to
 * \param size     Maximum size of buffer
 * \param prefix   A line prefix
 * \param csr      The X509 CSR to represent
 *
 * \return         The length of the string written (not including the
 *                 terminated nul byte), or a negative error code.
 */
int jhd_tls_x509_csr_info(char *buf, size_t size, const char *prefix, const jhd_tls_x509_csr *csr);

/**
 * \brief          Initialize a CSR
 *
 * \param csr      CSR to initialize
 */
void jhd_tls_x509_csr_init(jhd_tls_x509_csr *csr);

/**
 * \brief          Unallocate all CSR data
 *
 * \param csr      CSR to free
 */
void jhd_tls_x509_csr_free(jhd_tls_x509_csr *csr);
#endif /* JHD_TLS_X509_CSR_PARSE_C */

/* \} name */
/* \} addtogroup x509_module */
#endif /* jhd_tls_x509_csr.h */
