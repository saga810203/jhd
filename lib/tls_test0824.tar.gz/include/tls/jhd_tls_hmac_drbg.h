#ifndef JHD_TLS_HMAC_DRBG_H
#define JHD_TLS_HMAC_DRBG_H

#include <tls/jhd_tls_md.h>

/*
 * Error codes
 */
#define JHD_TLS_ERR_HMAC_DRBG_REQUEST_TOO_BIG              -0x0003  /**< Too many random requested in single call. */
#define JHD_TLS_ERR_HMAC_DRBG_INPUT_TOO_BIG                -0x0005  /**< Input too large (Entropy + additional). */
#define JHD_TLS_ERR_HMAC_DRBG_FILE_IO_ERROR                -0x0007  /**< Read/write error in file. */
#define JHD_TLS_ERR_HMAC_DRBG_ENTROPY_SOURCE_FAILED        -0x0009  /**< The entropy source failed. */

/**
 * \name SECTION: Module settings
 *
 * The configuration options you can set for this module are in this section.
 * Either change them in config.h or define them on the compiler command line.
 * \{
 */

#if !defined(JHD_TLS_HMAC_DRBG_RESEED_INTERVAL)
#define JHD_TLS_HMAC_DRBG_RESEED_INTERVAL   10000   /**< Interval before reseed is performed by default */
#endif

#if !defined(JHD_TLS_HMAC_DRBG_MAX_INPUT)
#define JHD_TLS_HMAC_DRBG_MAX_INPUT         256     /**< Maximum number of additional input bytes */
#endif

#if !defined(JHD_TLS_HMAC_DRBG_MAX_REQUEST)
#define JHD_TLS_HMAC_DRBG_MAX_REQUEST       1024    /**< Maximum number of requested bytes per call */
#endif

#if !defined(JHD_TLS_HMAC_DRBG_MAX_SEED_INPUT)
#define JHD_TLS_HMAC_DRBG_MAX_SEED_INPUT    384     /**< Maximum size of (re)seed buffer */
#endif

/* \} name SECTION: Module settings */

#define JHD_TLS_HMAC_DRBG_PR_OFF   0   /**< No prediction resistance       */
#define JHD_TLS_HMAC_DRBG_PR_ON    1   /**< Prediction resistance enabled  */

/**
 * HMAC_DRBG context.
 */
typedef struct {
	/* Working state: the key K is not stored explicitely,
	 * but is implied by the HMAC context */
	jhd_tls_md_context_t *md_ctx; /*!< HMAC context (inc. K)  */
	unsigned char V[JHD_TLS_MD_MAX_SIZE]; /*!< V in the spec          */
} jhd_tls_hmac_drbg_context;

#if !defined(JHD_TLS_INLINE)
/**
 * \brief               HMAC_DRBG context initialization
 *                      Makes the context ready for jhd_tls_hmac_drbg_seed(),
 *                      jhd_tls_hmac_drbg_seed_buf() or
 *                      jhd_tls_hmac_drbg_free().
 *
 * \param ctx           HMAC_DRBG context to be initialized
 */
void jhd_tls_hmac_drbg_init(jhd_tls_hmac_drbg_context *ctx);
#else
#define jhd_tls_hmac_drbg_init(ctx) jhd_tls_platform_zeroize(ctx,sizeof(jhd_tls_hmac_drbg_context))
#endif

/**
 * \brief               Initilisation of simpified HMAC_DRBG (never reseeds).
 *                      (For use with deterministic ECDSA.)
 *
 * \param ctx           HMAC_DRBG context to be initialised
 * \param md_info       MD algorithm to use for HMAC_DRBG
 * \param data          Concatenation of entropy string and additional data
 * \param data_len      Length of data in bytes
 *
 * \return              0 if successful, or
 *                      JHD_TLS_ERR_MD_BAD_INPUT_DATA, or
 *                      JHD_TLS_ERR_MD_ALLOC_FAILED.
 */
void jhd_tls_hmac_drbg_seed_buf(jhd_tls_hmac_drbg_context *ctx, jhd_tls_md_context_t * md_ctx, const unsigned char *data, size_t data_len);

/**
 * \brief               HMAC_DRBG generate random
 *
 * Note: Automatically reseeds if reseed_counter is reached or PR is enabled.
 *
 * \param p_rng         HMAC_DRBG context
 * \param output        Buffer to fill
 * \param out_len       Length of the buffer
 *
 * \return              0 if successful, or
 *                      JHD_TLS_ERR_HMAC_DRBG_ENTROPY_SOURCE_FAILED, or
 *                      JHD_TLS_ERR_HMAC_DRBG_REQUEST_TOO_BIG
 */
void jhd_tls_hmac_drbg_random(void *p_rng, unsigned char *output, size_t out_len);

#endif /* hmac_drbg.h */
